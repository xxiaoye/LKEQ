﻿namespace UseingEQ
{
    partial class EQChangeManag
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EQChangeManag));
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("所有设备类别");
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Add_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.Edit_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.SubmitCheck_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.Submited_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.Del_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.View_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.refresh_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeDuan1 = new YtWinContrl.com.contrl.DateTimeDuan();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.selTextInpt1 = new YtWinContrl.com.contrl.SelTextInpt();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.EQKind_tab = new System.Windows.Forms.TabPage();
            this.EQKind_ytTreeView = new YtWinContrl.com.YtTreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGView2 = new YtWinContrl.com.datagrid.DataGView();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ChangeTypeColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ChangeManagStatu_Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column65 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column57 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column53 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column54 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column58 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column56 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column60 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column61 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column62 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column70 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column71 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column55 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column59 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column72 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column64 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGView1 = new YtWinContrl.com.datagrid.DataGView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status_Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Statuscode_Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Deptid_Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.EQKind_tab.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Add_toolStrip,
            this.Edit_toolStrip,
            this.SubmitCheck_toolStrip,
            this.Submited_toolStrip,
            this.Del_toolStrip,
            this.View_toolStrip,
            this.refresh_toolStrip});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(983, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Add_toolStrip
            // 
            this.Add_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Add_toolStrip.Image")));
            this.Add_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Add_toolStrip.Name = "Add_toolStrip";
            this.Add_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Add_toolStrip.Text = "新增";
            this.Add_toolStrip.Click += new System.EventHandler(this.Add_toolStrip_Click);
            // 
            // Edit_toolStrip
            // 
            this.Edit_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Edit_toolStrip.Image")));
            this.Edit_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Edit_toolStrip.Name = "Edit_toolStrip";
            this.Edit_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Edit_toolStrip.Text = "编辑";
            this.Edit_toolStrip.Click += new System.EventHandler(this.Edit_toolStrip_Click);
            // 
            // SubmitCheck_toolStrip
            // 
            this.SubmitCheck_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("SubmitCheck_toolStrip.Image")));
            this.SubmitCheck_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SubmitCheck_toolStrip.Name = "SubmitCheck_toolStrip";
            this.SubmitCheck_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.SubmitCheck_toolStrip.Text = "提交";
            this.SubmitCheck_toolStrip.Click += new System.EventHandler(this.SubmitCheck_toolStrip_Click);
            // 
            // Submited_toolStrip
            // 
            this.Submited_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Submited_toolStrip.Image")));
            this.Submited_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Submited_toolStrip.Name = "Submited_toolStrip";
            this.Submited_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Submited_toolStrip.Text = "审核";
            this.Submited_toolStrip.Click += new System.EventHandler(this.Submited_toolStrip_Click);
            // 
            // Del_toolStrip
            // 
            this.Del_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Del_toolStrip.Image")));
            this.Del_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Del_toolStrip.Name = "Del_toolStrip";
            this.Del_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Del_toolStrip.Text = "删除";
            this.Del_toolStrip.Click += new System.EventHandler(this.Del_toolStrip_Click);
            // 
            // View_toolStrip
            // 
            this.View_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("View_toolStrip.Image")));
            this.View_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.View_toolStrip.Name = "View_toolStrip";
            this.View_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.View_toolStrip.Text = "浏览";
            this.View_toolStrip.Click += new System.EventHandler(this.View_toolStrip_Click);
            // 
            // refresh_toolStrip
            // 
            this.refresh_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("refresh_toolStrip.Image")));
            this.refresh_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.refresh_toolStrip.Name = "refresh_toolStrip";
            this.refresh_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.refresh_toolStrip.Text = "刷新";
            this.refresh_toolStrip.Click += new System.EventHandler(this.refresh_toolStrip_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.dateTimeDuan1);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.selTextInpt1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(983, 59);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "查询条件";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(411, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 36;
            this.label2.Text = "到";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(248, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 35;
            this.label4.Text = "从";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Checked = false;
            this.dateTimePicker2.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(442, 22);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(127, 21);
            this.dateTimePicker2.TabIndex = 2;
            // 
            // dateTimeDuan1
            // 
            this.dateTimeDuan1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dateTimeDuan1.End = this.dateTimePicker2;
            this.dateTimeDuan1.FormattingEnabled = true;
            this.dateTimeDuan1.Location = new System.Drawing.Point(93, 21);
            this.dateTimeDuan1.Name = "dateTimeDuan1";
            this.dateTimeDuan1.Size = new System.Drawing.Size(108, 20);
            this.dateTimeDuan1.Start = this.dateTimePicker1;
            this.dateTimeDuan1.TabIndex = 0;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Checked = false;
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(272, 22);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(127, 21);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(593, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "科室";
            // 
            // selTextInpt1
            // 
            this.selTextInpt1.ColDefText = null;
            this.selTextInpt1.ColStyle = null;
            this.selTextInpt1.DataType = null;
            this.selTextInpt1.DbConn = null;
            this.selTextInpt1.Location = new System.Drawing.Point(659, 21);
            this.selTextInpt1.Name = "selTextInpt1";
            this.selTextInpt1.NextFocusControl = null;
            this.selTextInpt1.ReadOnly = false;
            this.selTextInpt1.SelParam = null;
            this.selTextInpt1.ShowColNum = 0;
            this.selTextInpt1.ShowWidth = 0;
            this.selTextInpt1.Size = new System.Drawing.Size(137, 22);
            this.selTextInpt1.Sql = null;
            this.selTextInpt1.SqlStr = null;
            this.selTextInpt1.TabIndex = 3;
            this.selTextInpt1.TvColName = null;
            this.selTextInpt1.Value = null;
            this.selTextInpt1.WatermarkText = "";
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(850, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "查询";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "时间段";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tabControl1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox2.Location = new System.Drawing.Point(0, 84);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(174, 398);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "列表查询条件";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.EQKind_tab);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ItemSize = new System.Drawing.Size(95, 17);
            this.tabControl1.Location = new System.Drawing.Point(3, 17);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(168, 378);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 3;
            // 
            // EQKind_tab
            // 
            this.EQKind_tab.Controls.Add(this.EQKind_ytTreeView);
            this.EQKind_tab.Location = new System.Drawing.Point(4, 21);
            this.EQKind_tab.Name = "EQKind_tab";
            this.EQKind_tab.Padding = new System.Windows.Forms.Padding(3);
            this.EQKind_tab.Size = new System.Drawing.Size(160, 353);
            this.EQKind_tab.TabIndex = 0;
            this.EQKind_tab.Text = "所有设备分类";
            this.EQKind_tab.UseVisualStyleBackColor = true;
            // 
            // EQKind_ytTreeView
            // 
            this.EQKind_ytTreeView.DbConn = null;
            this.EQKind_ytTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EQKind_ytTreeView.HideSelection = false;
            this.EQKind_ytTreeView.ImageIndex = 0;
            this.EQKind_ytTreeView.ImageList = this.imageList1;
            this.EQKind_ytTreeView.LoadHaveData = false;
            this.EQKind_ytTreeView.Location = new System.Drawing.Point(3, 3);
            this.EQKind_ytTreeView.Name = "EQKind_ytTreeView";
            treeNode2.Name = "节点0";
            treeNode2.Text = "所有设备类别";
            this.EQKind_ytTreeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode2});
            this.EQKind_ytTreeView.NoNodeTag = null;
            this.EQKind_ytTreeView.SelectedImageIndex = 1;
            this.EQKind_ytTreeView.Size = new System.Drawing.Size(154, 347);
            this.EQKind_ytTreeView.TabIndex = 5;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "CheckGreen.bmp");
            this.imageList1.Images.SetKeyName(1, "CheckRed.bmp");
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dataGView2);
            this.groupBox3.Controls.Add(this.dataGView1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(174, 84);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(809, 398);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "设备使用信息";
            // 
            // dataGView2
            // 
            this.dataGView2.AllowUserToAddRows = false;
            this.dataGView2.AllowUserToDeleteRows = false;
            this.dataGView2.AllowUserToResizeRows = false;
            this.dataGView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGView2.ChangeDataColumName = null;
            this.dataGView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column22,
            this.Column39,
            this.ChangeTypeColumn,
            this.ChangeManagStatu_Column,
            this.Column65,
            this.Column50,
            this.Column41,
            this.Column57,
            this.Column53,
            this.Column54,
            this.Column52,
            this.Column58,
            this.Column56,
            this.Column60,
            this.Column61,
            this.Column62,
            this.Column70,
            this.Column71,
            this.Column55,
            this.Column59,
            this.Column72,
            this.Column49,
            this.Column51,
            this.Column64});
            this.dataGView2.DbConn = null;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView2.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGView2.DwColIndex = 0;
            this.dataGView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView2.IsEditOnEnter = true;
            this.dataGView2.IsFillForm = true;
            this.dataGView2.IsPage = false;
            this.dataGView2.Key = null;
            this.dataGView2.Location = new System.Drawing.Point(3, 258);
            this.dataGView2.MultiSelect = false;
            this.dataGView2.Name = "dataGView2";
            this.dataGView2.ReadOnly = true;
            this.dataGView2.RowHeadersWidth = 20;
            this.dataGView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView2.RowTemplate.Height = 23;
            this.dataGView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView2.Size = new System.Drawing.Size(803, 137);
            this.dataGView2.TabIndex = 6;
            this.dataGView2.TjFmtStr = null;
            this.dataGView2.TjFormat = null;
            this.dataGView2.Url = null;
            this.dataGView2.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGView2_CellDoubleClick);
            // 
            // Column22
            // 
            this.Column22.DataPropertyName = "CHANGEID";
            this.Column22.HeaderText = "变动ID";
            this.Column22.Name = "Column22";
            this.Column22.ReadOnly = true;
            this.Column22.Width = 66;
            // 
            // Column39
            // 
            this.Column39.DataPropertyName = "CARDID";
            this.Column39.HeaderText = "卡片ID";
            this.Column39.Name = "Column39";
            this.Column39.ReadOnly = true;
            this.Column39.Width = 66;
            // 
            // ChangeTypeColumn
            // 
            this.ChangeTypeColumn.DataPropertyName = "CHANGETYPE";
            this.ChangeTypeColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.ChangeTypeColumn.HeaderText = "变动类型";
            this.ChangeTypeColumn.Name = "ChangeTypeColumn";
            this.ChangeTypeColumn.ReadOnly = true;
            this.ChangeTypeColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ChangeTypeColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ChangeTypeColumn.Width = 78;
            // 
            // ChangeManagStatu_Column
            // 
            this.ChangeManagStatu_Column.DataPropertyName = "STATUS";
            this.ChangeManagStatu_Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.ChangeManagStatu_Column.HeaderText = "状态";
            this.ChangeManagStatu_Column.Name = "ChangeManagStatu_Column";
            this.ChangeManagStatu_Column.ReadOnly = true;
            this.ChangeManagStatu_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ChangeManagStatu_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ChangeManagStatu_Column.Width = 54;
            // 
            // Column65
            // 
            this.Column65.DataPropertyName = "原使用科室";
            this.Column65.HeaderText = "原使用科室";
            this.Column65.Name = "Column65";
            this.Column65.ReadOnly = true;
            this.Column65.Width = 90;
            // 
            // Column50
            // 
            this.Column50.DataPropertyName = "OLDMAN";
            this.Column50.HeaderText = "原保管员";
            this.Column50.Name = "Column50";
            this.Column50.ReadOnly = true;
            this.Column50.Width = 78;
            // 
            // Column41
            // 
            this.Column41.DataPropertyName = "现使用科室";
            this.Column41.HeaderText = "现使用科室";
            this.Column41.Name = "Column41";
            this.Column41.ReadOnly = true;
            this.Column41.Width = 90;
            // 
            // Column57
            // 
            this.Column57.DataPropertyName = "USEMAN";
            this.Column57.HeaderText = "现保管员";
            this.Column57.Name = "Column57";
            this.Column57.ReadOnly = true;
            this.Column57.Width = 78;
            // 
            // Column53
            // 
            this.Column53.DataPropertyName = "OLDVALUE";
            this.Column53.HeaderText = "调整前原值";
            this.Column53.Name = "Column53";
            this.Column53.ReadOnly = true;
            this.Column53.Width = 90;
            // 
            // Column54
            // 
            this.Column54.DataPropertyName = "NOWVALUE";
            this.Column54.HeaderText = "调整后原值";
            this.Column54.Name = "Column54";
            this.Column54.ReadOnly = true;
            this.Column54.Width = 90;
            // 
            // Column52
            // 
            this.Column52.DataPropertyName = "原使用状态";
            this.Column52.HeaderText = "原使用状态";
            this.Column52.Name = "Column52";
            this.Column52.ReadOnly = true;
            this.Column52.Width = 90;
            // 
            // Column58
            // 
            this.Column58.DataPropertyName = "新使用状态";
            this.Column58.HeaderText = "新使用状态";
            this.Column58.Name = "Column58";
            this.Column58.ReadOnly = true;
            this.Column58.Width = 90;
            // 
            // Column56
            // 
            this.Column56.DataPropertyName = "MEMO";
            this.Column56.HeaderText = "备注";
            this.Column56.Name = "Column56";
            this.Column56.ReadOnly = true;
            this.Column56.Width = 54;
            // 
            // Column60
            // 
            this.Column60.DataPropertyName = "USERID";
            this.Column60.HeaderText = "操作员ID";
            this.Column60.Name = "Column60";
            this.Column60.ReadOnly = true;
            this.Column60.Width = 78;
            // 
            // Column61
            // 
            this.Column61.DataPropertyName = "USERNAME";
            this.Column61.HeaderText = "操作员姓名";
            this.Column61.Name = "Column61";
            this.Column61.ReadOnly = true;
            this.Column61.Width = 90;
            // 
            // Column62
            // 
            this.Column62.DataPropertyName = "RECDATE";
            this.Column62.HeaderText = "修改时间";
            this.Column62.Name = "Column62";
            this.Column62.ReadOnly = true;
            this.Column62.Width = 78;
            // 
            // Column70
            // 
            this.Column70.DataPropertyName = "SHUSERNAME";
            this.Column70.HeaderText = "审核操作员名称";
            this.Column70.Name = "Column70";
            this.Column70.ReadOnly = true;
            this.Column70.Width = 114;
            // 
            // Column71
            // 
            this.Column71.DataPropertyName = "SHUSERID";
            this.Column71.HeaderText = "审核操作员ID";
            this.Column71.Name = "Column71";
            this.Column71.ReadOnly = true;
            this.Column71.Width = 102;
            // 
            // Column55
            // 
            this.Column55.DataPropertyName = "SHDATE";
            this.Column55.HeaderText = "审核时间";
            this.Column55.Name = "Column55";
            this.Column55.ReadOnly = true;
            this.Column55.Width = 78;
            // 
            // Column59
            // 
            this.Column59.DataPropertyName = "CHOSCODE";
            this.Column59.HeaderText = "医疗机构编码";
            this.Column59.Name = "Column59";
            this.Column59.ReadOnly = true;
            this.Column59.Width = 102;
            // 
            // Column72
            // 
            this.Column72.DataPropertyName = "OLDDEPTID";
            this.Column72.HeaderText = "原使用科室ID";
            this.Column72.Name = "Column72";
            this.Column72.ReadOnly = true;
            this.Column72.Width = 102;
            // 
            // Column49
            // 
            this.Column49.DataPropertyName = "OLDSTATUSCODE";
            this.Column49.HeaderText = "原使用状态编码";
            this.Column49.Name = "Column49";
            this.Column49.ReadOnly = true;
            this.Column49.Width = 114;
            // 
            // Column51
            // 
            this.Column51.DataPropertyName = "USEDEPTID";
            this.Column51.HeaderText = "现使用科室ID";
            this.Column51.Name = "Column51";
            this.Column51.ReadOnly = true;
            this.Column51.Width = 102;
            // 
            // Column64
            // 
            this.Column64.DataPropertyName = "NEWSTATUSCODE";
            this.Column64.HeaderText = "新使用状态编码";
            this.Column64.Name = "Column64";
            this.Column64.ReadOnly = true;
            this.Column64.Width = 114;
            // 
            // dataGView1
            // 
            this.dataGView1.AllowUserToAddRows = false;
            this.dataGView1.AllowUserToDeleteRows = false;
            this.dataGView1.AllowUserToResizeRows = false;
            this.dataGView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGView1.ChangeDataColumName = null;
            this.dataGView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column6,
            this.Column9,
            this.Status_Column,
            this.Statuscode_Column,
            this.Deptid_Column,
            this.Column12,
            this.Column7,
            this.Column8,
            this.Column10,
            this.Column11,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21,
            this.Column23,
            this.Column24,
            this.Column25,
            this.Column26,
            this.Column27,
            this.Column28,
            this.Column29,
            this.Column30,
            this.Column31,
            this.Column32,
            this.Column33,
            this.Column34,
            this.Column35,
            this.Column36,
            this.Column37,
            this.Column38,
            this.Column40,
            this.Column42,
            this.Column43,
            this.Column44,
            this.Column45,
            this.Column46,
            this.Column47,
            this.Column48,
            this.Column5});
            this.dataGView1.DbConn = null;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGView1.DwColIndex = 0;
            this.dataGView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView1.IsEditOnEnter = true;
            this.dataGView1.IsFillForm = true;
            this.dataGView1.IsPage = false;
            this.dataGView1.Key = null;
            this.dataGView1.Location = new System.Drawing.Point(3, 17);
            this.dataGView1.MultiSelect = false;
            this.dataGView1.Name = "dataGView1";
            this.dataGView1.ReadOnly = true;
            this.dataGView1.RowHeadersWidth = 20;
            this.dataGView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView1.RowTemplate.Height = 23;
            this.dataGView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView1.Size = new System.Drawing.Size(803, 241);
            this.dataGView1.TabIndex = 5;
            this.dataGView1.TjFmtStr = null;
            this.dataGView1.TjFormat = null;
            this.dataGView1.Url = null;
            this.dataGView1.SelectionChanged += new System.EventHandler(this.dataGView1_SelectionChanged);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "CARDID";
            this.Column1.HeaderText = "卡片ID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 66;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "CARDCODE";
            this.Column2.HeaderText = "卡号";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 54;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "STOCKFLOWNO";
            this.Column3.HeaderText = "库存流水号";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 90;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "STOCKID";
            this.Column4.HeaderText = "库存ID";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 66;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "EQNAME";
            this.Column6.HeaderText = "设备名称";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 78;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "EQNUM";
            this.Column9.HeaderText = "设备数量";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 78;
            // 
            // Status_Column
            // 
            this.Status_Column.DataPropertyName = "STATUS";
            this.Status_Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Status_Column.HeaderText = "状态";
            this.Status_Column.Name = "Status_Column";
            this.Status_Column.ReadOnly = true;
            this.Status_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Status_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Status_Column.Width = 54;
            // 
            // Statuscode_Column
            // 
            this.Statuscode_Column.DataPropertyName = "STATUSCODE";
            this.Statuscode_Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Statuscode_Column.HeaderText = "使用状态";
            this.Statuscode_Column.Name = "Statuscode_Column";
            this.Statuscode_Column.ReadOnly = true;
            this.Statuscode_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Statuscode_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Statuscode_Column.Width = 78;
            // 
            // Deptid_Column
            // 
            this.Deptid_Column.DataPropertyName = "DEPTID";
            this.Deptid_Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Deptid_Column.HeaderText = "使用科室ID";
            this.Deptid_Column.Name = "Deptid_Column";
            this.Deptid_Column.ReadOnly = true;
            this.Deptid_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Deptid_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Deptid_Column.Width = 90;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "FARE";
            this.Column12.HeaderText = "收费标准";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 78;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "COUNTRY";
            this.Column7.HeaderText = "国别";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 54;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "CONTRACTCODE";
            this.Column8.HeaderText = "合同号";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 66;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "PRICE";
            this.Column10.HeaderText = "价格";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 54;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "YPRICE";
            this.Column11.HeaderText = "原值";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 54;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "DGDATE";
            this.Column13.HeaderText = "订购时间";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Width = 78;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "CCDATE";
            this.Column14.HeaderText = "出厂时间";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Width = 78;
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "LYPEOPLE";
            this.Column15.HeaderText = "领用人";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Width = 66;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "LYDATE";
            this.Column16.HeaderText = "领用时间";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.Width = 78;
            // 
            // Column17
            // 
            this.Column17.DataPropertyName = "SETUPDATE";
            this.Column17.HeaderText = "安装时间";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.Width = 78;
            // 
            // Column18
            // 
            this.Column18.DataPropertyName = "SETUPPEOPLE";
            this.Column18.HeaderText = "安装人";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            this.Column18.Width = 66;
            // 
            // Column19
            // 
            this.Column19.DataPropertyName = "CCCODE";
            this.Column19.HeaderText = "出厂号";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            this.Column19.Width = 66;
            // 
            // Column20
            // 
            this.Column20.DataPropertyName = "USEYEAR";
            this.Column20.HeaderText = "使用年限";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.Width = 78;
            // 
            // Column21
            // 
            this.Column21.DataPropertyName = "USEDYEAR";
            this.Column21.HeaderText = "已使用年限";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.Width = 90;
            // 
            // Column23
            // 
            this.Column23.DataPropertyName = "TOTALWORK";
            this.Column23.HeaderText = "总工作量";
            this.Column23.Name = "Column23";
            this.Column23.ReadOnly = true;
            this.Column23.Width = 78;
            // 
            // Column24
            // 
            this.Column24.DataPropertyName = "TOTALEDWORK";
            this.Column24.HeaderText = "累计工作量";
            this.Column24.Name = "Column24";
            this.Column24.ReadOnly = true;
            this.Column24.Width = 90;
            // 
            // Column25
            // 
            this.Column25.DataPropertyName = "TOTALZJ";
            this.Column25.HeaderText = "累计折旧";
            this.Column25.Name = "Column25";
            this.Column25.ReadOnly = true;
            this.Column25.Width = 78;
            // 
            // Column26
            // 
            this.Column26.DataPropertyName = "CZRATE";
            this.Column26.HeaderText = "残值率";
            this.Column26.Name = "Column26";
            this.Column26.ReadOnly = true;
            this.Column26.Width = 66;
            // 
            // Column27
            // 
            this.Column27.DataPropertyName = "MAINUSE";
            this.Column27.HeaderText = "主要用途";
            this.Column27.Name = "Column27";
            this.Column27.ReadOnly = true;
            this.Column27.Width = 78;
            // 
            // Column28
            // 
            this.Column28.DataPropertyName = "YSREC";
            this.Column28.HeaderText = "验收记录";
            this.Column28.Name = "Column28";
            this.Column28.ReadOnly = true;
            this.Column28.Width = 78;
            // 
            // Column29
            // 
            this.Column29.DataPropertyName = "YSPEOPLE";
            this.Column29.HeaderText = "验收人员";
            this.Column29.Name = "Column29";
            this.Column29.ReadOnly = true;
            this.Column29.Width = 78;
            // 
            // Column30
            // 
            this.Column30.DataPropertyName = "QUATHING";
            this.Column30.HeaderText = "质量情况";
            this.Column30.Name = "Column30";
            this.Column30.ReadOnly = true;
            this.Column30.Width = 78;
            // 
            // Column31
            // 
            this.Column31.DataPropertyName = "BGPEOPLE";
            this.Column31.HeaderText = "保管人";
            this.Column31.Name = "Column31";
            this.Column31.ReadOnly = true;
            this.Column31.Width = 66;
            // 
            // Column32
            // 
            this.Column32.DataPropertyName = "MEMO";
            this.Column32.HeaderText = "备注";
            this.Column32.Name = "Column32";
            this.Column32.ReadOnly = true;
            this.Column32.Width = 54;
            // 
            // Column33
            // 
            this.Column33.DataPropertyName = "TXM";
            this.Column33.HeaderText = "条形码";
            this.Column33.Name = "Column33";
            this.Column33.ReadOnly = true;
            this.Column33.Width = 66;
            // 
            // Column34
            // 
            this.Column34.DataPropertyName = "FDVALUE";
            this.Column34.HeaderText = "分度值";
            this.Column34.Name = "Column34";
            this.Column34.ReadOnly = true;
            this.Column34.Width = 66;
            // 
            // Column35
            // 
            this.Column35.DataPropertyName = "JDLEVEL";
            this.Column35.HeaderText = "精度等级";
            this.Column35.Name = "Column35";
            this.Column35.ReadOnly = true;
            this.Column35.Width = 78;
            // 
            // Column36
            // 
            this.Column36.DataPropertyName = "CHECKLEVEL";
            this.Column36.HeaderText = "检定等级";
            this.Column36.Name = "Column36";
            this.Column36.ReadOnly = true;
            this.Column36.Width = 78;
            // 
            // Column37
            // 
            this.Column37.DataPropertyName = "CHECKRANGE";
            this.Column37.HeaderText = "测量范围";
            this.Column37.Name = "Column37";
            this.Column37.ReadOnly = true;
            this.Column37.Width = 78;
            // 
            // Column38
            // 
            this.Column38.DataPropertyName = "CHECKZQ";
            this.Column38.HeaderText = "检定周期";
            this.Column38.Name = "Column38";
            this.Column38.ReadOnly = true;
            this.Column38.Width = 78;
            // 
            // Column40
            // 
            this.Column40.DataPropertyName = "CHOSCODE";
            this.Column40.HeaderText = "医疗机构编码";
            this.Column40.Name = "Column40";
            this.Column40.ReadOnly = true;
            this.Column40.Width = 102;
            // 
            // Column42
            // 
            this.Column42.DataPropertyName = "USERID";
            this.Column42.HeaderText = "操作员ID";
            this.Column42.Name = "Column42";
            this.Column42.ReadOnly = true;
            this.Column42.Width = 78;
            // 
            // Column43
            // 
            this.Column43.DataPropertyName = "USERNAME";
            this.Column43.HeaderText = "操作员姓名";
            this.Column43.Name = "Column43";
            this.Column43.ReadOnly = true;
            this.Column43.Width = 90;
            // 
            // Column44
            // 
            this.Column44.DataPropertyName = "RECDATE";
            this.Column44.HeaderText = "制卡时间";
            this.Column44.Name = "Column44";
            this.Column44.ReadOnly = true;
            this.Column44.Width = 78;
            // 
            // Column45
            // 
            this.Column45.DataPropertyName = "STARTDATE";
            this.Column45.HeaderText = "启用日期";
            this.Column45.Name = "Column45";
            this.Column45.ReadOnly = true;
            this.Column45.Width = 78;
            // 
            // Column46
            // 
            this.Column46.DataPropertyName = "STARTPEOPLE";
            this.Column46.HeaderText = "启用人";
            this.Column46.Name = "Column46";
            this.Column46.ReadOnly = true;
            this.Column46.Width = 66;
            // 
            // Column47
            // 
            this.Column47.DataPropertyName = "BFDATE";
            this.Column47.HeaderText = "报废日期";
            this.Column47.Name = "Column47";
            this.Column47.ReadOnly = true;
            this.Column47.Width = 78;
            // 
            // Column48
            // 
            this.Column48.DataPropertyName = "BFPEOPLE";
            this.Column48.HeaderText = "报废人";
            this.Column48.Name = "Column48";
            this.Column48.ReadOnly = true;
            this.Column48.Width = 66;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "EQID";
            this.Column5.HeaderText = "设备ID";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 66;
            // 
            // EQChangeManag
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(983, 482);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "EQChangeManag";
            this.Text = "设备变动管理";
            this.Load += new System.EventHandler(this.EQChangeManag_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.EQKind_tab.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton Add_toolStrip;
        private System.Windows.Forms.ToolStripButton Edit_toolStrip;
        private System.Windows.Forms.ToolStripButton SubmitCheck_toolStrip;
        private System.Windows.Forms.ToolStripButton Submited_toolStrip;
        private System.Windows.Forms.ToolStripButton Del_toolStrip;
        private System.Windows.Forms.ToolStripButton View_toolStrip;
        private System.Windows.Forms.ToolStripButton refresh_toolStrip;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage EQKind_tab;
        private YtWinContrl.com.YtTreeView EQKind_ytTreeView;
        private System.Windows.Forms.GroupBox groupBox3;
        private YtWinContrl.com.datagrid.DataGView dataGView2;
        private YtWinContrl.com.datagrid.DataGView dataGView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewComboBoxColumn Status_Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn Statuscode_Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn Deptid_Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column29;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column30;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column31;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column32;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column34;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column35;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column36;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column37;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column38;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column40;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column42;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column43;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column44;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column45;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column46;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column47;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column48;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column39;
        private System.Windows.Forms.DataGridViewComboBoxColumn ChangeTypeColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn ChangeManagStatu_Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column65;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column50;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column41;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column57;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column53;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column54;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column52;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column58;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column56;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column60;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column61;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column62;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column70;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column71;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column55;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column59;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column72;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column49;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column51;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column64;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private YtWinContrl.com.contrl.DateTimeDuan dateTimeDuan1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;

    }
}