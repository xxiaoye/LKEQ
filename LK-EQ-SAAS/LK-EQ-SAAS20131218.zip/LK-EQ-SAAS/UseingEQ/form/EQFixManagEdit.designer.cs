﻿namespace UseingEQ.form
{
    partial class EQFixManagEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList2 = new YtWinContrl.com.datagrid.TvList();
            this.cancel_button = new System.Windows.Forms.Button();
            this.Save_button = new System.Windows.Forms.Button();
            this.OK_button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.PayDate_dateTime = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.repairMan_textBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Repairdate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.ChangeParts_textBox = new System.Windows.Forms.TextBox();
            this.RepairDeptId_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.label7 = new System.Windows.Forms.Label();
            this.RepairPass_textBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.RepairResult_textBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.RepairTime_textBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.CLfare_textBox = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.OtherFare_textBox = new System.Windows.Forms.TextBox();
            this.Repairfare_textBox = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Reportdate_dateTime = new System.Windows.Forms.DateTimePicker();
            this.repotruser_textBox = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.reportmanId_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.repaircode_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.FaultThing_textBox = new System.Windows.Forms.TextBox();
            this.Fault_textBox = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Status_ytComboBox1 = new YtWinContrl.com.contrl.YtComboBox();
            this.repairid_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.deptid_selTextInpt = new YtWinContrl.com.contrl.SelTextInpt();
            this.cardId_textBox = new YtWinContrl.com.contrl.SelTextInpt();
            this.Userid_textBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.choscode_textBox = new System.Windows.Forms.TextBox();
            this.Username_textBox = new System.Windows.Forms.TextBox();
            this.recdate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.memo_textBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // cancel_button
            // 
            this.cancel_button.Location = new System.Drawing.Point(718, 20);
            this.cancel_button.Name = "cancel_button";
            this.cancel_button.Size = new System.Drawing.Size(75, 23);
            this.cancel_button.TabIndex = 20;
            this.cancel_button.Text = "取消";
            this.cancel_button.UseVisualStyleBackColor = true;
            this.cancel_button.Click += new System.EventHandler(this.cancel_button_Click);
            // 
            // Save_button
            // 
            this.Save_button.Location = new System.Drawing.Point(191, 20);
            this.Save_button.Name = "Save_button";
            this.Save_button.Size = new System.Drawing.Size(75, 23);
            this.Save_button.TabIndex = 19;
            this.Save_button.Text = "保存";
            this.Save_button.UseVisualStyleBackColor = true;
            this.Save_button.Click += new System.EventHandler(this.Save_button_Click);
            // 
            // OK_button
            // 
            this.OK_button.Location = new System.Drawing.Point(465, 20);
            this.OK_button.Name = "OK_button";
            this.OK_button.Size = new System.Drawing.Size(75, 23);
            this.OK_button.TabIndex = 21;
            this.OK_button.Text = "确定";
            this.OK_button.UseVisualStyleBackColor = true;
            this.OK_button.Click += new System.EventHandler(this.OK_button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cancel_button);
            this.groupBox2.Controls.Add(this.Save_button);
            this.groupBox2.Controls.Add(this.OK_button);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Location = new System.Drawing.Point(0, 648);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1143, 76);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1143, 648);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.PayDate_dateTime);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(3, 572);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1137, 73);
            this.groupBox6.TabIndex = 25;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "交付信息";
            // 
            // PayDate_dateTime
            // 
            this.PayDate_dateTime.CustomFormat = "yyyy-MM-dd hh:mm:ss";
            this.PayDate_dateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.PayDate_dateTime.Location = new System.Drawing.Point(509, 29);
            this.PayDate_dateTime.Name = "PayDate_dateTime";
            this.PayDate_dateTime.Size = new System.Drawing.Size(154, 21);
            this.PayDate_dateTime.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(386, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 36;
            this.label5.Text = "交付日期";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.repairMan_textBox);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.Repairdate_dateTimePicker);
            this.groupBox5.Controls.Add(this.ChangeParts_textBox);
            this.groupBox5.Controls.Add(this.RepairDeptId_selText);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.RepairPass_textBox);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.RepairResult_textBox);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.RepairTime_textBox);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.CLfare_textBox);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.OtherFare_textBox);
            this.groupBox5.Controls.Add(this.Repairfare_textBox);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox5.Location = new System.Drawing.Point(3, 380);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1137, 192);
            this.groupBox5.TabIndex = 24;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "维修信息";
            // 
            // repairMan_textBox
            // 
            this.repairMan_textBox.Location = new System.Drawing.Point(142, 70);
            this.repairMan_textBox.Name = "repairMan_textBox";
            this.repairMan_textBox.Size = new System.Drawing.Size(149, 21);
            this.repairMan_textBox.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(40, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 40;
            this.label4.Text = "维修人";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(38, 110);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 30;
            this.label12.Text = "工时";
            // 
            // Repairdate_dateTimePicker
            // 
            this.Repairdate_dateTimePicker.CustomFormat = "yyyy-MM-dd hh:mm:ss";
            this.Repairdate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Repairdate_dateTimePicker.Location = new System.Drawing.Point(853, 110);
            this.Repairdate_dateTimePicker.Name = "Repairdate_dateTimePicker";
            this.Repairdate_dateTimePicker.Size = new System.Drawing.Size(159, 21);
            this.Repairdate_dateTimePicker.TabIndex = 17;
            // 
            // ChangeParts_textBox
            // 
            this.ChangeParts_textBox.Location = new System.Drawing.Point(858, 67);
            this.ChangeParts_textBox.Name = "ChangeParts_textBox";
            this.ChangeParts_textBox.Size = new System.Drawing.Size(152, 21);
            this.ChangeParts_textBox.TabIndex = 16;
            // 
            // RepairDeptId_selText
            // 
            this.RepairDeptId_selText.ColDefText = null;
            this.RepairDeptId_selText.ColStyle = null;
            this.RepairDeptId_selText.DataType = null;
            this.RepairDeptId_selText.DbConn = null;
            this.RepairDeptId_selText.Location = new System.Drawing.Point(142, 23);
            this.RepairDeptId_selText.Name = "RepairDeptId_selText";
            this.RepairDeptId_selText.NextFocusControl = null;
            this.RepairDeptId_selText.ReadOnly = false;
            this.RepairDeptId_selText.SelParam = null;
            this.RepairDeptId_selText.ShowColNum = 0;
            this.RepairDeptId_selText.ShowWidth = 0;
            this.RepairDeptId_selText.Size = new System.Drawing.Size(149, 22);
            this.RepairDeptId_selText.Sql = null;
            this.RepairDeptId_selText.SqlStr = null;
            this.RepairDeptId_selText.TabIndex = 8;
            this.RepairDeptId_selText.TvColName = null;
            this.RepairDeptId_selText.Value = null;
            this.RepairDeptId_selText.WatermarkText = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(770, 115);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 39;
            this.label7.Text = "维修日期";
            // 
            // RepairPass_textBox
            // 
            this.RepairPass_textBox.Location = new System.Drawing.Point(139, 151);
            this.RepairPass_textBox.Multiline = true;
            this.RepairPass_textBox.Name = "RepairPass_textBox";
            this.RepairPass_textBox.Size = new System.Drawing.Size(873, 21);
            this.RepairPass_textBox.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(28, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 37;
            this.label6.Text = "维修科室ID";
            // 
            // RepairResult_textBox
            // 
            this.RepairResult_textBox.Location = new System.Drawing.Point(855, 27);
            this.RepairResult_textBox.Name = "RepairResult_textBox";
            this.RepairResult_textBox.Size = new System.Drawing.Size(154, 21);
            this.RepairResult_textBox.TabIndex = 15;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Blue;
            this.label15.Location = new System.Drawing.Point(770, 30);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 64;
            this.label15.Text = "维修结果";
            // 
            // RepairTime_textBox
            // 
            this.RepairTime_textBox.Location = new System.Drawing.Point(142, 110);
            this.RepairTime_textBox.Name = "RepairTime_textBox";
            this.RepairTime_textBox.Size = new System.Drawing.Size(149, 21);
            this.RepairTime_textBox.TabIndex = 10;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Blue;
            this.label19.Location = new System.Drawing.Point(30, 160);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 63;
            this.label19.Text = "维修经过";
            // 
            // CLfare_textBox
            // 
            this.CLfare_textBox.Location = new System.Drawing.Point(509, 23);
            this.CLfare_textBox.Name = "CLfare_textBox";
            this.CLfare_textBox.Size = new System.Drawing.Size(154, 21);
            this.CLfare_textBox.TabIndex = 11;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Blue;
            this.label23.Location = new System.Drawing.Point(770, 70);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 67;
            this.label23.Text = "更换部件";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(410, 110);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 43;
            this.label10.Text = "其他";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(404, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 44;
            this.label8.Text = "材料费";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(409, 70);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 29;
            this.label9.Text = "维修费";
            // 
            // OtherFare_textBox
            // 
            this.OtherFare_textBox.Location = new System.Drawing.Point(511, 107);
            this.OtherFare_textBox.Name = "OtherFare_textBox";
            this.OtherFare_textBox.Size = new System.Drawing.Size(152, 21);
            this.OtherFare_textBox.TabIndex = 13;
            // 
            // Repairfare_textBox
            // 
            this.Repairfare_textBox.Location = new System.Drawing.Point(511, 61);
            this.Repairfare_textBox.Name = "Repairfare_textBox";
            this.Repairfare_textBox.Size = new System.Drawing.Size(152, 21);
            this.Repairfare_textBox.TabIndex = 12;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Reportdate_dateTime);
            this.groupBox4.Controls.Add(this.repotruser_textBox);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.reportmanId_selText);
            this.groupBox4.Controls.Add(this.repaircode_selText);
            this.groupBox4.Controls.Add(this.FaultThing_textBox);
            this.groupBox4.Controls.Add(this.Fault_textBox);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(3, 193);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1137, 187);
            this.groupBox4.TabIndex = 23;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "报修信息";
            // 
            // Reportdate_dateTime
            // 
            this.Reportdate_dateTime.CustomFormat = "yyyy-MM-dd hh:mm:ss";
            this.Reportdate_dateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Reportdate_dateTime.Location = new System.Drawing.Point(514, 32);
            this.Reportdate_dateTime.Name = "Reportdate_dateTime";
            this.Reportdate_dateTime.Size = new System.Drawing.Size(149, 21);
            this.Reportdate_dateTime.TabIndex = 3;
            // 
            // repotruser_textBox
            // 
            this.repotruser_textBox.Location = new System.Drawing.Point(853, 90);
            this.repotruser_textBox.Name = "repotruser_textBox";
            this.repotruser_textBox.Size = new System.Drawing.Size(154, 21);
            this.repotruser_textBox.TabIndex = 7;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Blue;
            this.label25.Location = new System.Drawing.Point(30, 36);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 69;
            this.label25.Text = "维修类别编码";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Blue;
            this.label21.Location = new System.Drawing.Point(773, 94);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 12);
            this.label21.TabIndex = 65;
            this.label21.Text = "报修人";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(770, 36);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 12);
            this.label26.TabIndex = 78;
            this.label26.Text = "报修人ID";
            // 
            // reportmanId_selText
            // 
            this.reportmanId_selText.ColDefText = null;
            this.reportmanId_selText.ColStyle = null;
            this.reportmanId_selText.DataType = null;
            this.reportmanId_selText.DbConn = null;
            this.reportmanId_selText.Location = new System.Drawing.Point(856, 33);
            this.reportmanId_selText.Name = "reportmanId_selText";
            this.reportmanId_selText.NextFocusControl = null;
            this.reportmanId_selText.ReadOnly = false;
            this.reportmanId_selText.SelParam = null;
            this.reportmanId_selText.ShowColNum = 0;
            this.reportmanId_selText.ShowWidth = 0;
            this.reportmanId_selText.Size = new System.Drawing.Size(151, 22);
            this.reportmanId_selText.Sql = null;
            this.reportmanId_selText.SqlStr = null;
            this.reportmanId_selText.TabIndex = 6;
            this.reportmanId_selText.TvColName = null;
            this.reportmanId_selText.Value = null;
            this.reportmanId_selText.WatermarkText = "";
            // 
            // repaircode_selText
            // 
            this.repaircode_selText.ColDefText = null;
            this.repaircode_selText.ColStyle = null;
            this.repaircode_selText.DataType = null;
            this.repaircode_selText.DbConn = null;
            this.repaircode_selText.Location = new System.Drawing.Point(140, 26);
            this.repaircode_selText.Name = "repaircode_selText";
            this.repaircode_selText.NextFocusControl = null;
            this.repaircode_selText.ReadOnly = false;
            this.repaircode_selText.SelParam = null;
            this.repaircode_selText.ShowColNum = 0;
            this.repaircode_selText.ShowWidth = 0;
            this.repaircode_selText.Size = new System.Drawing.Size(151, 22);
            this.repaircode_selText.Sql = null;
            this.repaircode_selText.SqlStr = null;
            this.repaircode_selText.TabIndex = 2;
            this.repaircode_selText.TvColName = null;
            this.repaircode_selText.Value = null;
            this.repaircode_selText.WatermarkText = "";
            // 
            // FaultThing_textBox
            // 
            this.FaultThing_textBox.Location = new System.Drawing.Point(137, 141);
            this.FaultThing_textBox.Name = "FaultThing_textBox";
            this.FaultThing_textBox.Size = new System.Drawing.Size(870, 21);
            this.FaultThing_textBox.TabIndex = 5;
            // 
            // Fault_textBox
            // 
            this.Fault_textBox.Location = new System.Drawing.Point(137, 85);
            this.Fault_textBox.Name = "Fault_textBox";
            this.Fault_textBox.Size = new System.Drawing.Size(526, 21);
            this.Fault_textBox.TabIndex = 4;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Blue;
            this.label22.Location = new System.Drawing.Point(28, 90);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 12);
            this.label22.TabIndex = 68;
            this.label22.Text = "故障现象";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.Blue;
            this.label24.Location = new System.Drawing.Point(396, 36);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 12);
            this.label24.TabIndex = 66;
            this.label24.Text = "报修日期";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Blue;
            this.label20.Location = new System.Drawing.Point(32, 144);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 62;
            this.label20.Text = "故障情况";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Status_ytComboBox1);
            this.groupBox3.Controls.Add(this.repairid_textBox);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.deptid_selTextInpt);
            this.groupBox3.Controls.Add(this.cardId_textBox);
            this.groupBox3.Controls.Add(this.Userid_textBox);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.choscode_textBox);
            this.groupBox3.Controls.Add(this.Username_textBox);
            this.groupBox3.Controls.Add(this.recdate_dateTimePicker);
            this.groupBox3.Controls.Add(this.memo_textBox);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(3, 17);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1137, 176);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "公共信息";
            // 
            // Status_ytComboBox1
            // 
            this.Status_ytComboBox1.CacheKey = null;
            this.Status_ytComboBox1.DbConn = null;
            this.Status_ytComboBox1.DefText = null;
            this.Status_ytComboBox1.DefValue = null;
            this.Status_ytComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Status_ytComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Status_ytComboBox1.EnableEmpty = true;
            this.Status_ytComboBox1.FirstText = null;
            this.Status_ytComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Status_ytComboBox1.Fomart = null;
            this.Status_ytComboBox1.ItemStr = "";
            this.Status_ytComboBox1.Location = new System.Drawing.Point(507, 105);
            this.Status_ytComboBox1.Name = "ytComboBox1";
            this.Status_ytComboBox1.Param = null;
            this.Status_ytComboBox1.Size = new System.Drawing.Size(155, 22);
            this.Status_ytComboBox1.Sql = null;
            this.Status_ytComboBox1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Status_ytComboBox1.TabIndex = 0;
            this.Status_ytComboBox1.Tag = tvList2;
            this.Status_ytComboBox1.Value = null;
            // 
            // repairid_textBox
            // 
            this.repairid_textBox.Location = new System.Drawing.Point(142, 24);
            this.repairid_textBox.Name = "repairid_textBox";
            this.repairid_textBox.ReadOnly = true;
            this.repairid_textBox.Size = new System.Drawing.Size(154, 21);
            this.repairid_textBox.TabIndex = 50;
            this.repairid_textBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(29, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 41;
            this.label1.Text = "卡片ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(32, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 42;
            this.label2.Text = "维修ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(30, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 45;
            this.label3.Text = "科室ID";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Blue;
            this.label16.Location = new System.Drawing.Point(402, 107);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 47;
            this.label16.Text = "状态";
            // 
            // deptid_selTextInpt
            // 
            this.deptid_selTextInpt.ColDefText = null;
            this.deptid_selTextInpt.ColStyle = null;
            this.deptid_selTextInpt.DataType = null;
            this.deptid_selTextInpt.DbConn = null;
            this.deptid_selTextInpt.Enabled = false;
            this.deptid_selTextInpt.Location = new System.Drawing.Point(140, 107);
            this.deptid_selTextInpt.Name = "deptid_selTextInpt";
            this.deptid_selTextInpt.NextFocusControl = null;
            this.deptid_selTextInpt.ReadOnly = false;
            this.deptid_selTextInpt.SelParam = null;
            this.deptid_selTextInpt.ShowColNum = 0;
            this.deptid_selTextInpt.ShowWidth = 0;
            this.deptid_selTextInpt.Size = new System.Drawing.Size(156, 22);
            this.deptid_selTextInpt.Sql = null;
            this.deptid_selTextInpt.SqlStr = null;
            this.deptid_selTextInpt.TabIndex = 35;
            this.deptid_selTextInpt.TabStop = false;
            this.deptid_selTextInpt.TvColName = null;
            this.deptid_selTextInpt.Value = null;
            this.deptid_selTextInpt.WatermarkText = "";
            // 
            // cardId_textBox
            // 
            this.cardId_textBox.ColDefText = null;
            this.cardId_textBox.ColStyle = null;
            this.cardId_textBox.DataType = null;
            this.cardId_textBox.DbConn = null;
            this.cardId_textBox.Enabled = false;
            this.cardId_textBox.Location = new System.Drawing.Point(140, 65);
            this.cardId_textBox.Name = "cardId_textBox";
            this.cardId_textBox.NextFocusControl = null;
            this.cardId_textBox.ReadOnly = false;
            this.cardId_textBox.SelParam = null;
            this.cardId_textBox.ShowColNum = 0;
            this.cardId_textBox.ShowWidth = 0;
            this.cardId_textBox.Size = new System.Drawing.Size(156, 22);
            this.cardId_textBox.Sql = null;
            this.cardId_textBox.SqlStr = null;
            this.cardId_textBox.TabIndex = 34;
            this.cardId_textBox.TabStop = false;
            this.cardId_textBox.TvColName = null;
            this.cardId_textBox.Value = null;
            this.cardId_textBox.WatermarkText = "";
            // 
            // Userid_textBox
            // 
            this.Userid_textBox.Location = new System.Drawing.Point(858, 26);
            this.Userid_textBox.Name = "Userid_textBox";
            this.Userid_textBox.ReadOnly = true;
            this.Userid_textBox.Size = new System.Drawing.Size(154, 21);
            this.Userid_textBox.TabIndex = 51;
            this.Userid_textBox.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(390, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 46;
            this.label13.Text = "操作员姓名";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(396, 67);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 31;
            this.label14.Text = "修改时间";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Blue;
            this.label17.Location = new System.Drawing.Point(750, 74);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 12);
            this.label17.TabIndex = 32;
            this.label17.Text = "医疗机构编码";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Blue;
            this.label18.Location = new System.Drawing.Point(758, 29);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 33;
            this.label18.Text = "操作员ID";
            // 
            // choscode_textBox
            // 
            this.choscode_textBox.Location = new System.Drawing.Point(856, 68);
            this.choscode_textBox.Name = "choscode_textBox";
            this.choscode_textBox.ReadOnly = true;
            this.choscode_textBox.Size = new System.Drawing.Size(156, 21);
            this.choscode_textBox.TabIndex = 53;
            this.choscode_textBox.TabStop = false;
            // 
            // Username_textBox
            // 
            this.Username_textBox.Location = new System.Drawing.Point(509, 24);
            this.Username_textBox.Name = "Username_textBox";
            this.Username_textBox.ReadOnly = true;
            this.Username_textBox.Size = new System.Drawing.Size(154, 21);
            this.Username_textBox.TabIndex = 49;
            this.Username_textBox.TabStop = false;
            // 
            // recdate_dateTimePicker
            // 
            this.recdate_dateTimePicker.CustomFormat = "yyyy-MM-dd hh:mm:ss";
            this.recdate_dateTimePicker.Enabled = false;
            this.recdate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.recdate_dateTimePicker.Location = new System.Drawing.Point(509, 65);
            this.recdate_dateTimePicker.Name = "recdate_dateTimePicker";
            this.recdate_dateTimePicker.Size = new System.Drawing.Size(154, 21);
            this.recdate_dateTimePicker.TabIndex = 55;
            this.recdate_dateTimePicker.TabStop = false;
            // 
            // memo_textBox
            // 
            this.memo_textBox.Location = new System.Drawing.Point(140, 141);
            this.memo_textBox.Name = "memo_textBox";
            this.memo_textBox.Size = new System.Drawing.Size(872, 21);
            this.memo_textBox.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 141);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 38;
            this.label11.Text = "备注";
            // 
            // EQFixManagEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 724);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "EQFixManagEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "设备维修单";
            this.Load += new System.EventHandler(this.EQFixManagEdit_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cancel_button;
        private System.Windows.Forms.Button Save_button;
        private System.Windows.Forms.Button OK_button;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label26;
        private YtWinContrl.com.contrl.SelTextInpt RepairDeptId_selText;
        private System.Windows.Forms.TextBox ChangeParts_textBox;
        private System.Windows.Forms.TextBox RepairPass_textBox;
        private System.Windows.Forms.TextBox RepairResult_textBox;
        private System.Windows.Forms.TextBox FaultThing_textBox;
        private System.Windows.Forms.TextBox Fault_textBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.DateTimePicker recdate_dateTimePicker;
        private System.Windows.Forms.DateTimePicker Repairdate_dateTimePicker;
        private YtWinContrl.com.contrl.SelTextInpt cardId_textBox;
        private YtWinContrl.com.contrl.SelTextInpt deptid_selTextInpt;
        private System.Windows.Forms.TextBox memo_textBox;
        private System.Windows.Forms.TextBox Username_textBox;
        private System.Windows.Forms.TextBox RepairTime_textBox;
        private System.Windows.Forms.TextBox OtherFare_textBox;
        private System.Windows.Forms.TextBox repairid_textBox;
        private System.Windows.Forms.TextBox repairMan_textBox;
        private System.Windows.Forms.TextBox repotruser_textBox;
        private System.Windows.Forms.TextBox Userid_textBox;
        private System.Windows.Forms.TextBox choscode_textBox;
        private System.Windows.Forms.TextBox Repairfare_textBox;
        private System.Windows.Forms.TextBox CLfare_textBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DateTimePicker Reportdate_dateTime;
        private System.Windows.Forms.DateTimePicker PayDate_dateTime;
        private YtWinContrl.com.contrl.YtComboBox Status_ytComboBox1;
        private YtWinContrl.com.contrl.SelTextInpt repaircode_selText;
        private YtWinContrl.com.contrl.SelTextInpt reportmanId_selText;
    }
}