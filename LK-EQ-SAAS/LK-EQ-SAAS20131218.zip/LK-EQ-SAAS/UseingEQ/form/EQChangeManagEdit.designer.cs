﻿namespace UseingEQ.form
{
    partial class EQChangeManagEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList1 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList2 = new YtWinContrl.com.datagrid.TvList();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Status_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.ChangeType_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.NewUseStatus_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.NewDeptid_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.OldDeptid_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.OldUseStatus_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.CardId_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.ChangeId_textBox = new System.Windows.Forms.TextBox();
            this.OldMan_textBox = new System.Windows.Forms.TextBox();
            this.SHdateTime = new System.Windows.Forms.TextBox();
            this.Recdate_dateTime = new System.Windows.Forms.TextBox();
            this.NewMan_textBox = new System.Windows.Forms.TextBox();
            this.OldYZ_textBox = new System.Windows.Forms.TextBox();
            this.UserName_textBox = new System.Windows.Forms.TextBox();
            this.NewYZ_textBox = new System.Windows.Forms.TextBox();
            this.SHUserName_textBox = new System.Windows.Forms.TextBox();
            this.UserId_textBox = new System.Windows.Forms.TextBox();
            this.Memo_textBox = new System.Windows.Forms.TextBox();
            this.SHUserId_textBox = new System.Windows.Forms.TextBox();
            this.Choscode_textBox = new System.Windows.Forms.TextBox();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.OkBtn = new System.Windows.Forms.Button();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Status_ytComboBox);
            this.groupBox1.Controls.Add(this.ChangeType_ytComboBox);
            this.groupBox1.Controls.Add(this.NewUseStatus_selText);
            this.groupBox1.Controls.Add(this.NewDeptid_selText);
            this.groupBox1.Controls.Add(this.OldDeptid_selText);
            this.groupBox1.Controls.Add(this.OldUseStatus_selText);
            this.groupBox1.Controls.Add(this.CardId_selText);
            this.groupBox1.Controls.Add(this.ChangeId_textBox);
            this.groupBox1.Controls.Add(this.OldMan_textBox);
            this.groupBox1.Controls.Add(this.SHdateTime);
            this.groupBox1.Controls.Add(this.Recdate_dateTime);
            this.groupBox1.Controls.Add(this.NewMan_textBox);
            this.groupBox1.Controls.Add(this.OldYZ_textBox);
            this.groupBox1.Controls.Add(this.UserName_textBox);
            this.groupBox1.Controls.Add(this.NewYZ_textBox);
            this.groupBox1.Controls.Add(this.SHUserName_textBox);
            this.groupBox1.Controls.Add(this.UserId_textBox);
            this.groupBox1.Controls.Add(this.Memo_textBox);
            this.groupBox1.Controls.Add(this.SHUserId_textBox);
            this.groupBox1.Controls.Add(this.Choscode_textBox);
            this.groupBox1.Controls.Add(this.CancelBtn);
            this.groupBox1.Controls.Add(this.OkBtn);
            this.groupBox1.Controls.Add(this.SaveBtn);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(906, 515);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "设备变动单详细信息";
            // 
            // Status_ytComboBox
            // 
            this.Status_ytComboBox.CacheKey = null;
            this.Status_ytComboBox.DbConn = null;
            this.Status_ytComboBox.DefText = null;
            this.Status_ytComboBox.DefValue = null;
            this.Status_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Status_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Status_ytComboBox.EnableEmpty = true;
            this.Status_ytComboBox.FirstText = null;
            this.Status_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Status_ytComboBox.Fomart = null;
            this.Status_ytComboBox.ItemStr = "";
            this.Status_ytComboBox.Location = new System.Drawing.Point(718, 37);
            this.Status_ytComboBox.Name = "Status_ytComboBox";
            this.Status_ytComboBox.Param = null;
            this.Status_ytComboBox.Size = new System.Drawing.Size(142, 22);
            this.Status_ytComboBox.Sql = null;
            this.Status_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Status_ytComboBox.TabIndex = 1;
            this.Status_ytComboBox.Tag = tvList1;
            this.Status_ytComboBox.Value = null;
            // 
            // ChangeType_ytComboBox
            // 
            this.ChangeType_ytComboBox.CacheKey = null;
            this.ChangeType_ytComboBox.DbConn = null;
            this.ChangeType_ytComboBox.DefText = null;
            this.ChangeType_ytComboBox.DefValue = null;
            this.ChangeType_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ChangeType_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ChangeType_ytComboBox.EnableEmpty = true;
            this.ChangeType_ytComboBox.FirstText = null;
            this.ChangeType_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangeType_ytComboBox.Fomart = null;
            this.ChangeType_ytComboBox.ItemStr = "";
            this.ChangeType_ytComboBox.Location = new System.Drawing.Point(440, 37);
            this.ChangeType_ytComboBox.Name = "ChangeType_ytComboBox";
            this.ChangeType_ytComboBox.Param = null;
            this.ChangeType_ytComboBox.Size = new System.Drawing.Size(142, 22);
            this.ChangeType_ytComboBox.Sql = null;
            this.ChangeType_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ChangeType_ytComboBox.TabIndex = 0;
            this.ChangeType_ytComboBox.Tag = tvList2;
            this.ChangeType_ytComboBox.Value = null;
            // 
            // NewUseStatus_selText
            // 
            this.NewUseStatus_selText.ColDefText = null;
            this.NewUseStatus_selText.ColStyle = null;
            this.NewUseStatus_selText.DataType = null;
            this.NewUseStatus_selText.DbConn = null;
            this.NewUseStatus_selText.Location = new System.Drawing.Point(134, 215);
            this.NewUseStatus_selText.Name = "NewUseStatus_selText";
            this.NewUseStatus_selText.NextFocusControl = null;
            this.NewUseStatus_selText.ReadOnly = false;
            this.NewUseStatus_selText.SelParam = null;
            this.NewUseStatus_selText.ShowColNum = 0;
            this.NewUseStatus_selText.ShowWidth = 0;
            this.NewUseStatus_selText.Size = new System.Drawing.Size(141, 22);
            this.NewUseStatus_selText.Sql = null;
            this.NewUseStatus_selText.SqlStr = null;
            this.NewUseStatus_selText.TabIndex = 3;
            this.NewUseStatus_selText.TvColName = null;
            this.NewUseStatus_selText.Value = null;
            this.NewUseStatus_selText.WatermarkText = "";
            // 
            // NewDeptid_selText
            // 
            this.NewDeptid_selText.ColDefText = null;
            this.NewDeptid_selText.ColStyle = null;
            this.NewDeptid_selText.DataType = null;
            this.NewDeptid_selText.DbConn = null;
            this.NewDeptid_selText.Location = new System.Drawing.Point(446, 214);
            this.NewDeptid_selText.Name = "NewDeptid_selText";
            this.NewDeptid_selText.NextFocusControl = null;
            this.NewDeptid_selText.ReadOnly = false;
            this.NewDeptid_selText.SelParam = null;
            this.NewDeptid_selText.ShowColNum = 0;
            this.NewDeptid_selText.ShowWidth = 0;
            this.NewDeptid_selText.Size = new System.Drawing.Size(141, 22);
            this.NewDeptid_selText.Sql = null;
            this.NewDeptid_selText.SqlStr = null;
            this.NewDeptid_selText.TabIndex = 4;
            this.NewDeptid_selText.TvColName = null;
            this.NewDeptid_selText.Value = null;
            this.NewDeptid_selText.WatermarkText = "";
            // 
            // OldDeptid_selText
            // 
            this.OldDeptid_selText.ColDefText = null;
            this.OldDeptid_selText.ColStyle = null;
            this.OldDeptid_selText.DataType = null;
            this.OldDeptid_selText.DbConn = null;
            this.OldDeptid_selText.Location = new System.Drawing.Point(446, 155);
            this.OldDeptid_selText.Name = "OldDeptid_selText";
            this.OldDeptid_selText.NextFocusControl = null;
            this.OldDeptid_selText.ReadOnly = true;
            this.OldDeptid_selText.SelParam = null;
            this.OldDeptid_selText.ShowColNum = 0;
            this.OldDeptid_selText.ShowWidth = 0;
            this.OldDeptid_selText.Size = new System.Drawing.Size(141, 22);
            this.OldDeptid_selText.Sql = null;
            this.OldDeptid_selText.SqlStr = null;
            this.OldDeptid_selText.TabIndex = 39;
            this.OldDeptid_selText.TabStop = false;
            this.OldDeptid_selText.TvColName = null;
            this.OldDeptid_selText.Value = null;
            this.OldDeptid_selText.WatermarkText = "";
            // 
            // OldUseStatus_selText
            // 
            this.OldUseStatus_selText.ColDefText = null;
            this.OldUseStatus_selText.ColStyle = null;
            this.OldUseStatus_selText.DataType = null;
            this.OldUseStatus_selText.DbConn = null;
            this.OldUseStatus_selText.Location = new System.Drawing.Point(134, 155);
            this.OldUseStatus_selText.Name = "OldUseStatus_selText";
            this.OldUseStatus_selText.NextFocusControl = null;
            this.OldUseStatus_selText.ReadOnly = true;
            this.OldUseStatus_selText.SelParam = null;
            this.OldUseStatus_selText.ShowColNum = 0;
            this.OldUseStatus_selText.ShowWidth = 0;
            this.OldUseStatus_selText.Size = new System.Drawing.Size(141, 22);
            this.OldUseStatus_selText.Sql = null;
            this.OldUseStatus_selText.SqlStr = null;
            this.OldUseStatus_selText.TabIndex = 40;
            this.OldUseStatus_selText.TabStop = false;
            this.OldUseStatus_selText.TvColName = null;
            this.OldUseStatus_selText.Value = null;
            this.OldUseStatus_selText.WatermarkText = "";
            // 
            // CardId_selText
            // 
            this.CardId_selText.ColDefText = null;
            this.CardId_selText.ColStyle = null;
            this.CardId_selText.DataType = null;
            this.CardId_selText.DbConn = null;
            this.CardId_selText.Location = new System.Drawing.Point(134, 94);
            this.CardId_selText.Name = "CardId_selText";
            this.CardId_selText.NextFocusControl = null;
            this.CardId_selText.ReadOnly = true;
            this.CardId_selText.SelParam = null;
            this.CardId_selText.ShowColNum = 0;
            this.CardId_selText.ShowWidth = 0;
            this.CardId_selText.Size = new System.Drawing.Size(141, 22);
            this.CardId_selText.Sql = null;
            this.CardId_selText.SqlStr = null;
            this.CardId_selText.TabIndex = 41;
            this.CardId_selText.TabStop = false;
            this.CardId_selText.TvColName = null;
            this.CardId_selText.Value = null;
            this.CardId_selText.WatermarkText = "";
            // 
            // ChangeId_textBox
            // 
            this.ChangeId_textBox.Location = new System.Drawing.Point(134, 36);
            this.ChangeId_textBox.Name = "ChangeId_textBox";
            this.ChangeId_textBox.ReadOnly = true;
            this.ChangeId_textBox.Size = new System.Drawing.Size(141, 21);
            this.ChangeId_textBox.TabIndex = 32;
            this.ChangeId_textBox.TabStop = false;
            // 
            // OldMan_textBox
            // 
            this.OldMan_textBox.Location = new System.Drawing.Point(723, 156);
            this.OldMan_textBox.Name = "OldMan_textBox";
            this.OldMan_textBox.ReadOnly = true;
            this.OldMan_textBox.Size = new System.Drawing.Size(143, 21);
            this.OldMan_textBox.TabIndex = 31;
            this.OldMan_textBox.TabStop = false;
            // 
            // SHdateTime
            // 
            this.SHdateTime.Location = new System.Drawing.Point(724, 336);
            this.SHdateTime.Name = "SHdateTime";
            this.SHdateTime.ReadOnly = true;
            this.SHdateTime.Size = new System.Drawing.Size(143, 21);
            this.SHdateTime.TabIndex = 46;
            this.SHdateTime.TabStop = false;
            // 
            // Recdate_dateTime
            // 
            this.Recdate_dateTime.Location = new System.Drawing.Point(723, 276);
            this.Recdate_dateTime.Name = "Recdate_dateTime";
            this.Recdate_dateTime.ReadOnly = true;
            this.Recdate_dateTime.Size = new System.Drawing.Size(143, 21);
            this.Recdate_dateTime.TabIndex = 46;
            this.Recdate_dateTime.TabStop = false;
            // 
            // NewMan_textBox
            // 
            this.NewMan_textBox.Location = new System.Drawing.Point(723, 215);
            this.NewMan_textBox.Name = "NewMan_textBox";
            this.NewMan_textBox.Size = new System.Drawing.Size(143, 21);
            this.NewMan_textBox.TabIndex = 5;
            // 
            // OldYZ_textBox
            // 
            this.OldYZ_textBox.Location = new System.Drawing.Point(446, 94);
            this.OldYZ_textBox.Name = "OldYZ_textBox";
            this.OldYZ_textBox.ReadOnly = true;
            this.OldYZ_textBox.Size = new System.Drawing.Size(141, 21);
            this.OldYZ_textBox.TabIndex = 38;
            this.OldYZ_textBox.TabStop = false;
            // 
            // UserName_textBox
            // 
            this.UserName_textBox.Location = new System.Drawing.Point(446, 276);
            this.UserName_textBox.Name = "UserName_textBox";
            this.UserName_textBox.ReadOnly = true;
            this.UserName_textBox.Size = new System.Drawing.Size(141, 21);
            this.UserName_textBox.TabIndex = 37;
            this.UserName_textBox.TabStop = false;
            // 
            // NewYZ_textBox
            // 
            this.NewYZ_textBox.Location = new System.Drawing.Point(724, 95);
            this.NewYZ_textBox.Name = "NewYZ_textBox";
            this.NewYZ_textBox.Size = new System.Drawing.Size(142, 21);
            this.NewYZ_textBox.TabIndex = 2;
            // 
            // SHUserName_textBox
            // 
            this.SHUserName_textBox.Location = new System.Drawing.Point(446, 337);
            this.SHUserName_textBox.Name = "SHUserName_textBox";
            this.SHUserName_textBox.ReadOnly = true;
            this.SHUserName_textBox.Size = new System.Drawing.Size(141, 21);
            this.SHUserName_textBox.TabIndex = 36;
            this.SHUserName_textBox.TabStop = false;
            // 
            // UserId_textBox
            // 
            this.UserId_textBox.Location = new System.Drawing.Point(134, 276);
            this.UserId_textBox.Name = "UserId_textBox";
            this.UserId_textBox.ReadOnly = true;
            this.UserId_textBox.Size = new System.Drawing.Size(141, 21);
            this.UserId_textBox.TabIndex = 34;
            this.UserId_textBox.TabStop = false;
            // 
            // Memo_textBox
            // 
            this.Memo_textBox.Location = new System.Drawing.Point(446, 396);
            this.Memo_textBox.Multiline = true;
            this.Memo_textBox.Name = "Memo_textBox";
            this.Memo_textBox.Size = new System.Drawing.Size(420, 21);
            this.Memo_textBox.TabIndex = 6;
            // 
            // SHUserId_textBox
            // 
            this.SHUserId_textBox.Location = new System.Drawing.Point(134, 335);
            this.SHUserId_textBox.Name = "SHUserId_textBox";
            this.SHUserId_textBox.ReadOnly = true;
            this.SHUserId_textBox.Size = new System.Drawing.Size(141, 21);
            this.SHUserId_textBox.TabIndex = 30;
            this.SHUserId_textBox.TabStop = false;
            // 
            // Choscode_textBox
            // 
            this.Choscode_textBox.Location = new System.Drawing.Point(134, 396);
            this.Choscode_textBox.Name = "Choscode_textBox";
            this.Choscode_textBox.ReadOnly = true;
            this.Choscode_textBox.Size = new System.Drawing.Size(141, 21);
            this.Choscode_textBox.TabIndex = 35;
            this.Choscode_textBox.TabStop = false;
            // 
            // CancelBtn
            // 
            this.CancelBtn.Location = new System.Drawing.Point(570, 455);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(75, 23);
            this.CancelBtn.TabIndex = 9;
            this.CancelBtn.Text = "取消";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // OkBtn
            // 
            this.OkBtn.Location = new System.Drawing.Point(371, 455);
            this.OkBtn.Name = "OkBtn";
            this.OkBtn.Size = new System.Drawing.Size(75, 23);
            this.OkBtn.TabIndex = 8;
            this.OkBtn.Text = "确定";
            this.OkBtn.UseVisualStyleBackColor = true;
            this.OkBtn.Click += new System.EventHandler(this.OkBtn_Click);
            // 
            // SaveBtn
            // 
            this.SaveBtn.Location = new System.Drawing.Point(184, 455);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(75, 23);
            this.SaveBtn.TabIndex = 7;
            this.SaveBtn.Text = "保存";
            this.SaveBtn.UseVisualStyleBackColor = true;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Blue;
            this.label20.Location = new System.Drawing.Point(648, 339);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 10;
            this.label20.Text = "审核时间";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Blue;
            this.label15.Location = new System.Drawing.Point(50, 279);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 11;
            this.label15.Text = "操作员ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(41, 159);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 12;
            this.label10.Text = "原使用状态";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(648, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 17;
            this.label5.Text = "原保管员";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Blue;
            this.label19.Location = new System.Drawing.Point(345, 339);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 12);
            this.label19.TabIndex = 22;
            this.label19.Text = "审核操作员姓名";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Blue;
            this.label18.Location = new System.Drawing.Point(41, 339);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 12);
            this.label18.TabIndex = 23;
            this.label18.Text = "审核操作员ID";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(41, 399);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 12);
            this.label14.TabIndex = 24;
            this.label14.Text = "医疗机构编码";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(654, 39);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 21;
            this.label13.Text = "状态";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(636, 99);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 18;
            this.label9.Text = "调整后原值";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Blue;
            this.label17.Location = new System.Drawing.Point(648, 279);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 19;
            this.label17.Text = "修改时间";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(364, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 20;
            this.label8.Text = "调整前原值";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(377, 399);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 14;
            this.label12.Text = "备注";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(359, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 13;
            this.label4.Text = "原使用科室";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Blue;
            this.label16.Location = new System.Drawing.Point(359, 279);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 12);
            this.label16.TabIndex = 16;
            this.label16.Text = "操作员姓名";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(648, 219);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 15;
            this.label7.Text = "现保管员";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.Location = new System.Drawing.Point(41, 219);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 25;
            this.label11.Text = "现使用状态";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(364, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 27;
            this.label3.Text = "变动类型";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(359, 219);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 28;
            this.label6.Text = "现使用科室";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(50, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 26;
            this.label2.Text = "卡片ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(50, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 29;
            this.label1.Text = "变动ID";
            // 
            // EQChangeManagEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 515);
            this.Controls.Add(this.groupBox1);
            this.Name = "EQChangeManagEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "设备变动单";
            this.Load += new System.EventHandler(this.EQChangeManagEdit_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private YtWinContrl.com.contrl.SelTextInpt NewUseStatus_selText;
        private YtWinContrl.com.contrl.SelTextInpt NewDeptid_selText;
        private YtWinContrl.com.contrl.SelTextInpt OldDeptid_selText;
        private YtWinContrl.com.contrl.SelTextInpt OldUseStatus_selText;
        private YtWinContrl.com.contrl.SelTextInpt CardId_selText;
        private System.Windows.Forms.TextBox ChangeId_textBox;
        private System.Windows.Forms.TextBox OldMan_textBox;
        private System.Windows.Forms.TextBox NewMan_textBox;
        private System.Windows.Forms.TextBox OldYZ_textBox;
        private System.Windows.Forms.TextBox UserName_textBox;
        private System.Windows.Forms.TextBox NewYZ_textBox;
        private System.Windows.Forms.TextBox SHUserName_textBox;
        private System.Windows.Forms.TextBox UserId_textBox;
        private System.Windows.Forms.TextBox Memo_textBox;
        private System.Windows.Forms.TextBox SHUserId_textBox;
        private System.Windows.Forms.TextBox Choscode_textBox;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.Button OkBtn;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private YtWinContrl.com.contrl.YtComboBox Status_ytComboBox;
        private YtWinContrl.com.contrl.YtComboBox ChangeType_ytComboBox;
        private System.Windows.Forms.TextBox Recdate_dateTime;
        private System.Windows.Forms.TextBox SHdateTime;

    }
}