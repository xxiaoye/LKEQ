﻿namespace UseingEQ.form
{
    partial class EQCheckManagEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList6 = new YtWinContrl.com.datagrid.TvList();
            this.Save_button = new System.Windows.Forms.Button();
            this.cancel_button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox_CheckUnit = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker_CheckDate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.CheckThing_textBox = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.CHECKRESULT_textBox = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.CheckPeople_textBox = new System.Windows.Forms.TextBox();
            this.NextCheckdate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label27 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Status_ytComboBox1 = new YtWinContrl.com.contrl.YtComboBox();
            this.Checkid_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.deptid_selTextInpt = new YtWinContrl.com.contrl.SelTextInpt();
            this.cardId_textBox = new YtWinContrl.com.contrl.SelTextInpt();
            this.Userid_textBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.choscode_textBox = new System.Windows.Forms.TextBox();
            this.Username_textBox = new System.Windows.Forms.TextBox();
            this.recdate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.memo_textBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Save_button
            // 
            this.Save_button.Location = new System.Drawing.Point(342, 20);
            this.Save_button.Name = "Save_button";
            this.Save_button.Size = new System.Drawing.Size(75, 23);
            this.Save_button.TabIndex = 15;
            this.Save_button.Text = "保存";
            this.Save_button.UseVisualStyleBackColor = true;
            this.Save_button.Click += new System.EventHandler(this.Save_button_Click);
            // 
            // cancel_button
            // 
            this.cancel_button.Location = new System.Drawing.Point(678, 20);
            this.cancel_button.Name = "cancel_button";
            this.cancel_button.Size = new System.Drawing.Size(75, 23);
            this.cancel_button.TabIndex = 16;
            this.cancel_button.Text = "取消";
            this.cancel_button.UseVisualStyleBackColor = true;
            this.cancel_button.Click += new System.EventHandler(this.cancel_button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cancel_button);
            this.groupBox2.Controls.Add(this.Save_button);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Location = new System.Drawing.Point(0, 279);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(907, 71);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox_CheckUnit);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.dateTimePicker_CheckDate);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.CheckThing_textBox);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.CHECKRESULT_textBox);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.CheckPeople_textBox);
            this.groupBox3.Controls.Add(this.NextCheckdate_dateTimePicker);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.Status_ytComboBox1);
            this.groupBox3.Controls.Add(this.Checkid_textBox);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.deptid_selTextInpt);
            this.groupBox3.Controls.Add(this.cardId_textBox);
            this.groupBox3.Controls.Add(this.Userid_textBox);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.choscode_textBox);
            this.groupBox3.Controls.Add(this.Username_textBox);
            this.groupBox3.Controls.Add(this.recdate_dateTimePicker);
            this.groupBox3.Controls.Add(this.memo_textBox);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(907, 289);
            this.groupBox3.TabIndex = 27;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "公共信息";
            // 
            // textBox_CheckUnit
            // 
            this.textBox_CheckUnit.Location = new System.Drawing.Point(429, 91);
            this.textBox_CheckUnit.Name = "textBox_CheckUnit";
            this.textBox_CheckUnit.Size = new System.Drawing.Size(154, 21);
            this.textBox_CheckUnit.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(359, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 91;
            this.label5.Text = "检查单位";
            // 
            // dateTimePicker_CheckDate
            // 
            this.dateTimePicker_CheckDate.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker_CheckDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_CheckDate.Location = new System.Drawing.Point(731, 57);
            this.dateTimePicker_CheckDate.Name = "dateTimePicker_CheckDate";
            this.dateTimePicker_CheckDate.Size = new System.Drawing.Size(154, 21);
            this.dateTimePicker_CheckDate.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(639, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 89;
            this.label4.Text = "检查日期";
            // 
            // CheckThing_textBox
            // 
            this.CheckThing_textBox.Location = new System.Drawing.Point(141, 157);
            this.CheckThing_textBox.Name = "CheckThing_textBox";
            this.CheckThing_textBox.Size = new System.Drawing.Size(743, 21);
            this.CheckThing_textBox.TabIndex = 12;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(55, 160);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 87;
            this.label23.Text = "简要记录";
            // 
            // CHECKRESULT_textBox
            // 
            this.CHECKRESULT_textBox.Location = new System.Drawing.Point(139, 223);
            this.CHECKRESULT_textBox.Multiline = true;
            this.CHECKRESULT_textBox.Name = "CHECKRESULT_textBox";
            this.CHECKRESULT_textBox.Size = new System.Drawing.Size(747, 42);
            this.CHECKRESULT_textBox.TabIndex = 14;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(47, 226);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 83;
            this.label20.Text = "检查结论";
            // 
            // CheckPeople_textBox
            // 
            this.CheckPeople_textBox.Location = new System.Drawing.Point(429, 57);
            this.CheckPeople_textBox.Name = "CheckPeople_textBox";
            this.CheckPeople_textBox.Size = new System.Drawing.Size(154, 21);
            this.CheckPeople_textBox.TabIndex = 4;
            // 
            // NextCheckdate_dateTimePicker
            // 
            this.NextCheckdate_dateTimePicker.CustomFormat = "yyyy-MM-dd ";
            this.NextCheckdate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.NextCheckdate_dateTimePicker.Location = new System.Drawing.Point(731, 93);
            this.NextCheckdate_dateTimePicker.Name = "NextCheckdate_dateTimePicker";
            this.NextCheckdate_dateTimePicker.Size = new System.Drawing.Size(154, 21);
            this.NextCheckdate_dateTimePicker.TabIndex = 8;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.Color.Blue;
            this.label27.Location = new System.Drawing.Point(359, 59);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 12);
            this.label27.TabIndex = 79;
            this.label27.Text = "检查人";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(628, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 12);
            this.label7.TabIndex = 39;
            this.label7.Text = "下次检定日期";
            // 
            // Status_ytComboBox1
            // 
            this.Status_ytComboBox1.CacheKey = null;
            this.Status_ytComboBox1.DbConn = null;
            this.Status_ytComboBox1.DefText = null;
            this.Status_ytComboBox1.DefValue = null;
            this.Status_ytComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Status_ytComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Status_ytComboBox1.EnableEmpty = true;
            this.Status_ytComboBox1.FirstText = null;
            this.Status_ytComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Status_ytComboBox1.Fomart = null;
            this.Status_ytComboBox1.ItemStr = "";
            this.Status_ytComboBox1.Location = new System.Drawing.Point(429, 22);
            this.Status_ytComboBox1.Name = "ytComboBox1";
            this.Status_ytComboBox1.Param = null;
            this.Status_ytComboBox1.Size = new System.Drawing.Size(154, 22);
            this.Status_ytComboBox1.Sql = null;
            this.Status_ytComboBox1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Status_ytComboBox1.TabIndex = 1;
            this.Status_ytComboBox1.Tag = tvList6;
            this.Status_ytComboBox1.Value = null;
            // 
            // Checkid_textBox
            // 
            this.Checkid_textBox.Location = new System.Drawing.Point(140, 24);
            this.Checkid_textBox.Name = "Checkid_textBox";
            this.Checkid_textBox.ReadOnly = true;
            this.Checkid_textBox.Size = new System.Drawing.Size(154, 21);
            this.Checkid_textBox.TabIndex = 0;
            this.Checkid_textBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(61, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 41;
            this.label1.Text = "卡片ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(63, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 42;
            this.label2.Text = "检查ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(61, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 45;
            this.label3.Text = "科室";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Blue;
            this.label16.Location = new System.Drawing.Point(368, 24);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 47;
            this.label16.Text = "状态";
            // 
            // deptid_selTextInpt
            // 
            this.deptid_selTextInpt.ColDefText = null;
            this.deptid_selTextInpt.ColStyle = null;
            this.deptid_selTextInpt.DataType = null;
            this.deptid_selTextInpt.DbConn = null;
            this.deptid_selTextInpt.Enabled = false;
            this.deptid_selTextInpt.Location = new System.Drawing.Point(140, 91);
            this.deptid_selTextInpt.Name = "deptid_selTextInpt";
            this.deptid_selTextInpt.NextFocusControl = null;
            this.deptid_selTextInpt.ReadOnly = false;
            this.deptid_selTextInpt.SelParam = null;
            this.deptid_selTextInpt.ShowColNum = 0;
            this.deptid_selTextInpt.ShowWidth = 0;
            this.deptid_selTextInpt.Size = new System.Drawing.Size(154, 22);
            this.deptid_selTextInpt.Sql = null;
            this.deptid_selTextInpt.SqlStr = null;
            this.deptid_selTextInpt.TabIndex = 6;
            this.deptid_selTextInpt.TabStop = false;
            this.deptid_selTextInpt.TvColName = null;
            this.deptid_selTextInpt.Value = null;
            this.deptid_selTextInpt.WatermarkText = "";
            // 
            // cardId_textBox
            // 
            this.cardId_textBox.ColDefText = null;
            this.cardId_textBox.ColStyle = null;
            this.cardId_textBox.DataType = null;
            this.cardId_textBox.DbConn = null;
            this.cardId_textBox.Enabled = false;
            this.cardId_textBox.Location = new System.Drawing.Point(141, 59);
            this.cardId_textBox.Name = "cardId_textBox";
            this.cardId_textBox.NextFocusControl = null;
            this.cardId_textBox.ReadOnly = false;
            this.cardId_textBox.SelParam = null;
            this.cardId_textBox.ShowColNum = 0;
            this.cardId_textBox.ShowWidth = 0;
            this.cardId_textBox.Size = new System.Drawing.Size(154, 21);
            this.cardId_textBox.Sql = null;
            this.cardId_textBox.SqlStr = null;
            this.cardId_textBox.TabIndex = 3;
            this.cardId_textBox.TabStop = false;
            this.cardId_textBox.TvColName = null;
            this.cardId_textBox.Value = null;
            this.cardId_textBox.WatermarkText = "";
            // 
            // Userid_textBox
            // 
            this.Userid_textBox.Location = new System.Drawing.Point(429, 127);
            this.Userid_textBox.Name = "Userid_textBox";
            this.Userid_textBox.ReadOnly = true;
            this.Userid_textBox.Size = new System.Drawing.Size(154, 21);
            this.Userid_textBox.TabIndex = 10;
            this.Userid_textBox.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(46, 132);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 46;
            this.label13.Text = "操作员姓名";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(639, 28);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 31;
            this.label14.Text = "修改时间";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Blue;
            this.label17.Location = new System.Drawing.Point(632, 129);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 12);
            this.label17.TabIndex = 32;
            this.label17.Text = "医疗机构编码";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Blue;
            this.label18.Location = new System.Drawing.Point(355, 132);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 33;
            this.label18.Text = "操作员ID";
            // 
            // choscode_textBox
            // 
            this.choscode_textBox.Location = new System.Drawing.Point(731, 124);
            this.choscode_textBox.Name = "choscode_textBox";
            this.choscode_textBox.ReadOnly = true;
            this.choscode_textBox.Size = new System.Drawing.Size(154, 21);
            this.choscode_textBox.TabIndex = 11;
            this.choscode_textBox.TabStop = false;
            // 
            // Username_textBox
            // 
            this.Username_textBox.Location = new System.Drawing.Point(139, 126);
            this.Username_textBox.Name = "Username_textBox";
            this.Username_textBox.ReadOnly = true;
            this.Username_textBox.Size = new System.Drawing.Size(154, 21);
            this.Username_textBox.TabIndex = 9;
            this.Username_textBox.TabStop = false;
            // 
            // recdate_dateTimePicker
            // 
            this.recdate_dateTimePicker.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.recdate_dateTimePicker.Enabled = false;
            this.recdate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.recdate_dateTimePicker.Location = new System.Drawing.Point(730, 24);
            this.recdate_dateTimePicker.Name = "recdate_dateTimePicker";
            this.recdate_dateTimePicker.Size = new System.Drawing.Size(154, 21);
            this.recdate_dateTimePicker.TabIndex = 2;
            this.recdate_dateTimePicker.TabStop = false;
            // 
            // memo_textBox
            // 
            this.memo_textBox.Location = new System.Drawing.Point(140, 191);
            this.memo_textBox.Name = "memo_textBox";
            this.memo_textBox.Size = new System.Drawing.Size(745, 21);
            this.memo_textBox.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(68, 194);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 38;
            this.label11.Text = "备注";
            // 
            // EQCheckManagEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(907, 350);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Name = "EQCheckManagEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "设备检查单";
            this.Load += new System.EventHandler(this.EQCheckManagEdit_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Save_button;
        private System.Windows.Forms.Button cancel_button;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox CheckThing_textBox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox CHECKRESULT_textBox;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox CheckPeople_textBox;
        private System.Windows.Forms.DateTimePicker NextCheckdate_dateTimePicker;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label7;
        private YtWinContrl.com.contrl.YtComboBox Status_ytComboBox1;
        private System.Windows.Forms.TextBox Checkid_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label16;
        private YtWinContrl.com.contrl.SelTextInpt deptid_selTextInpt;
        private YtWinContrl.com.contrl.SelTextInpt cardId_textBox;
        private System.Windows.Forms.TextBox Userid_textBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox choscode_textBox;
        private System.Windows.Forms.TextBox Username_textBox;
        private System.Windows.Forms.DateTimePicker recdate_dateTimePicker;
        private System.Windows.Forms.TextBox memo_textBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dateTimePicker_CheckDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_CheckUnit;
        private System.Windows.Forms.Label label5;

    }
}