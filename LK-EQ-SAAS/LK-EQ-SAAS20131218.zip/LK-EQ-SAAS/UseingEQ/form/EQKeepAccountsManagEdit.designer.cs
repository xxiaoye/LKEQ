﻿namespace UseingEQ.form
{
    partial class EQKeepAccountsManagEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EQKeepAccountsManagEdit));
            YtWinContrl.com.datagrid.TvList tvList2 = new YtWinContrl.com.datagrid.TvList();
            this.Save_button = new System.Windows.Forms.Button();
            this.cancel_button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStrip_JDPass = new System.Windows.Forms.ToolStripButton();
            this.toolStrip_JDNo = new System.Windows.Forms.ToolStripButton();
            this.toolStrip_SHPass = new System.Windows.Forms.ToolStripButton();
            this.toolStrip_SHNo = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TipStatus_toolStrip = new System.Windows.Forms.ToolStripLabel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox_SHUSERID = new System.Windows.Forms.TextBox();
            this.textBox_SHMAN = new System.Windows.Forms.TextBox();
            this.textBox_JDUSERID = new System.Windows.Forms.TextBox();
            this.textBox_JDMAN = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dateTimePicker_SHDATE = new System.Windows.Forms.DateTimePicker();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox_SHADVICE = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker_JDDATE = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_JDADVICE = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.repotruserId_textBox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.reportman_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.QLFARE_textBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.CVALUE_textBox = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.IOID_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.dateTimePicker_REPORTDATE = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.NOREASON_textBox = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.Status_ytComboBox1 = new YtWinContrl.com.contrl.YtComboBox();
            this.NOID_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.deptid_selTextInpt = new YtWinContrl.com.contrl.SelTextInpt();
            this.cardId_textBox = new YtWinContrl.com.contrl.SelTextInpt();
            this.Userid_textBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.choscode_textBox = new System.Windows.Forms.TextBox();
            this.Username_textBox = new System.Windows.Forms.TextBox();
            this.recdate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.memo_textBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Save_button
            // 
            this.Save_button.Location = new System.Drawing.Point(295, 20);
            this.Save_button.Name = "Save_button";
            this.Save_button.Size = new System.Drawing.Size(75, 23);
            this.Save_button.TabIndex = 24;
            this.Save_button.Text = "保存";
            this.Save_button.UseVisualStyleBackColor = true;
            this.Save_button.Click += new System.EventHandler(this.Save_button_Click);
            // 
            // cancel_button
            // 
            this.cancel_button.Location = new System.Drawing.Point(678, 20);
            this.cancel_button.Name = "cancel_button";
            this.cancel_button.Size = new System.Drawing.Size(75, 23);
            this.cancel_button.TabIndex = 25;
            this.cancel_button.Text = "取消";
            this.cancel_button.UseVisualStyleBackColor = true;
            this.cancel_button.Click += new System.EventHandler(this.cancel_button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cancel_button);
            this.groupBox2.Controls.Add(this.Save_button);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Location = new System.Drawing.Point(0, 546);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(907, 63);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStrip_JDPass,
            this.toolStrip_JDNo,
            this.toolStrip_SHPass,
            this.toolStrip_SHNo,
            this.toolStripSeparator1,
            this.TipStatus_toolStrip});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(907, 25);
            this.toolStrip1.TabIndex = 28;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStrip_JDPass
            // 
            this.toolStrip_JDPass.Image = ((System.Drawing.Image)(resources.GetObject("toolStrip_JDPass.Image")));
            this.toolStrip_JDPass.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStrip_JDPass.Name = "toolStrip_JDPass";
            this.toolStrip_JDPass.Size = new System.Drawing.Size(73, 22);
            this.toolStrip_JDPass.Text = "鉴定通过";
            this.toolStrip_JDPass.Click += new System.EventHandler(this.toolStrip_JDPass_Click);
            // 
            // toolStrip_JDNo
            // 
            this.toolStrip_JDNo.Image = ((System.Drawing.Image)(resources.GetObject("toolStrip_JDNo.Image")));
            this.toolStrip_JDNo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStrip_JDNo.Name = "toolStrip_JDNo";
            this.toolStrip_JDNo.Size = new System.Drawing.Size(85, 22);
            this.toolStrip_JDNo.Text = "鉴定不通过";
            this.toolStrip_JDNo.Click += new System.EventHandler(this.toolStrip_JDNo_Click);
            // 
            // toolStrip_SHPass
            // 
            this.toolStrip_SHPass.Image = ((System.Drawing.Image)(resources.GetObject("toolStrip_SHPass.Image")));
            this.toolStrip_SHPass.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStrip_SHPass.Name = "toolStrip_SHPass";
            this.toolStrip_SHPass.Size = new System.Drawing.Size(73, 22);
            this.toolStrip_SHPass.Text = "审批通过";
            this.toolStrip_SHPass.Click += new System.EventHandler(this.toolStrip_SHPass_Click);
            // 
            // toolStrip_SHNo
            // 
            this.toolStrip_SHNo.Image = ((System.Drawing.Image)(resources.GetObject("toolStrip_SHNo.Image")));
            this.toolStrip_SHNo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStrip_SHNo.Name = "toolStrip_SHNo";
            this.toolStrip_SHNo.Size = new System.Drawing.Size(85, 22);
            this.toolStrip_SHNo.Text = "审批不通过";
            this.toolStrip_SHNo.Click += new System.EventHandler(this.toolStrip_SHNo_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // TipStatus_toolStrip
            // 
            this.TipStatus_toolStrip.Name = "TipStatus_toolStrip";
            this.TipStatus_toolStrip.Size = new System.Drawing.Size(0, 22);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox_SHUSERID);
            this.groupBox3.Controls.Add(this.textBox_SHMAN);
            this.groupBox3.Controls.Add(this.textBox_JDUSERID);
            this.groupBox3.Controls.Add(this.textBox_JDMAN);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.dateTimePicker_SHDATE);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.textBox_SHADVICE);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.dateTimePicker_JDDATE);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.textBox_JDADVICE);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.repotruserId_textBox);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.reportman_selText);
            this.groupBox3.Controls.Add(this.QLFARE_textBox);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.CVALUE_textBox);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.IOID_selText);
            this.groupBox3.Controls.Add(this.dateTimePicker_REPORTDATE);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.NOREASON_textBox);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.Status_ytComboBox1);
            this.groupBox3.Controls.Add(this.NOID_textBox);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.deptid_selTextInpt);
            this.groupBox3.Controls.Add(this.cardId_textBox);
            this.groupBox3.Controls.Add(this.Userid_textBox);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.choscode_textBox);
            this.groupBox3.Controls.Add(this.Username_textBox);
            this.groupBox3.Controls.Add(this.recdate_dateTimePicker);
            this.groupBox3.Controls.Add(this.memo_textBox);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(0, 25);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(907, 521);
            this.groupBox3.TabIndex = 29;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "公共信息";
            // 
            // textBox_SHUSERID
            // 
            this.textBox_SHUSERID.Location = new System.Drawing.Point(441, 473);
            this.textBox_SHUSERID.Name = "textBox_SHUSERID";
            this.textBox_SHUSERID.ReadOnly = true;
            this.textBox_SHUSERID.Size = new System.Drawing.Size(154, 21);
            this.textBox_SHUSERID.TabIndex = 22;
            this.textBox_SHUSERID.TabStop = false;
            // 
            // textBox_SHMAN
            // 
            this.textBox_SHMAN.Location = new System.Drawing.Point(135, 476);
            this.textBox_SHMAN.Name = "textBox_SHMAN";
            this.textBox_SHMAN.ReadOnly = true;
            this.textBox_SHMAN.Size = new System.Drawing.Size(154, 21);
            this.textBox_SHMAN.TabIndex = 21;
            this.textBox_SHMAN.TabStop = false;
            // 
            // textBox_JDUSERID
            // 
            this.textBox_JDUSERID.Location = new System.Drawing.Point(441, 374);
            this.textBox_JDUSERID.Name = "textBox_JDUSERID";
            this.textBox_JDUSERID.ReadOnly = true;
            this.textBox_JDUSERID.Size = new System.Drawing.Size(154, 21);
            this.textBox_JDUSERID.TabIndex = 18;
            this.textBox_JDUSERID.TabStop = false;
            // 
            // textBox_JDMAN
            // 
            this.textBox_JDMAN.Location = new System.Drawing.Point(137, 373);
            this.textBox_JDMAN.Name = "textBox_JDMAN";
            this.textBox_JDMAN.ReadOnly = true;
            this.textBox_JDMAN.Size = new System.Drawing.Size(154, 21);
            this.textBox_JDMAN.TabIndex = 17;
            this.textBox_JDMAN.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label12.Location = new System.Drawing.Point(355, 478);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 116;
            this.label12.Text = "审批人ID";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(44, 476);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 117;
            this.label15.Text = "审批人";
            // 
            // dateTimePicker_SHDATE
            // 
            this.dateTimePicker_SHDATE.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker_SHDATE.Enabled = false;
            this.dateTimePicker_SHDATE.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_SHDATE.Location = new System.Drawing.Point(730, 473);
            this.dateTimePicker_SHDATE.Name = "dateTimePicker_SHDATE";
            this.dateTimePicker_SHDATE.Size = new System.Drawing.Size(159, 21);
            this.dateTimePicker_SHDATE.TabIndex = 23;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(645, 478);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 113;
            this.label19.Text = "审批日期";
            // 
            // textBox_SHADVICE
            // 
            this.textBox_SHADVICE.Location = new System.Drawing.Point(135, 408);
            this.textBox_SHADVICE.Multiline = true;
            this.textBox_SHADVICE.Name = "textBox_SHADVICE";
            this.textBox_SHADVICE.Size = new System.Drawing.Size(751, 52);
            this.textBox_SHADVICE.TabIndex = 20;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(49, 412);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 111;
            this.label20.Text = "审批意见";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label5.Location = new System.Drawing.Point(356, 374);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 108;
            this.label5.Text = "鉴定人ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(49, 374);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 109;
            this.label6.Text = "鉴定人";
            // 
            // dateTimePicker_JDDATE
            // 
            this.dateTimePicker_JDDATE.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker_JDDATE.Enabled = false;
            this.dateTimePicker_JDDATE.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_JDDATE.Location = new System.Drawing.Point(733, 369);
            this.dateTimePicker_JDDATE.Name = "dateTimePicker_JDDATE";
            this.dateTimePicker_JDDATE.Size = new System.Drawing.Size(154, 21);
            this.dateTimePicker_JDDATE.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(645, 376);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 105;
            this.label7.Text = "鉴定日期";
            // 
            // textBox_JDADVICE
            // 
            this.textBox_JDADVICE.Location = new System.Drawing.Point(137, 306);
            this.textBox_JDADVICE.Multiline = true;
            this.textBox_JDADVICE.Name = "textBox_JDADVICE";
            this.textBox_JDADVICE.Size = new System.Drawing.Size(749, 52);
            this.textBox_JDADVICE.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(54, 310);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 103;
            this.label10.Text = "鉴定意见";
            // 
            // repotruserId_textBox
            // 
            this.repotruserId_textBox.Location = new System.Drawing.Point(441, 261);
            this.repotruserId_textBox.Name = "repotruserId_textBox";
            this.repotruserId_textBox.Size = new System.Drawing.Size(154, 21);
            this.repotruserId_textBox.TabIndex = 14;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Blue;
            this.label21.Location = new System.Drawing.Point(355, 265);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 100;
            this.label21.Text = "申请人ID";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.Color.Blue;
            this.label26.Location = new System.Drawing.Point(61, 265);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 12);
            this.label26.TabIndex = 101;
            this.label26.Text = "申请人";
            // 
            // reportman_selText
            // 
            this.reportman_selText.ColDefText = null;
            this.reportman_selText.ColStyle = null;
            this.reportman_selText.DataType = null;
            this.reportman_selText.DbConn = null;
            this.reportman_selText.Location = new System.Drawing.Point(137, 260);
            this.reportman_selText.Name = "reportman_selText";
            this.reportman_selText.NextFocusControl = null;
            this.reportman_selText.ReadOnly = false;
            this.reportman_selText.SelParam = null;
            this.reportman_selText.ShowColNum = 0;
            this.reportman_selText.ShowWidth = 0;
            this.reportman_selText.Size = new System.Drawing.Size(154, 22);
            this.reportman_selText.Sql = null;
            this.reportman_selText.SqlStr = null;
            this.reportman_selText.TabIndex = 13;
            this.reportman_selText.TvColName = null;
            this.reportman_selText.Value = null;
            this.reportman_selText.WatermarkText = "";
            // 
            // QLFARE_textBox
            // 
            this.QLFARE_textBox.Location = new System.Drawing.Point(441, 57);
            this.QLFARE_textBox.Name = "QLFARE_textBox";
            this.QLFARE_textBox.Size = new System.Drawing.Size(154, 21);
            this.QLFARE_textBox.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(371, 62);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 97;
            this.label8.Text = "清理费";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(380, 94);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 96;
            this.label9.Text = "残值";
            // 
            // CVALUE_textBox
            // 
            this.CVALUE_textBox.Location = new System.Drawing.Point(442, 91);
            this.CVALUE_textBox.Name = "CVALUE_textBox";
            this.CVALUE_textBox.Size = new System.Drawing.Size(154, 21);
            this.CVALUE_textBox.TabIndex = 7;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Blue;
            this.label25.Location = new System.Drawing.Point(49, 130);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 93;
            this.label25.Text = "下账类别";
            // 
            // IOID_selText
            // 
            this.IOID_selText.ColDefText = null;
            this.IOID_selText.ColStyle = null;
            this.IOID_selText.DataType = null;
            this.IOID_selText.DbConn = null;
            this.IOID_selText.Location = new System.Drawing.Point(140, 123);
            this.IOID_selText.Name = "IOID_selText";
            this.IOID_selText.NextFocusControl = null;
            this.IOID_selText.ReadOnly = false;
            this.IOID_selText.SelParam = null;
            this.IOID_selText.ShowColNum = 0;
            this.IOID_selText.ShowWidth = 0;
            this.IOID_selText.Size = new System.Drawing.Size(154, 22);
            this.IOID_selText.Sql = null;
            this.IOID_selText.SqlStr = null;
            this.IOID_selText.TabIndex = 9;
            this.IOID_selText.TvColName = null;
            this.IOID_selText.Value = null;
            this.IOID_selText.WatermarkText = "";
            // 
            // dateTimePicker_REPORTDATE
            // 
            this.dateTimePicker_REPORTDATE.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker_REPORTDATE.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_REPORTDATE.Location = new System.Drawing.Point(732, 260);
            this.dateTimePicker_REPORTDATE.Name = "dateTimePicker_REPORTDATE";
            this.dateTimePicker_REPORTDATE.Size = new System.Drawing.Size(154, 21);
            this.dateTimePicker_REPORTDATE.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(645, 264);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 89;
            this.label4.Text = "申请日期";
            // 
            // NOREASON_textBox
            // 
            this.NOREASON_textBox.Location = new System.Drawing.Point(137, 196);
            this.NOREASON_textBox.Multiline = true;
            this.NOREASON_textBox.Name = "NOREASON_textBox";
            this.NOREASON_textBox.Size = new System.Drawing.Size(749, 52);
            this.NOREASON_textBox.TabIndex = 12;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Blue;
            this.label23.Location = new System.Drawing.Point(51, 199);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 87;
            this.label23.Text = "下账原因";
            // 
            // Status_ytComboBox1
            // 
            this.Status_ytComboBox1.CacheKey = null;
            this.Status_ytComboBox1.DbConn = null;
            this.Status_ytComboBox1.DefText = null;
            this.Status_ytComboBox1.DefValue = null;
            this.Status_ytComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Status_ytComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Status_ytComboBox1.EnableEmpty = true;
            this.Status_ytComboBox1.FirstText = null;
            this.Status_ytComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Status_ytComboBox1.Fomart = null;
            this.Status_ytComboBox1.ItemStr = "";
            this.Status_ytComboBox1.Location = new System.Drawing.Point(441, 22);
            this.Status_ytComboBox1.Name = "ytComboBox1";
            this.Status_ytComboBox1.Param = null;
            this.Status_ytComboBox1.Size = new System.Drawing.Size(154, 22);
            this.Status_ytComboBox1.Sql = null;
            this.Status_ytComboBox1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Status_ytComboBox1.TabIndex = 1;
            this.Status_ytComboBox1.Tag = tvList2;
            this.Status_ytComboBox1.Value = null;
            // 
            // NOID_textBox
            // 
            this.NOID_textBox.Location = new System.Drawing.Point(140, 24);
            this.NOID_textBox.Name = "NOID_textBox";
            this.NOID_textBox.ReadOnly = true;
            this.NOID_textBox.Size = new System.Drawing.Size(154, 21);
            this.NOID_textBox.TabIndex = 0;
            this.NOID_textBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(61, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 41;
            this.label1.Text = "卡片ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(63, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 100;
            this.label2.Text = "下账ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(61, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 45;
            this.label3.Text = "科室";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Blue;
            this.label16.Location = new System.Drawing.Point(380, 24);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 47;
            this.label16.Text = "状态";
            // 
            // deptid_selTextInpt
            // 
            this.deptid_selTextInpt.ColDefText = null;
            this.deptid_selTextInpt.ColStyle = null;
            this.deptid_selTextInpt.DataType = null;
            this.deptid_selTextInpt.DbConn = null;
            this.deptid_selTextInpt.Enabled = false;
            this.deptid_selTextInpt.Location = new System.Drawing.Point(140, 91);
            this.deptid_selTextInpt.Name = "deptid_selTextInpt";
            this.deptid_selTextInpt.NextFocusControl = null;
            this.deptid_selTextInpt.ReadOnly = false;
            this.deptid_selTextInpt.SelParam = null;
            this.deptid_selTextInpt.ShowColNum = 0;
            this.deptid_selTextInpt.ShowWidth = 0;
            this.deptid_selTextInpt.Size = new System.Drawing.Size(154, 22);
            this.deptid_selTextInpt.Sql = null;
            this.deptid_selTextInpt.SqlStr = null;
            this.deptid_selTextInpt.TabIndex = 6;
            this.deptid_selTextInpt.TabStop = false;
            this.deptid_selTextInpt.TvColName = null;
            this.deptid_selTextInpt.Value = null;
            this.deptid_selTextInpt.WatermarkText = "";
            // 
            // cardId_textBox
            // 
            this.cardId_textBox.ColDefText = null;
            this.cardId_textBox.ColStyle = null;
            this.cardId_textBox.DataType = null;
            this.cardId_textBox.DbConn = null;
            this.cardId_textBox.Enabled = false;
            this.cardId_textBox.Location = new System.Drawing.Point(141, 59);
            this.cardId_textBox.Name = "cardId_textBox";
            this.cardId_textBox.NextFocusControl = null;
            this.cardId_textBox.ReadOnly = false;
            this.cardId_textBox.SelParam = null;
            this.cardId_textBox.ShowColNum = 0;
            this.cardId_textBox.ShowWidth = 0;
            this.cardId_textBox.Size = new System.Drawing.Size(154, 21);
            this.cardId_textBox.Sql = null;
            this.cardId_textBox.SqlStr = null;
            this.cardId_textBox.TabIndex = 3;
            this.cardId_textBox.TabStop = false;
            this.cardId_textBox.TvColName = null;
            this.cardId_textBox.Value = null;
            this.cardId_textBox.WatermarkText = "";
            // 
            // Userid_textBox
            // 
            this.Userid_textBox.Location = new System.Drawing.Point(728, 94);
            this.Userid_textBox.Name = "Userid_textBox";
            this.Userid_textBox.ReadOnly = true;
            this.Userid_textBox.Size = new System.Drawing.Size(154, 21);
            this.Userid_textBox.TabIndex = 8;
            this.Userid_textBox.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(350, 130);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 46;
            this.label13.Text = "操作员姓名";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(634, 28);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 31;
            this.label14.Text = "修改时间";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Blue;
            this.label17.Location = new System.Drawing.Point(634, 62);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 12);
            this.label17.TabIndex = 32;
            this.label17.Text = "医疗机构编码";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Blue;
            this.label18.Location = new System.Drawing.Point(650, 99);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 33;
            this.label18.Text = "操作员ID";
            // 
            // choscode_textBox
            // 
            this.choscode_textBox.Location = new System.Drawing.Point(729, 57);
            this.choscode_textBox.Name = "choscode_textBox";
            this.choscode_textBox.ReadOnly = true;
            this.choscode_textBox.Size = new System.Drawing.Size(154, 21);
            this.choscode_textBox.TabIndex = 5;
            this.choscode_textBox.TabStop = false;
            // 
            // Username_textBox
            // 
            this.Username_textBox.Location = new System.Drawing.Point(443, 124);
            this.Username_textBox.Name = "Username_textBox";
            this.Username_textBox.ReadOnly = true;
            this.Username_textBox.Size = new System.Drawing.Size(154, 21);
            this.Username_textBox.TabIndex = 10;
            this.Username_textBox.TabStop = false;
            // 
            // recdate_dateTimePicker
            // 
            this.recdate_dateTimePicker.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.recdate_dateTimePicker.Enabled = false;
            this.recdate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.recdate_dateTimePicker.Location = new System.Drawing.Point(730, 24);
            this.recdate_dateTimePicker.Name = "recdate_dateTimePicker";
            this.recdate_dateTimePicker.Size = new System.Drawing.Size(154, 21);
            this.recdate_dateTimePicker.TabIndex = 2;
            this.recdate_dateTimePicker.TabStop = false;
            // 
            // memo_textBox
            // 
            this.memo_textBox.Location = new System.Drawing.Point(139, 158);
            this.memo_textBox.Name = "memo_textBox";
            this.memo_textBox.Size = new System.Drawing.Size(745, 21);
            this.memo_textBox.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(67, 161);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 38;
            this.label11.Text = "备注";
            // 
            // EQKeepAccountsManagEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(907, 609);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox2);
            this.Name = "EQKeepAccountsManagEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "设备下账单";
            this.Load += new System.EventHandler(this.EQKeepAccountsManagEdit_Load);
            this.groupBox2.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Save_button;
        private System.Windows.Forms.Button cancel_button;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStrip_JDPass;
        private System.Windows.Forms.ToolStripButton toolStrip_JDNo;
        private System.Windows.Forms.ToolStripButton toolStrip_SHPass;
        private System.Windows.Forms.ToolStripButton toolStrip_SHNo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel TipStatus_toolStrip;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox_SHUSERID;
        private System.Windows.Forms.TextBox textBox_SHMAN;
        private System.Windows.Forms.TextBox textBox_JDUSERID;
        private System.Windows.Forms.TextBox textBox_JDMAN;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dateTimePicker_SHDATE;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox_SHADVICE;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker_JDDATE;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_JDADVICE;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox repotruserId_textBox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label26;
        private YtWinContrl.com.contrl.SelTextInpt reportman_selText;
        private System.Windows.Forms.TextBox QLFARE_textBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox CVALUE_textBox;
        private System.Windows.Forms.Label label25;
        private YtWinContrl.com.contrl.SelTextInpt IOID_selText;
        private System.Windows.Forms.DateTimePicker dateTimePicker_REPORTDATE;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox NOREASON_textBox;
        private System.Windows.Forms.Label label23;
        private YtWinContrl.com.contrl.YtComboBox Status_ytComboBox1;
        private System.Windows.Forms.TextBox NOID_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label16;
        private YtWinContrl.com.contrl.SelTextInpt deptid_selTextInpt;
        private YtWinContrl.com.contrl.SelTextInpt cardId_textBox;
        private System.Windows.Forms.TextBox Userid_textBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox choscode_textBox;
        private System.Windows.Forms.TextBox Username_textBox;
        private System.Windows.Forms.DateTimePicker recdate_dateTimePicker;
        private System.Windows.Forms.TextBox memo_textBox;
        private System.Windows.Forms.Label label11;

    }
}