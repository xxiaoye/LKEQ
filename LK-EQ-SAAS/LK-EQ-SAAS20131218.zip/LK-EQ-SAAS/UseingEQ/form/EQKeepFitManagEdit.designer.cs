﻿namespace UseingEQ.form
{
    partial class EQKeepFitManagEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList3 = new YtWinContrl.com.datagrid.TvList();
            this.Save_button = new System.Windows.Forms.Button();
            this.cancel_button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ChangeParts_textBox = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox_RepairPeople = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.MaintainThing_textBox = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.RepairDeptId_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.BaoyangPeople_textBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.OtherFare_textBox = new System.Windows.Forms.TextBox();
            this.Maintaindate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.Maintaincode_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.label7 = new System.Windows.Forms.Label();
            this.Status_ytComboBox1 = new YtWinContrl.com.contrl.YtComboBox();
            this.Maintainid_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.deptid_selTextInpt = new YtWinContrl.com.contrl.SelTextInpt();
            this.cardId_textBox = new YtWinContrl.com.contrl.SelTextInpt();
            this.CLfare_textBox = new System.Windows.Forms.TextBox();
            this.Userid_textBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Maintainfare_textBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.choscode_textBox = new System.Windows.Forms.TextBox();
            this.Username_textBox = new System.Windows.Forms.TextBox();
            this.recdate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.memo_textBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Save_button
            // 
            this.Save_button.Location = new System.Drawing.Point(337, 20);
            this.Save_button.Name = "Save_button";
            this.Save_button.Size = new System.Drawing.Size(75, 23);
            this.Save_button.TabIndex = 19;
            this.Save_button.Text = "保存";
            this.Save_button.UseVisualStyleBackColor = true;
            this.Save_button.Click += new System.EventHandler(this.Save_button_Click);
            // 
            // cancel_button
            // 
            this.cancel_button.Location = new System.Drawing.Point(678, 20);
            this.cancel_button.Name = "cancel_button";
            this.cancel_button.Size = new System.Drawing.Size(75, 23);
            this.cancel_button.TabIndex = 20;
            this.cancel_button.Text = "取消";
            this.cancel_button.UseVisualStyleBackColor = true;
            this.cancel_button.Click += new System.EventHandler(this.cancel_button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cancel_button);
            this.groupBox2.Controls.Add(this.Save_button);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Location = new System.Drawing.Point(0, 321);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(907, 69);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ChangeParts_textBox);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.textBox_RepairPeople);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.MaintainThing_textBox);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.RepairDeptId_selText);
            this.groupBox3.Controls.Add(this.BaoyangPeople_textBox);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.OtherFare_textBox);
            this.groupBox3.Controls.Add(this.Maintaindate_dateTimePicker);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.Maintaincode_selText);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.Status_ytComboBox1);
            this.groupBox3.Controls.Add(this.Maintainid_textBox);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.deptid_selTextInpt);
            this.groupBox3.Controls.Add(this.cardId_textBox);
            this.groupBox3.Controls.Add(this.CLfare_textBox);
            this.groupBox3.Controls.Add(this.Userid_textBox);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.Maintainfare_textBox);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.choscode_textBox);
            this.groupBox3.Controls.Add(this.Username_textBox);
            this.groupBox3.Controls.Add(this.recdate_dateTimePicker);
            this.groupBox3.Controls.Add(this.memo_textBox);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(907, 315);
            this.groupBox3.TabIndex = 27;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "公共信息";
            // 
            // ChangeParts_textBox
            // 
            this.ChangeParts_textBox.Location = new System.Drawing.Point(141, 157);
            this.ChangeParts_textBox.Name = "ChangeParts_textBox";
            this.ChangeParts_textBox.Size = new System.Drawing.Size(154, 21);
            this.ChangeParts_textBox.TabIndex = 12;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(55, 160);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 87;
            this.label23.Text = "更换部件";
            // 
            // textBox_RepairPeople
            // 
            this.textBox_RepairPeople.Location = new System.Drawing.Point(448, 91);
            this.textBox_RepairPeople.Name = "textBox_RepairPeople";
            this.textBox_RepairPeople.Size = new System.Drawing.Size(154, 21);
            this.textBox_RepairPeople.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(369, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 85;
            this.label5.Text = "维修人";
            // 
            // MaintainThing_textBox
            // 
            this.MaintainThing_textBox.Location = new System.Drawing.Point(138, 258);
            this.MaintainThing_textBox.Multiline = true;
            this.MaintainThing_textBox.Name = "MaintainThing_textBox";
            this.MaintainThing_textBox.Size = new System.Drawing.Size(753, 51);
            this.MaintainThing_textBox.TabIndex = 18;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(46, 261);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 83;
            this.label20.Text = "保养情况";
            // 
            // RepairDeptId_selText
            // 
            this.RepairDeptId_selText.ColDefText = null;
            this.RepairDeptId_selText.ColStyle = null;
            this.RepairDeptId_selText.DataType = null;
            this.RepairDeptId_selText.DbConn = null;
            this.RepairDeptId_selText.Location = new System.Drawing.Point(448, 125);
            this.RepairDeptId_selText.Name = "RepairDeptId_selText";
            this.RepairDeptId_selText.NextFocusControl = null;
            this.RepairDeptId_selText.ReadOnly = false;
            this.RepairDeptId_selText.SelParam = null;
            this.RepairDeptId_selText.ShowColNum = 0;
            this.RepairDeptId_selText.ShowWidth = 0;
            this.RepairDeptId_selText.Size = new System.Drawing.Size(154, 22);
            this.RepairDeptId_selText.Sql = null;
            this.RepairDeptId_selText.SqlStr = null;
            this.RepairDeptId_selText.TabIndex = 10;
            this.RepairDeptId_selText.TvColName = null;
            this.RepairDeptId_selText.Value = null;
            this.RepairDeptId_selText.WatermarkText = "";
            // 
            // BaoyangPeople_textBox
            // 
            this.BaoyangPeople_textBox.Location = new System.Drawing.Point(448, 59);
            this.BaoyangPeople_textBox.Name = "BaoyangPeople_textBox";
            this.BaoyangPeople_textBox.Size = new System.Drawing.Size(154, 21);
            this.BaoyangPeople_textBox.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(654, 130);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 81;
            this.label10.Text = "其它费用";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(359, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 37;
            this.label6.Text = "维修科室";
            // 
            // OtherFare_textBox
            // 
            this.OtherFare_textBox.Location = new System.Drawing.Point(735, 124);
            this.OtherFare_textBox.Name = "OtherFare_textBox";
            this.OtherFare_textBox.Size = new System.Drawing.Size(154, 21);
            this.OtherFare_textBox.TabIndex = 11;
            // 
            // Maintaindate_dateTimePicker
            // 
            this.Maintaindate_dateTimePicker.CustomFormat = "yyyy-MM-dd hh:mm:ss";
            this.Maintaindate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Maintaindate_dateTimePicker.Location = new System.Drawing.Point(450, 159);
            this.Maintaindate_dateTimePicker.Name = "Maintaindate_dateTimePicker";
            this.Maintaindate_dateTimePicker.Size = new System.Drawing.Size(154, 21);
            this.Maintaindate_dateTimePicker.TabIndex = 13;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.Color.Blue;
            this.label27.Location = new System.Drawing.Point(369, 61);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 12);
            this.label27.TabIndex = 79;
            this.label27.Text = "保养人";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Blue;
            this.label25.Location = new System.Drawing.Point(51, 131);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 71;
            this.label25.Text = "保养类别";
            // 
            // Maintaincode_selText
            // 
            this.Maintaincode_selText.ColDefText = null;
            this.Maintaincode_selText.ColStyle = null;
            this.Maintaincode_selText.DataType = null;
            this.Maintaincode_selText.DbConn = null;
            this.Maintaincode_selText.Location = new System.Drawing.Point(140, 124);
            this.Maintaincode_selText.Name = "Maintaincode_selText";
            this.Maintaincode_selText.NextFocusControl = null;
            this.Maintaincode_selText.ReadOnly = false;
            this.Maintaincode_selText.SelParam = null;
            this.Maintaincode_selText.ShowColNum = 0;
            this.Maintaincode_selText.ShowWidth = 0;
            this.Maintaincode_selText.Size = new System.Drawing.Size(154, 22);
            this.Maintaincode_selText.Sql = null;
            this.Maintaincode_selText.SqlStr = null;
            this.Maintaincode_selText.TabIndex = 9;
            this.Maintaincode_selText.TvColName = null;
            this.Maintaincode_selText.Value = null;
            this.Maintaincode_selText.WatermarkText = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(369, 163);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 39;
            this.label7.Text = "保养日期";
            // 
            // Status_ytComboBox1
            // 
            this.Status_ytComboBox1.CacheKey = null;
            this.Status_ytComboBox1.DbConn = null;
            this.Status_ytComboBox1.DefText = null;
            this.Status_ytComboBox1.DefValue = null;
            this.Status_ytComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Status_ytComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Status_ytComboBox1.EnableEmpty = true;
            this.Status_ytComboBox1.FirstText = null;
            this.Status_ytComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Status_ytComboBox1.Fomart = null;
            this.Status_ytComboBox1.ItemStr = "";
            this.Status_ytComboBox1.Location = new System.Drawing.Point(733, 24);
            this.Status_ytComboBox1.Name = "ytComboBox1";
            this.Status_ytComboBox1.Param = null;
            this.Status_ytComboBox1.Size = new System.Drawing.Size(154, 22);
            this.Status_ytComboBox1.Sql = null;
            this.Status_ytComboBox1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Status_ytComboBox1.TabIndex = 2;
            this.Status_ytComboBox1.Tag = tvList3;
            this.Status_ytComboBox1.Value = null;
            // 
            // Maintainid_textBox
            // 
            this.Maintainid_textBox.Location = new System.Drawing.Point(140, 24);
            this.Maintainid_textBox.Name = "Maintainid_textBox";
            this.Maintainid_textBox.ReadOnly = true;
            this.Maintainid_textBox.Size = new System.Drawing.Size(154, 21);
            this.Maintainid_textBox.TabIndex = 0;
            this.Maintainid_textBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(61, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 41;
            this.label1.Text = "卡片ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(63, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 42;
            this.label2.Text = "保养ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(61, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 45;
            this.label3.Text = "科室";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Blue;
            this.label16.Location = new System.Drawing.Point(658, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 47;
            this.label16.Text = "状态";
            // 
            // deptid_selTextInpt
            // 
            this.deptid_selTextInpt.ColDefText = null;
            this.deptid_selTextInpt.ColStyle = null;
            this.deptid_selTextInpt.DataType = null;
            this.deptid_selTextInpt.DbConn = null;
            this.deptid_selTextInpt.Enabled = false;
            this.deptid_selTextInpt.Location = new System.Drawing.Point(140, 91);
            this.deptid_selTextInpt.Name = "deptid_selTextInpt";
            this.deptid_selTextInpt.NextFocusControl = null;
            this.deptid_selTextInpt.ReadOnly = false;
            this.deptid_selTextInpt.SelParam = null;
            this.deptid_selTextInpt.ShowColNum = 0;
            this.deptid_selTextInpt.ShowWidth = 0;
            this.deptid_selTextInpt.Size = new System.Drawing.Size(154, 22);
            this.deptid_selTextInpt.Sql = null;
            this.deptid_selTextInpt.SqlStr = null;
            this.deptid_selTextInpt.TabIndex = 6;
            this.deptid_selTextInpt.TabStop = false;
            this.deptid_selTextInpt.TvColName = null;
            this.deptid_selTextInpt.Value = null;
            this.deptid_selTextInpt.WatermarkText = "";
            // 
            // cardId_textBox
            // 
            this.cardId_textBox.ColDefText = null;
            this.cardId_textBox.ColStyle = null;
            this.cardId_textBox.DataType = null;
            this.cardId_textBox.DbConn = null;
            this.cardId_textBox.Enabled = false;
            this.cardId_textBox.Location = new System.Drawing.Point(141, 59);
            this.cardId_textBox.Name = "cardId_textBox";
            this.cardId_textBox.NextFocusControl = null;
            this.cardId_textBox.ReadOnly = false;
            this.cardId_textBox.SelParam = null;
            this.cardId_textBox.ShowColNum = 0;
            this.cardId_textBox.ShowWidth = 0;
            this.cardId_textBox.Size = new System.Drawing.Size(154, 21);
            this.cardId_textBox.Sql = null;
            this.cardId_textBox.SqlStr = null;
            this.cardId_textBox.TabIndex = 3;
            this.cardId_textBox.TabStop = false;
            this.cardId_textBox.TvColName = null;
            this.cardId_textBox.Value = null;
            this.cardId_textBox.WatermarkText = "";
            // 
            // CLfare_textBox
            // 
            this.CLfare_textBox.Location = new System.Drawing.Point(733, 56);
            this.CLfare_textBox.Name = "CLfare_textBox";
            this.CLfare_textBox.Size = new System.Drawing.Size(154, 21);
            this.CLfare_textBox.TabIndex = 5;
            // 
            // Userid_textBox
            // 
            this.Userid_textBox.Location = new System.Drawing.Point(450, 192);
            this.Userid_textBox.Name = "Userid_textBox";
            this.Userid_textBox.ReadOnly = true;
            this.Userid_textBox.Size = new System.Drawing.Size(154, 21);
            this.Userid_textBox.TabIndex = 16;
            this.Userid_textBox.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(48, 197);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 46;
            this.label13.Text = "操作员姓名";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(655, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 44;
            this.label8.Text = "材料费";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(655, 93);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 29;
            this.label9.Text = "保养费";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(354, 28);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 31;
            this.label14.Text = "修改时间";
            // 
            // Maintainfare_textBox
            // 
            this.Maintainfare_textBox.Location = new System.Drawing.Point(734, 90);
            this.Maintainfare_textBox.Name = "Maintainfare_textBox";
            this.Maintainfare_textBox.Size = new System.Drawing.Size(154, 21);
            this.Maintainfare_textBox.TabIndex = 8;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Blue;
            this.label17.Location = new System.Drawing.Point(640, 166);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 12);
            this.label17.TabIndex = 32;
            this.label17.Text = "医疗机构编码";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Blue;
            this.label18.Location = new System.Drawing.Point(369, 197);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 33;
            this.label18.Text = "操作员ID";
            // 
            // choscode_textBox
            // 
            this.choscode_textBox.Location = new System.Drawing.Point(736, 161);
            this.choscode_textBox.Name = "choscode_textBox";
            this.choscode_textBox.ReadOnly = true;
            this.choscode_textBox.Size = new System.Drawing.Size(154, 21);
            this.choscode_textBox.TabIndex = 14;
            this.choscode_textBox.TabStop = false;
            // 
            // Username_textBox
            // 
            this.Username_textBox.Location = new System.Drawing.Point(141, 191);
            this.Username_textBox.Name = "Username_textBox";
            this.Username_textBox.ReadOnly = true;
            this.Username_textBox.Size = new System.Drawing.Size(154, 21);
            this.Username_textBox.TabIndex = 15;
            this.Username_textBox.TabStop = false;
            // 
            // recdate_dateTimePicker
            // 
            this.recdate_dateTimePicker.CustomFormat = "yyyy-MM-dd hh:mm:ss";
            this.recdate_dateTimePicker.Enabled = false;
            this.recdate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.recdate_dateTimePicker.Location = new System.Drawing.Point(447, 24);
            this.recdate_dateTimePicker.Name = "recdate_dateTimePicker";
            this.recdate_dateTimePicker.Size = new System.Drawing.Size(154, 21);
            this.recdate_dateTimePicker.TabIndex = 1;
            this.recdate_dateTimePicker.TabStop = false;
            // 
            // memo_textBox
            // 
            this.memo_textBox.Location = new System.Drawing.Point(139, 226);
            this.memo_textBox.Name = "memo_textBox";
            this.memo_textBox.Size = new System.Drawing.Size(752, 21);
            this.memo_textBox.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(67, 229);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 38;
            this.label11.Text = "备注";
            // 
            // EQKeepFitManagEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(907, 390);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Name = "EQKeepFitManagEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "设备保养单";
            this.Load += new System.EventHandler(this.EQFixManagEdit_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Save_button;
        private System.Windows.Forms.Button cancel_button;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox ChangeParts_textBox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox_RepairPeople;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox MaintainThing_textBox;
        private System.Windows.Forms.Label label20;
        private YtWinContrl.com.contrl.SelTextInpt RepairDeptId_selText;
        private System.Windows.Forms.TextBox BaoyangPeople_textBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox OtherFare_textBox;
        private System.Windows.Forms.DateTimePicker Maintaindate_dateTimePicker;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private YtWinContrl.com.contrl.SelTextInpt Maintaincode_selText;
        private System.Windows.Forms.Label label7;
        private YtWinContrl.com.contrl.YtComboBox Status_ytComboBox1;
        private System.Windows.Forms.TextBox Maintainid_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label16;
        private YtWinContrl.com.contrl.SelTextInpt deptid_selTextInpt;
        private YtWinContrl.com.contrl.SelTextInpt cardId_textBox;
        private System.Windows.Forms.TextBox CLfare_textBox;
        private System.Windows.Forms.TextBox Userid_textBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox Maintainfare_textBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox choscode_textBox;
        private System.Windows.Forms.TextBox Username_textBox;
        private System.Windows.Forms.DateTimePicker recdate_dateTimePicker;
        private System.Windows.Forms.TextBox memo_textBox;
        private System.Windows.Forms.Label label11;

    }
}