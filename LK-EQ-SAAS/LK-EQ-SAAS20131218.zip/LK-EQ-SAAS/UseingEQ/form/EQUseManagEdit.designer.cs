﻿namespace UseingEQ.form
{
    partial class EQUseManagEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList1 = new YtWinContrl.com.datagrid.TvList();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ytComboBox1 = new YtWinContrl.com.contrl.YtComboBox();
            this.recdate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.usedate_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cardId_textBox = new YtWinContrl.com.contrl.SelTextInpt();
            this.deptid_selTextInpt = new YtWinContrl.com.contrl.SelTextInpt();
            this.memo_textBox = new System.Windows.Forms.TextBox();
            this.Username_textBox = new System.Windows.Forms.TextBox();
            this.Income_textBox = new System.Windows.Forms.TextBox();
            this.OtherFare_textBox = new System.Windows.Forms.TextBox();
            this.useid_textBox = new System.Windows.Forms.TextBox();
            this.usenum_textBox = new System.Windows.Forms.TextBox();
            this.usething_textBox = new System.Windows.Forms.TextBox();
            this.useman_textBox = new System.Windows.Forms.TextBox();
            this.Userid_textBox = new System.Windows.Forms.TextBox();
            this.choscode_textBox = new System.Windows.Forms.TextBox();
            this.NHfare_textBox = new System.Windows.Forms.TextBox();
            this.CLfare_textBox = new System.Windows.Forms.TextBox();
            this.cancel_button = new System.Windows.Forms.Button();
            this.OK_button = new System.Windows.Forms.Button();
            this.Save_button = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ytComboBox1);
            this.groupBox1.Controls.Add(this.recdate_dateTimePicker);
            this.groupBox1.Controls.Add(this.usedate_dateTimePicker);
            this.groupBox1.Controls.Add(this.cardId_textBox);
            this.groupBox1.Controls.Add(this.deptid_selTextInpt);
            this.groupBox1.Controls.Add(this.memo_textBox);
            this.groupBox1.Controls.Add(this.Username_textBox);
            this.groupBox1.Controls.Add(this.Income_textBox);
            this.groupBox1.Controls.Add(this.OtherFare_textBox);
            this.groupBox1.Controls.Add(this.useid_textBox);
            this.groupBox1.Controls.Add(this.usenum_textBox);
            this.groupBox1.Controls.Add(this.usething_textBox);
            this.groupBox1.Controls.Add(this.useman_textBox);
            this.groupBox1.Controls.Add(this.Userid_textBox);
            this.groupBox1.Controls.Add(this.choscode_textBox);
            this.groupBox1.Controls.Add(this.NHfare_textBox);
            this.groupBox1.Controls.Add(this.CLfare_textBox);
            this.groupBox1.Controls.Add(this.cancel_button);
            this.groupBox1.Controls.Add(this.OK_button);
            this.groupBox1.Controls.Add(this.Save_button);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(766, 460);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "使用单详细信息";
            // 
            // ytComboBox1
            // 
            this.ytComboBox1.CacheKey = null;
            this.ytComboBox1.DbConn = null;
            this.ytComboBox1.DefText = null;
            this.ytComboBox1.DefValue = null;
            this.ytComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox1.EnableEmpty = true;
            this.ytComboBox1.FirstText = null;
            this.ytComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox1.Fomart = null;
            this.ytComboBox1.ItemStr = "";
            this.ytComboBox1.Location = new System.Drawing.Point(553, 88);
            this.ytComboBox1.Name = "ytComboBox1";
            this.ytComboBox1.Param = null;
            this.ytComboBox1.Size = new System.Drawing.Size(155, 22);
            this.ytComboBox1.Sql = null;
            this.ytComboBox1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox1.TabIndex = 0;
            this.ytComboBox1.Tag = tvList1;
            this.ytComboBox1.Value = null;
            // 
            // recdate_dateTimePicker
            // 
            this.recdate_dateTimePicker.CustomFormat = "yyyy-MM-dd hh:mm:ss";
            this.recdate_dateTimePicker.Enabled = false;
            this.recdate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.recdate_dateTimePicker.Location = new System.Drawing.Point(554, 288);
            this.recdate_dateTimePicker.Name = "recdate_dateTimePicker";
            this.recdate_dateTimePicker.Size = new System.Drawing.Size(154, 21);
            this.recdate_dateTimePicker.TabIndex = 9;
            // 
            // usedate_dateTimePicker
            // 
            this.usedate_dateTimePicker.CustomFormat = "yyyy-MM-dd hh:mm:ss";
            this.usedate_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.usedate_dateTimePicker.Location = new System.Drawing.Point(554, 212);
            this.usedate_dateTimePicker.Name = "usedate_dateTimePicker";
            this.usedate_dateTimePicker.Size = new System.Drawing.Size(154, 21);
            this.usedate_dateTimePicker.TabIndex = 6;
            // 
            // cardId_textBox
            // 
            this.cardId_textBox.ColDefText = null;
            this.cardId_textBox.ColStyle = null;
            this.cardId_textBox.DataType = null;
            this.cardId_textBox.DbConn = null;
            this.cardId_textBox.Enabled = false;
            this.cardId_textBox.Location = new System.Drawing.Point(554, 47);
            this.cardId_textBox.Name = "cardId_textBox";
            this.cardId_textBox.NextFocusControl = null;
            this.cardId_textBox.ReadOnly = false;
            this.cardId_textBox.SelParam = null;
            this.cardId_textBox.ShowColNum = 0;
            this.cardId_textBox.ShowWidth = 0;
            this.cardId_textBox.Size = new System.Drawing.Size(152, 22);
            this.cardId_textBox.Sql = null;
            this.cardId_textBox.SqlStr = null;
            this.cardId_textBox.TabIndex = 0;
            this.cardId_textBox.TabStop = false;
            this.cardId_textBox.TvColName = null;
            this.cardId_textBox.Value = null;
            this.cardId_textBox.WatermarkText = "";
            // 
            // deptid_selTextInpt
            // 
            this.deptid_selTextInpt.ColDefText = null;
            this.deptid_selTextInpt.ColStyle = null;
            this.deptid_selTextInpt.DataType = null;
            this.deptid_selTextInpt.DbConn = null;
            this.deptid_selTextInpt.Enabled = false;
            this.deptid_selTextInpt.Location = new System.Drawing.Point(152, 88);
            this.deptid_selTextInpt.Name = "deptid_selTextInpt";
            this.deptid_selTextInpt.NextFocusControl = null;
            this.deptid_selTextInpt.ReadOnly = false;
            this.deptid_selTextInpt.SelParam = null;
            this.deptid_selTextInpt.ShowColNum = 0;
            this.deptid_selTextInpt.ShowWidth = 0;
            this.deptid_selTextInpt.Size = new System.Drawing.Size(152, 22);
            this.deptid_selTextInpt.Sql = null;
            this.deptid_selTextInpt.SqlStr = null;
            this.deptid_selTextInpt.TabIndex = 0;
            this.deptid_selTextInpt.TabStop = false;
            this.deptid_selTextInpt.TvColName = null;
            this.deptid_selTextInpt.Value = null;
            this.deptid_selTextInpt.WatermarkText = "";
            // 
            // memo_textBox
            // 
            this.memo_textBox.Location = new System.Drawing.Point(152, 365);
            this.memo_textBox.Name = "memo_textBox";
            this.memo_textBox.Size = new System.Drawing.Size(556, 21);
            this.memo_textBox.TabIndex = 9;
            // 
            // Username_textBox
            // 
            this.Username_textBox.Location = new System.Drawing.Point(152, 328);
            this.Username_textBox.Name = "Username_textBox";
            this.Username_textBox.ReadOnly = true;
            this.Username_textBox.Size = new System.Drawing.Size(152, 21);
            this.Username_textBox.TabIndex = 9;
            this.Username_textBox.TabStop = false;
            // 
            // Income_textBox
            // 
            this.Income_textBox.Location = new System.Drawing.Point(152, 246);
            this.Income_textBox.Name = "Income_textBox";
            this.Income_textBox.Size = new System.Drawing.Size(152, 21);
            this.Income_textBox.TabIndex = 7;
            // 
            // OtherFare_textBox
            // 
            this.OtherFare_textBox.Location = new System.Drawing.Point(152, 203);
            this.OtherFare_textBox.Name = "OtherFare_textBox";
            this.OtherFare_textBox.Size = new System.Drawing.Size(152, 21);
            this.OtherFare_textBox.TabIndex = 5;
            // 
            // useid_textBox
            // 
            this.useid_textBox.Location = new System.Drawing.Point(150, 47);
            this.useid_textBox.Name = "useid_textBox";
            this.useid_textBox.ReadOnly = true;
            this.useid_textBox.Size = new System.Drawing.Size(154, 21);
            this.useid_textBox.TabIndex = 3;
            this.useid_textBox.TabStop = false;
            // 
            // usenum_textBox
            // 
            this.usenum_textBox.Location = new System.Drawing.Point(554, 129);
            this.usenum_textBox.Name = "usenum_textBox";
            this.usenum_textBox.Size = new System.Drawing.Size(154, 21);
            this.usenum_textBox.TabIndex = 2;
            this.usenum_textBox.Leave += new System.EventHandler(this.usenum_textBox_Leave);
            // 
            // usething_textBox
            // 
            this.usething_textBox.Location = new System.Drawing.Point(554, 169);
            this.usething_textBox.Name = "usething_textBox";
            this.usething_textBox.Size = new System.Drawing.Size(154, 21);
            this.usething_textBox.TabIndex = 4;
            // 
            // useman_textBox
            // 
            this.useman_textBox.Location = new System.Drawing.Point(554, 249);
            this.useman_textBox.Name = "useman_textBox";
            this.useman_textBox.Size = new System.Drawing.Size(154, 21);
            this.useman_textBox.TabIndex = 8;
            // 
            // Userid_textBox
            // 
            this.Userid_textBox.Location = new System.Drawing.Point(150, 289);
            this.Userid_textBox.Name = "Userid_textBox";
            this.Userid_textBox.ReadOnly = true;
            this.Userid_textBox.Size = new System.Drawing.Size(154, 21);
            this.Userid_textBox.TabIndex = 9;
            this.Userid_textBox.TabStop = false;
            // 
            // choscode_textBox
            // 
            this.choscode_textBox.Location = new System.Drawing.Point(554, 328);
            this.choscode_textBox.Name = "choscode_textBox";
            this.choscode_textBox.ReadOnly = true;
            this.choscode_textBox.Size = new System.Drawing.Size(154, 21);
            this.choscode_textBox.TabIndex = 9;
            this.choscode_textBox.TabStop = false;
            // 
            // NHfare_textBox
            // 
            this.NHfare_textBox.Location = new System.Drawing.Point(152, 166);
            this.NHfare_textBox.Name = "NHfare_textBox";
            this.NHfare_textBox.Size = new System.Drawing.Size(152, 21);
            this.NHfare_textBox.TabIndex = 3;
            // 
            // CLfare_textBox
            // 
            this.CLfare_textBox.Location = new System.Drawing.Point(150, 129);
            this.CLfare_textBox.Name = "CLfare_textBox";
            this.CLfare_textBox.Size = new System.Drawing.Size(154, 21);
            this.CLfare_textBox.TabIndex = 1;
            // 
            // cancel_button
            // 
            this.cancel_button.Location = new System.Drawing.Point(443, 412);
            this.cancel_button.Name = "cancel_button";
            this.cancel_button.Size = new System.Drawing.Size(75, 23);
            this.cancel_button.TabIndex = 12;
            this.cancel_button.Text = "取消";
            this.cancel_button.UseVisualStyleBackColor = true;
            this.cancel_button.Click += new System.EventHandler(this.button2_Click);
            // 
            // OK_button
            // 
            this.OK_button.Location = new System.Drawing.Point(327, 412);
            this.OK_button.Name = "OK_button";
            this.OK_button.Size = new System.Drawing.Size(75, 23);
            this.OK_button.TabIndex = 11;
            this.OK_button.Text = "确定";
            this.OK_button.UseVisualStyleBackColor = true;
            this.OK_button.Click += new System.EventHandler(this.OK_button_Click);
            // 
            // Save_button
            // 
            this.Save_button.Location = new System.Drawing.Point(204, 412);
            this.Save_button.Name = "Save_button";
            this.Save_button.Size = new System.Drawing.Size(75, 23);
            this.Save_button.TabIndex = 10;
            this.Save_button.Text = "保存";
            this.Save_button.UseVisualStyleBackColor = true;
            this.Save_button.Click += new System.EventHandler(this.Save_button_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(452, 172);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "使用情况";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(452, 252);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "使用人";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Blue;
            this.label18.Location = new System.Drawing.Point(74, 292);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 0;
            this.label18.Text = "操作员ID";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(74, 252);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "营业收入";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(74, 172);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "能耗费";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Blue;
            this.label17.Location = new System.Drawing.Point(452, 332);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "医疗机构编码";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(452, 292);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "修改时间";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(74, 365);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "备注";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(74, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "科室ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(74, 132);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "材料费";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Blue;
            this.label16.Location = new System.Drawing.Point(452, 92);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 0;
            this.label16.Text = "状态";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(74, 332);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "操作员姓名";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(74, 212);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "其他";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(452, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "使用次数";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(452, 212);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "使用日期";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(74, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "使用ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(452, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "卡片设备";
            // 
            // EQUseManagEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 460);
            this.Controls.Add(this.groupBox1);
            this.Name = "EQUseManagEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "设备使用单";
            this.Load += new System.EventHandler(this.EQUseManagEdit_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button cancel_button;
        private System.Windows.Forms.Button Save_button;
        private System.Windows.Forms.TextBox memo_textBox;
        private System.Windows.Forms.TextBox Username_textBox;
        private System.Windows.Forms.TextBox OtherFare_textBox;
        private System.Windows.Forms.TextBox choscode_textBox;
        private System.Windows.Forms.TextBox NHfare_textBox;
        private System.Windows.Forms.TextBox CLfare_textBox;
        private System.Windows.Forms.TextBox useid_textBox;
        private System.Windows.Forms.TextBox usenum_textBox;
        private System.Windows.Forms.TextBox usething_textBox;
        private System.Windows.Forms.TextBox useman_textBox;
        private System.Windows.Forms.TextBox Userid_textBox;
        private System.Windows.Forms.TextBox Income_textBox;
        private System.Windows.Forms.DateTimePicker usedate_dateTimePicker;
        private YtWinContrl.com.contrl.SelTextInpt deptid_selTextInpt;
        private System.Windows.Forms.DateTimePicker recdate_dateTimePicker;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox1;
        private System.Windows.Forms.Button OK_button;
        private YtWinContrl.com.contrl.SelTextInpt cardId_textBox;
    }
}