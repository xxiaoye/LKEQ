﻿namespace EQPurchase.form
{
    partial class AskBuy_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList3 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList4 = new YtWinContrl.com.datagrid.TvList();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.selTextInpt_Country = new YtWinContrl.com.contrl.SelTextInpt();
            this.label22 = new System.Windows.Forms.Label();
            this.ytDateTime_SHTime = new YtWinContrl.com.contrl.YTDateTime();
            this.label21 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.selTextInpt_EQID = new YtWinContrl.com.contrl.SelTextInpt();
            this.ytDateTime_MakeTime = new YtWinContrl.com.contrl.YTDateTime();
            this.ytDateTime_RECDATE = new YtWinContrl.com.contrl.YTDateTime();
            this.label20 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.selTextInpt_QGKSID = new YtWinContrl.com.contrl.SelTextInpt();
            this.label5 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.yTextBox_User = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Name = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_QGNum = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Rec = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_Status = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_YJMONEY = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_UserID = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_PTTJ = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_GuiG = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_YJPRICE = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_SPNum = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_XYFX = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_QGID = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_REASON = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Choscode = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_SHName = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_SHUserID = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_XH = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_Unitcode = new YtWinContrl.com.contrl.YtComboBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.button_CG = new System.Windows.Forms.Button();
            this.button_SB = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.selTextInpt_Country);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.ytDateTime_SHTime);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.selTextInpt_EQID);
            this.groupBox2.Controls.Add(this.ytDateTime_MakeTime);
            this.groupBox2.Controls.Add(this.ytDateTime_RECDATE);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.selTextInpt_QGKSID);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.yTextBox_User);
            this.groupBox2.Controls.Add(this.yTextBox_Name);
            this.groupBox2.Controls.Add(this.yTextBox_QGNum);
            this.groupBox2.Controls.Add(this.yTextBox_Rec);
            this.groupBox2.Controls.Add(this.ytComboBox_Status);
            this.groupBox2.Controls.Add(this.yTextBox_YJMONEY);
            this.groupBox2.Controls.Add(this.yTextBox_UserID);
            this.groupBox2.Controls.Add(this.yTextBox_PTTJ);
            this.groupBox2.Controls.Add(this.yTextBox_GuiG);
            this.groupBox2.Controls.Add(this.yTextBox_YJPRICE);
            this.groupBox2.Controls.Add(this.yTextBox_SPNum);
            this.groupBox2.Controls.Add(this.yTextBox_XYFX);
            this.groupBox2.Controls.Add(this.yTextBox_QGID);
            this.groupBox2.Controls.Add(this.yTextBox_REASON);
            this.groupBox2.Controls.Add(this.yTextBox_Choscode);
            this.groupBox2.Controls.Add(this.yTextBox_SHName);
            this.groupBox2.Controls.Add(this.yTextBox_SHUserID);
            this.groupBox2.Controls.Add(this.yTextBox_XH);
            this.groupBox2.Controls.Add(this.ytComboBox_Unitcode);
            this.groupBox2.Location = new System.Drawing.Point(12, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(748, 366);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "基本信息";
            // 
            // selTextInpt_Country
            // 
            this.selTextInpt_Country.ColDefText = null;
            this.selTextInpt_Country.ColStyle = null;
            this.selTextInpt_Country.DataType = null;
            this.selTextInpt_Country.DbConn = null;
            this.selTextInpt_Country.Location = new System.Drawing.Point(585, 38);
            this.selTextInpt_Country.Name = "selTextInpt_Country";
            this.selTextInpt_Country.NextFocusControl = null;
            this.selTextInpt_Country.ReadOnly = false;
            this.selTextInpt_Country.SelParam = null;
            this.selTextInpt_Country.ShowColNum = 0;
            this.selTextInpt_Country.ShowWidth = 0;
            this.selTextInpt_Country.Size = new System.Drawing.Size(117, 22);
            this.selTextInpt_Country.Sql = null;
            this.selTextInpt_Country.SqlStr = null;
            this.selTextInpt_Country.TabIndex = 2;
            this.selTextInpt_Country.TvColName = null;
            this.selTextInpt_Country.Value = null;
            this.selTextInpt_Country.WatermarkText = "";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label22.Location = new System.Drawing.Point(25, 214);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 12);
            this.label22.TabIndex = 59;
            this.label22.Text = "审核操作员ID";
            // 
            // ytDateTime_SHTime
            // 
            this.ytDateTime_SHTime.CustomFormat = "yyyy-MM-dd HH:mm";
            this.ytDateTime_SHTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ytDateTime_SHTime.Location = new System.Drawing.Point(347, 214);
            this.ytDateTime_SHTime.Name = "ytDateTime_SHTime";
            this.ytDateTime_SHTime.Size = new System.Drawing.Size(119, 21);
            this.ytDateTime_SHTime.TabIndex = 22;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label21.Location = new System.Drawing.Point(260, 218);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 57;
            this.label21.Text = "审核日期";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(479, 218);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 12);
            this.label16.TabIndex = 56;
            this.label16.Text = "审核操作员姓名";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(50, 41);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 55;
            this.label8.Text = "请购ID";
            // 
            // selTextInpt_EQID
            // 
            this.selTextInpt_EQID.ColDefText = null;
            this.selTextInpt_EQID.ColStyle = null;
            this.selTextInpt_EQID.DataType = null;
            this.selTextInpt_EQID.DbConn = null;
            this.selTextInpt_EQID.Location = new System.Drawing.Point(116, 63);
            this.selTextInpt_EQID.Name = "selTextInpt_EQID";
            this.selTextInpt_EQID.NextFocusControl = null;
            this.selTextInpt_EQID.ReadOnly = false;
            this.selTextInpt_EQID.SelParam = null;
            this.selTextInpt_EQID.ShowColNum = 0;
            this.selTextInpt_EQID.ShowWidth = 0;
            this.selTextInpt_EQID.Size = new System.Drawing.Size(117, 22);
            this.selTextInpt_EQID.Sql = null;
            this.selTextInpt_EQID.SqlStr = null;
            this.selTextInpt_EQID.TabIndex = 3;
            this.selTextInpt_EQID.TvColName = null;
            this.selTextInpt_EQID.Value = null;
            this.selTextInpt_EQID.WatermarkText = "";
            // 
            // ytDateTime_MakeTime
            // 
            this.ytDateTime_MakeTime.CustomFormat = "yyyy-MM-dd HH:mm";
            this.ytDateTime_MakeTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ytDateTime_MakeTime.Location = new System.Drawing.Point(347, 154);
            this.ytDateTime_MakeTime.Name = "ytDateTime_MakeTime";
            this.ytDateTime_MakeTime.Size = new System.Drawing.Size(119, 21);
            this.ytDateTime_MakeTime.TabIndex = 16;
            // 
            // ytDateTime_RECDATE
            // 
            this.ytDateTime_RECDATE.CustomFormat = "yyyy-MM-dd HH:mm";
            this.ytDateTime_RECDATE.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ytDateTime_RECDATE.Location = new System.Drawing.Point(347, 183);
            this.ytDateTime_RECDATE.Name = "ytDateTime_RECDATE";
            this.ytDateTime_RECDATE.Size = new System.Drawing.Size(119, 21);
            this.ytDateTime_RECDATE.TabIndex = 19;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Blue;
            this.label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label20.Location = new System.Drawing.Point(261, 189);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 51;
            this.label20.Text = "修改时间";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(286, 102);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 49;
            this.label7.Text = "型号";
            // 
            // selTextInpt_QGKSID
            // 
            this.selTextInpt_QGKSID.ColDefText = null;
            this.selTextInpt_QGKSID.ColStyle = null;
            this.selTextInpt_QGKSID.DataType = null;
            this.selTextInpt_QGKSID.DbConn = null;
            this.selTextInpt_QGKSID.Location = new System.Drawing.Point(346, 37);
            this.selTextInpt_QGKSID.Name = "selTextInpt_QGKSID";
            this.selTextInpt_QGKSID.NextFocusControl = null;
            this.selTextInpt_QGKSID.ReadOnly = false;
            this.selTextInpt_QGKSID.SelParam = null;
            this.selTextInpt_QGKSID.ShowColNum = 0;
            this.selTextInpt_QGKSID.ShowWidth = 0;
            this.selTextInpt_QGKSID.Size = new System.Drawing.Size(121, 22);
            this.selTextInpt_QGKSID.Sql = null;
            this.selTextInpt_QGKSID.SqlStr = null;
            this.selTextInpt_QGKSID.TabIndex = 1;
            this.selTextInpt_QGKSID.TvColName = null;
            this.selTextInpt_QGKSID.Value = null;
            this.selTextInpt_QGKSID.WatermarkText = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(25, 187);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 47;
            this.label5.Text = "医疗机构编码";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label30.Location = new System.Drawing.Point(26, 304);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 46;
            this.label30.Text = "原因及用途";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.Color.Blue;
            this.label26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label26.Location = new System.Drawing.Point(526, 103);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 12);
            this.label26.TabIndex = 43;
            this.label26.Text = "状态";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label17.Location = new System.Drawing.Point(524, 73);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 42;
            this.label17.Text = "规格";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.Blue;
            this.label24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label24.Location = new System.Drawing.Point(261, 42);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 12);
            this.label24.TabIndex = 40;
            this.label24.Text = "请购科室";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(38, 272);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 34;
            this.label14.Text = "配套条件";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Blue;
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(493, 129);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 33;
            this.label15.Text = "预计总金额";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(36, 159);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 30;
            this.label18.Text = "审批数量";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(39, 245);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 29;
            this.label19.Text = "效益分析";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(506, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 28;
            this.label6.Text = "操作员ID";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(264, 129);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 26;
            this.label11.Text = "预计单价";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(524, 44);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 25;
            this.label12.Text = "国别";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(49, 68);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 24;
            this.label13.Text = "设备ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(34, 328);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 23;
            this.label4.Text = "备注";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(503, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 22;
            this.label2.Text = "操作员名称";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(37, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "单位编码";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(37, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 13;
            this.label10.Text = "请购数量";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(264, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "制定日期";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(263, 72);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "设备名称";
            // 
            // yTextBox_User
            // 
            // 
            // 
            // 
            this.yTextBox_User.Border.Class = "TextBoxBorder";
            this.yTextBox_User.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_User.Location = new System.Drawing.Point(584, 181);
            this.yTextBox_User.Name = "yTextBox_User";
            this.yTextBox_User.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_User.TabIndex = 20;
            // 
            // yTextBox_Name
            // 
            // 
            // 
            // 
            this.yTextBox_Name.Border.Class = "TextBoxBorder";
            this.yTextBox_Name.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Name.Location = new System.Drawing.Point(345, 68);
            this.yTextBox_Name.Name = "yTextBox_Name";
            this.yTextBox_Name.Size = new System.Drawing.Size(121, 21);
            this.yTextBox_Name.TabIndex = 4;
            // 
            // yTextBox_QGNum
            // 
            // 
            // 
            // 
            this.yTextBox_QGNum.Border.Class = "TextBoxBorder";
            this.yTextBox_QGNum.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_QGNum.Location = new System.Drawing.Point(115, 125);
            this.yTextBox_QGNum.Name = "yTextBox_PY";
            this.yTextBox_QGNum.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_QGNum.TabIndex = 9;
            // 
            // yTextBox_Rec
            // 
            // 
            // 
            // 
            this.yTextBox_Rec.Border.Class = "TextBoxBorder";
            this.yTextBox_Rec.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Rec.Location = new System.Drawing.Point(116, 323);
            this.yTextBox_Rec.Name = "yTextBox_User";
            this.yTextBox_Rec.Size = new System.Drawing.Size(587, 21);
            this.yTextBox_Rec.TabIndex = 27;
            // 
            // ytComboBox_Status
            // 
            this.ytComboBox_Status.CacheKey = null;
            this.ytComboBox_Status.DbConn = null;
            this.ytComboBox_Status.DefText = null;
            this.ytComboBox_Status.DefValue = null;
            this.ytComboBox_Status.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_Status.EnableEmpty = true;
            this.ytComboBox_Status.FirstText = null;
            this.ytComboBox_Status.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_Status.Fomart = null;
            this.ytComboBox_Status.ItemStr = "";
            this.ytComboBox_Status.Location = new System.Drawing.Point(586, 98);
            this.ytComboBox_Status.Name = "ytComboBox_Status";
            this.ytComboBox_Status.Param = null;
            this.ytComboBox_Status.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_Status.Sql = null;
            this.ytComboBox_Status.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_Status.TabIndex = 8;
            this.ytComboBox_Status.Tag = tvList3;
            this.ytComboBox_Status.Value = null;
            // 
            // yTextBox_YJMONEY
            // 
            // 
            // 
            // 
            this.yTextBox_YJMONEY.Border.Class = "TextBoxBorder";
            this.yTextBox_YJMONEY.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_YJMONEY.Location = new System.Drawing.Point(585, 126);
            this.yTextBox_YJMONEY.Name = "yTextBox_PY";
            this.yTextBox_YJMONEY.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_YJMONEY.TabIndex = 11;
            // 
            // yTextBox_UserID
            // 
            // 
            // 
            // 
            this.yTextBox_UserID.Border.Class = "TextBoxBorder";
            this.yTextBox_UserID.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_UserID.Location = new System.Drawing.Point(585, 154);
            this.yTextBox_UserID.Name = "yTextBox_User";
            this.yTextBox_UserID.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_UserID.TabIndex = 17;
            // 
            // yTextBox_PTTJ
            // 
            // 
            // 
            // 
            this.yTextBox_PTTJ.Border.Class = "TextBoxBorder";
            this.yTextBox_PTTJ.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_PTTJ.Location = new System.Drawing.Point(116, 268);
            this.yTextBox_PTTJ.Name = "yTextBox_User";
            this.yTextBox_PTTJ.Size = new System.Drawing.Size(587, 21);
            this.yTextBox_PTTJ.TabIndex = 25;
            // 
            // yTextBox_GuiG
            // 
            // 
            // 
            // 
            this.yTextBox_GuiG.Border.Class = "TextBoxBorder";
            this.yTextBox_GuiG.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_GuiG.Location = new System.Drawing.Point(586, 68);
            this.yTextBox_GuiG.Name = "yTextBox_User";
            this.yTextBox_GuiG.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_GuiG.TabIndex = 5;
            // 
            // yTextBox_YJPRICE
            // 
            // 
            // 
            // 
            this.yTextBox_YJPRICE.Border.Class = "TextBoxBorder";
            this.yTextBox_YJPRICE.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_YJPRICE.Location = new System.Drawing.Point(345, 124);
            this.yTextBox_YJPRICE.Name = "yTextBox_User";
            this.yTextBox_YJPRICE.Size = new System.Drawing.Size(121, 21);
            this.yTextBox_YJPRICE.TabIndex = 10;
            // 
            // yTextBox_SPNum
            // 
            // 
            // 
            // 
            this.yTextBox_SPNum.Border.Class = "TextBoxBorder";
            this.yTextBox_SPNum.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_SPNum.Location = new System.Drawing.Point(116, 153);
            this.yTextBox_SPNum.Name = "yTextBox_PY";
            this.yTextBox_SPNum.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_SPNum.TabIndex = 15;
            // 
            // yTextBox_XYFX
            // 
            // 
            // 
            // 
            this.yTextBox_XYFX.Border.Class = "TextBoxBorder";
            this.yTextBox_XYFX.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_XYFX.Location = new System.Drawing.Point(115, 242);
            this.yTextBox_XYFX.Multiline = true;
            this.yTextBox_XYFX.Name = "yTextBox_Name";
            this.yTextBox_XYFX.Size = new System.Drawing.Size(587, 21);
            this.yTextBox_XYFX.TabIndex = 24;
            // 
            // yTextBox_QGID
            // 
            // 
            // 
            // 
            this.yTextBox_QGID.Border.Class = "TextBoxBorder";
            this.yTextBox_QGID.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_QGID.Location = new System.Drawing.Point(117, 35);
            this.yTextBox_QGID.Name = "yTextBox_Name";
            this.yTextBox_QGID.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_QGID.TabIndex = 0;
            // 
            // yTextBox_REASON
            // 
            // 
            // 
            // 
            this.yTextBox_REASON.Border.Class = "TextBoxBorder";
            this.yTextBox_REASON.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_REASON.Location = new System.Drawing.Point(116, 296);
            this.yTextBox_REASON.Multiline = true;
            this.yTextBox_REASON.Name = "yTextBox_User";
            this.yTextBox_REASON.Size = new System.Drawing.Size(587, 21);
            this.yTextBox_REASON.TabIndex = 26;
            // 
            // yTextBox_Choscode
            // 
            // 
            // 
            // 
            this.yTextBox_Choscode.Border.Class = "TextBoxBorder";
            this.yTextBox_Choscode.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Choscode.Location = new System.Drawing.Point(115, 182);
            this.yTextBox_Choscode.Name = "yTextBox_User";
            this.yTextBox_Choscode.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_Choscode.TabIndex = 0;
            // 
            // yTextBox_SHName
            // 
            // 
            // 
            // 
            this.yTextBox_SHName.Border.Class = "TextBoxBorder";
            this.yTextBox_SHName.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_SHName.Location = new System.Drawing.Point(584, 213);
            this.yTextBox_SHName.Name = "yTextBox_User";
            this.yTextBox_SHName.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_SHName.TabIndex = 23;
            // 
            // yTextBox_SHUserID
            // 
            // 
            // 
            // 
            this.yTextBox_SHUserID.Border.Class = "TextBoxBorder";
            this.yTextBox_SHUserID.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_SHUserID.Location = new System.Drawing.Point(115, 210);
            this.yTextBox_SHUserID.Name = "yTextBox_User";
            this.yTextBox_SHUserID.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_SHUserID.TabIndex = 21;
            // 
            // yTextBox_XH
            // 
            // 
            // 
            // 
            this.yTextBox_XH.Border.Class = "TextBoxBorder";
            this.yTextBox_XH.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_XH.Location = new System.Drawing.Point(345, 97);
            this.yTextBox_XH.Name = "yTextBox_User";
            this.yTextBox_XH.Size = new System.Drawing.Size(121, 21);
            this.yTextBox_XH.TabIndex = 7;
            // 
            // ytComboBox_Unitcode
            // 
            this.ytComboBox_Unitcode.CacheKey = null;
            this.ytComboBox_Unitcode.DbConn = null;
            this.ytComboBox_Unitcode.DefText = null;
            this.ytComboBox_Unitcode.DefValue = null;
            this.ytComboBox_Unitcode.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_Unitcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_Unitcode.EnableEmpty = true;
            this.ytComboBox_Unitcode.FirstText = null;
            this.ytComboBox_Unitcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_Unitcode.Fomart = null;
            this.ytComboBox_Unitcode.ItemStr = "";
            this.ytComboBox_Unitcode.Location = new System.Drawing.Point(116, 95);
            this.ytComboBox_Unitcode.Name = "ytComboBox_Status";
            this.ytComboBox_Unitcode.Param = null;
            this.ytComboBox_Unitcode.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_Unitcode.Sql = null;
            this.ytComboBox_Unitcode.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_Unitcode.TabIndex = 6;
            this.ytComboBox_Unitcode.Tag = tvList4;
            this.ytComboBox_Unitcode.Value = null;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(507, 392);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(74, 26);
            this.btn_Cancel.TabIndex = 29;
            this.btn_Cancel.Text = "取消";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(251, 392);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(74, 26);
            this.btn_Save.TabIndex = 28;
            this.btn_Save.Text = "保存";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // button_CG
            // 
            this.button_CG.Location = new System.Drawing.Point(128, 392);
            this.button_CG.Name = "button_CG";
            this.button_CG.Size = new System.Drawing.Size(74, 26);
            this.button_CG.TabIndex = 30;
            this.button_CG.Text = "通过";
            this.button_CG.UseVisualStyleBackColor = true;
            this.button_CG.Click += new System.EventHandler(this.button_CG_Click);
            // 
            // button_SB
            // 
            this.button_SB.Location = new System.Drawing.Point(323, 392);
            this.button_SB.Name = "button_SB";
            this.button_SB.Size = new System.Drawing.Size(74, 26);
            this.button_SB.TabIndex = 31;
            this.button_SB.Text = "不通过";
            this.button_SB.UseVisualStyleBackColor = true;
            this.button_SB.Click += new System.EventHandler(this.button_SB_Click);
            // 
            // AskBuy_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 430);
            this.Controls.Add(this.button_SB);
            this.Controls.Add(this.button_CG);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.groupBox2);
            this.Name = "AskBuy_Add";
            this.Text = "设备请购信息";
            this.Load += new System.EventHandler(this.WZDict_Add_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private YtWinContrl.com.contrl.YTextBox yTextBox_User;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Name;
        private YtWinContrl.com.contrl.YTextBox yTextBox_QGNum;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Rec;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_Status;
        private YtWinContrl.com.contrl.YTextBox yTextBox_YJMONEY;
        private YtWinContrl.com.contrl.YTextBox yTextBox_PTTJ;
        private YtWinContrl.com.contrl.YTextBox yTextBox_GuiG;
        private YtWinContrl.com.contrl.YTextBox yTextBox_YJPRICE;
        private YtWinContrl.com.contrl.YTextBox yTextBox_SPNum;
        private YtWinContrl.com.contrl.YTextBox yTextBox_XYFX;
        private YtWinContrl.com.contrl.YTextBox yTextBox_QGID;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label26;
        private YtWinContrl.com.contrl.YTextBox yTextBox_REASON;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label label5;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Choscode;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt_QGKSID;
        private System.Windows.Forms.Label label6;
        private YtWinContrl.com.contrl.YTextBox yTextBox_UserID;
        private System.Windows.Forms.Label label7;
        private YtWinContrl.com.contrl.YTextBox yTextBox_XH;
        private System.Windows.Forms.Label label20;
        private YtWinContrl.com.contrl.YTDateTime ytDateTime_RECDATE;
        private YtWinContrl.com.contrl.YTDateTime ytDateTime_MakeTime;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt_EQID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label22;
        private YtWinContrl.com.contrl.YTDateTime ytDateTime_SHTime;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label16;
        private YtWinContrl.com.contrl.YTextBox yTextBox_SHName;
        private YtWinContrl.com.contrl.YTextBox yTextBox_SHUserID;
        private System.Windows.Forms.Button button_CG;
        private System.Windows.Forms.Button button_SB;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt_Country;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_Unitcode;
    }
}