﻿namespace JiChuDictionary.form
{
    partial class EQUnit_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList2 = new YtWinContrl.com.datagrid.TvList();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pycode_yTextBox5 = new YtWinContrl.com.contrl.YTextBox();
            this.dicgrpid_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.dicdesc_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.defvalue_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.dicid_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.fixed_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.save_button = new System.Windows.Forms.Button();
            this.cancel_button = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.pycode_yTextBox5);
            this.groupBox1.Controls.Add(this.dicgrpid_yTextBox);
            this.groupBox1.Controls.Add(this.dicdesc_yTextBox);
            this.groupBox1.Controls.Add(this.defvalue_ytComboBox);
            this.groupBox1.Controls.Add(this.dicid_yTextBox);
            this.groupBox1.Controls.Add(this.fixed_yTextBox);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(597, 220);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "请填写相应设备单位信息";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(24, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "DICID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(323, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "是否使用";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(24, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "名称";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(323, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "是否默认值";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(323, 164);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "拼音码";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(18, 225);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 12);
            this.label6.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(18, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "字典组类别";
            // 
            // pycode_yTextBox5
            // 
            // 
            // 
            // 
            this.pycode_yTextBox5.Border.Class = "TextBoxBorder";
            this.pycode_yTextBox5.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.pycode_yTextBox5.Location = new System.Drawing.Point(445, 162);
            this.pycode_yTextBox5.Name = "pycode_yTextBox5";
            this.pycode_yTextBox5.Size = new System.Drawing.Size(120, 21);
            this.pycode_yTextBox5.TabIndex = 5;
            // 
            // dicgrpid_yTextBox
            // 
            // 
            // 
            // 
            this.dicgrpid_yTextBox.Border.Class = "TextBoxBorder";
            this.dicgrpid_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dicgrpid_yTextBox.Location = new System.Drawing.Point(121, 32);
            this.dicgrpid_yTextBox.Name = "warecode_yTextBox";
            this.dicgrpid_yTextBox.ReadOnly = true;
            this.dicgrpid_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.dicgrpid_yTextBox.TabIndex = 0;
            // 
            // dicdesc_yTextBox
            // 
            // 
            // 
            // 
            this.dicdesc_yTextBox.Border.Class = "TextBoxBorder";
            this.dicdesc_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dicdesc_yTextBox.Location = new System.Drawing.Point(121, 160);
            this.dicdesc_yTextBox.Name = "warename_yTextBox";
            this.dicdesc_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.dicdesc_yTextBox.TabIndex = 4;
            // 
            // defvalue_ytComboBox
            // 
            this.defvalue_ytComboBox.CacheKey = null;
            this.defvalue_ytComboBox.DbConn = null;
            this.defvalue_ytComboBox.DefText = null;
            this.defvalue_ytComboBox.DefValue = null;
            this.defvalue_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.defvalue_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.defvalue_ytComboBox.EnableEmpty = true;
            this.defvalue_ytComboBox.FirstText = null;
            this.defvalue_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.defvalue_ytComboBox.Fomart = null;
            this.defvalue_ytComboBox.ItemStr = "";
            this.defvalue_ytComboBox.Location = new System.Drawing.Point(448, 33);
            this.defvalue_ytComboBox.Name = "ifuse_ytComboBox";
            this.defvalue_ytComboBox.Param = null;
            this.defvalue_ytComboBox.Size = new System.Drawing.Size(121, 22);
            this.defvalue_ytComboBox.Sql = null;
            this.defvalue_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.defvalue_ytComboBox.TabIndex = 1;
            this.defvalue_ytComboBox.Tag = tvList2;
            this.defvalue_ytComboBox.Value = null;
            // 
            // dicid_yTextBox
            // 
            // 
            // 
            // 
            this.dicid_yTextBox.Border.Class = "TextBoxBorder";
            this.dicid_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dicid_yTextBox.Location = new System.Drawing.Point(121, 89);
            this.dicid_yTextBox.Name = "choscode_yTextBox";
            this.dicid_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.dicid_yTextBox.TabIndex = 2;
            // 
            // fixed_yTextBox
            // 
            // 
            // 
            // 
            this.fixed_yTextBox.Border.Class = "TextBoxBorder";
            this.fixed_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.fixed_yTextBox.Location = new System.Drawing.Point(447, 89);
            this.fixed_yTextBox.Name = "fixed_yTextBox";
            this.fixed_yTextBox.ReadOnly = true;
            this.fixed_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.fixed_yTextBox.TabIndex = 0;
            // 
            // save_button
            // 
            this.save_button.Location = new System.Drawing.Point(169, 263);
            this.save_button.Name = "save_button";
            this.save_button.Size = new System.Drawing.Size(75, 23);
            this.save_button.TabIndex = 6;
            this.save_button.Text = "保存(&S)";
            this.save_button.UseVisualStyleBackColor = true;
            this.save_button.Click += new System.EventHandler(this.save_button_Click);
            // 
            // cancel_button
            // 
            this.cancel_button.Location = new System.Drawing.Point(379, 263);
            this.cancel_button.Name = "cancel_button";
            this.cancel_button.Size = new System.Drawing.Size(75, 23);
            this.cancel_button.TabIndex = 7;
            this.cancel_button.Text = "取消(&C)";
            this.cancel_button.UseVisualStyleBackColor = true;
            this.cancel_button.Click += new System.EventHandler(this.cancel_button_Click);
            // 
            // EQUnit_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 298);
            this.Controls.Add(this.cancel_button);
            this.Controls.Add(this.save_button);
            this.Controls.Add(this.groupBox1);
            this.Name = "EQUnit_Add";
            this.Text = "设备单位信息";
            this.Load += new System.EventHandler(this.AddWZUnit_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private YtWinContrl.com.contrl.YTextBox pycode_yTextBox5;
        private YtWinContrl.com.contrl.YTextBox dicgrpid_yTextBox;
        private YtWinContrl.com.contrl.YTextBox dicdesc_yTextBox;
        private YtWinContrl.com.contrl.YtComboBox defvalue_ytComboBox;
        private YtWinContrl.com.contrl.YTextBox dicid_yTextBox;
        private System.Windows.Forms.Button save_button;
        private System.Windows.Forms.Button cancel_button;
        private YtWinContrl.com.contrl.YTextBox fixed_yTextBox;
    }
}