﻿namespace JiChuDictionary.form
{
    partial class AddEQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList1 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList2 = new YtWinContrl.com.datagrid.TvList();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.wbcode_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.pycode_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.memo_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.warecode_yTextBox1 = new YtWinContrl.com.contrl.YTextBox();
            this.choscode_yTextBox1 = new YtWinContrl.com.contrl.YTextBox();
            this.warename_yTextBox1 = new YtWinContrl.com.contrl.YTextBox();
            this.ifuse_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.ifall_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.userid_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.username_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.selTextInpt1 = new YtWinContrl.com.contrl.SelTextInpt();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnCancel);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Location = new System.Drawing.Point(0, 358);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(635, 53);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(379, 18);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "取消(&C)";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(168, 18);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "保存(&S)";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.wbcode_yTextBox);
            this.groupBox1.Controls.Add(this.pycode_yTextBox);
            this.groupBox1.Controls.Add(this.memo_yTextBox);
            this.groupBox1.Controls.Add(this.warecode_yTextBox1);
            this.groupBox1.Controls.Add(this.choscode_yTextBox1);
            this.groupBox1.Controls.Add(this.warename_yTextBox1);
            this.groupBox1.Controls.Add(this.ifuse_ytComboBox);
            this.groupBox1.Controls.Add(this.ifall_ytComboBox);
            this.groupBox1.Controls.Add(this.userid_yTextBox);
            this.groupBox1.Controls.Add(this.username_yTextBox);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.selTextInpt1);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(635, 358);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "请填写相应的设备库房信息";
            // 
            // wbcode_yTextBox
            // 
            // 
            // 
            // 
            this.wbcode_yTextBox.Border.Class = "TextBoxBorder";
            this.wbcode_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.wbcode_yTextBox.Location = new System.Drawing.Point(451, 271);
            this.wbcode_yTextBox.Name = "wbcode_yTextBox";
            this.wbcode_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.wbcode_yTextBox.TabIndex = 6;
            // 
            // pycode_yTextBox
            // 
            // 
            // 
            // 
            this.pycode_yTextBox.Border.Class = "TextBoxBorder";
            this.pycode_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.pycode_yTextBox.Location = new System.Drawing.Point(141, 267);
            this.pycode_yTextBox.Name = "pycode_yTextBox";
            this.pycode_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.pycode_yTextBox.TabIndex = 5;
            // 
            // memo_yTextBox
            // 
            // 
            // 
            // 
            this.memo_yTextBox.Border.Class = "TextBoxBorder";
            this.memo_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.memo_yTextBox.Location = new System.Drawing.Point(141, 310);
            this.memo_yTextBox.Name = "memo_yTextBox";
            this.memo_yTextBox.Size = new System.Drawing.Size(430, 21);
            this.memo_yTextBox.TabIndex = 7;
            // 
            // warecode_yTextBox1
            // 
            // 
            // 
            // 
            this.warecode_yTextBox1.Border.Class = "TextBoxBorder";
            this.warecode_yTextBox1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.warecode_yTextBox1.Location = new System.Drawing.Point(141, 47);
            this.warecode_yTextBox1.Name = "warecode_yTextBox1";
            this.warecode_yTextBox1.ReadOnly = true;
            this.warecode_yTextBox1.Size = new System.Drawing.Size(120, 21);
            this.warecode_yTextBox1.TabIndex = 0;
            this.warecode_yTextBox1.TabStop = false;
            // 
            // choscode_yTextBox1
            // 
            // 
            // 
            // 
            this.choscode_yTextBox1.Border.Class = "TextBoxBorder";
            this.choscode_yTextBox1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.choscode_yTextBox1.Location = new System.Drawing.Point(141, 94);
            this.choscode_yTextBox1.Name = "choscode_yTextBox1";
            this.choscode_yTextBox1.ReadOnly = true;
            this.choscode_yTextBox1.Size = new System.Drawing.Size(120, 21);
            this.choscode_yTextBox1.TabIndex = 0;
            this.choscode_yTextBox1.TabStop = false;
            // 
            // warename_yTextBox1
            // 
            // 
            // 
            // 
            this.warename_yTextBox1.Border.Class = "TextBoxBorder";
            this.warename_yTextBox1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.warename_yTextBox1.Location = new System.Drawing.Point(141, 135);
            this.warename_yTextBox1.Name = "warename_yTextBox1";
            this.warename_yTextBox1.Size = new System.Drawing.Size(120, 21);
            this.warename_yTextBox1.TabIndex = 0;
            // 
            // ifuse_ytComboBox
            // 
            this.ifuse_ytComboBox.CacheKey = null;
            this.ifuse_ytComboBox.DbConn = null;
            this.ifuse_ytComboBox.DefText = null;
            this.ifuse_ytComboBox.DefValue = null;
            this.ifuse_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ifuse_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ifuse_ytComboBox.EnableEmpty = true;
            this.ifuse_ytComboBox.FirstText = null;
            this.ifuse_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ifuse_ytComboBox.Fomart = null;
            this.ifuse_ytComboBox.ItemStr = "";
            this.ifuse_ytComboBox.Location = new System.Drawing.Point(451, 183);
            this.ifuse_ytComboBox.Name = "ifuse_ytComboBox";
            this.ifuse_ytComboBox.Param = null;
            this.ifuse_ytComboBox.Size = new System.Drawing.Size(120, 22);
            this.ifuse_ytComboBox.Sql = null;
            this.ifuse_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ifuse_ytComboBox.TabIndex = 3;
            this.ifuse_ytComboBox.Tag = tvList1;
            this.ifuse_ytComboBox.Value = null;
            // 
            // ifall_ytComboBox
            // 
            this.ifall_ytComboBox.CacheKey = null;
            this.ifall_ytComboBox.DbConn = null;
            this.ifall_ytComboBox.DefText = null;
            this.ifall_ytComboBox.DefValue = null;
            this.ifall_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ifall_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ifall_ytComboBox.EnableEmpty = true;
            this.ifall_ytComboBox.FirstText = null;
            this.ifall_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ifall_ytComboBox.Fomart = null;
            this.ifall_ytComboBox.ItemStr = "";
            this.ifall_ytComboBox.Location = new System.Drawing.Point(451, 140);
            this.ifall_ytComboBox.Name = "ifall_ytComboBox";
            this.ifall_ytComboBox.Param = null;
            this.ifall_ytComboBox.Size = new System.Drawing.Size(120, 22);
            this.ifall_ytComboBox.Sql = null;
            this.ifall_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ifall_ytComboBox.TabIndex = 1;
            this.ifall_ytComboBox.Tag = tvList2;
            this.ifall_ytComboBox.Value = null;
            // 
            // userid_yTextBox
            // 
            // 
            // 
            // 
            this.userid_yTextBox.Border.Class = "TextBoxBorder";
            this.userid_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.userid_yTextBox.Location = new System.Drawing.Point(451, 48);
            this.userid_yTextBox.Name = "userid_yTextBox";
            this.userid_yTextBox.ReadOnly = true;
            this.userid_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.userid_yTextBox.TabIndex = 0;
            this.userid_yTextBox.TabStop = false;
            // 
            // username_yTextBox
            // 
            // 
            // 
            // 
            this.username_yTextBox.Border.Class = "TextBoxBorder";
            this.username_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.username_yTextBox.Location = new System.Drawing.Point(451, 99);
            this.username_yTextBox.Name = "username_yTextBox";
            this.username_yTextBox.ReadOnly = true;
            this.username_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.username_yTextBox.TabIndex = 0;
            this.username_yTextBox.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Checked = false;
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(141, 227);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker1.TabIndex = 4;
            // 
            // selTextInpt1
            // 
            this.selTextInpt1.ColDefText = null;
            this.selTextInpt1.ColStyle = null;
            this.selTextInpt1.DataType = null;
            this.selTextInpt1.DbConn = null;
            this.selTextInpt1.Location = new System.Drawing.Point(141, 179);
            this.selTextInpt1.Name = "selTextInpt1";
            this.selTextInpt1.NextFocusControl = null;
            this.selTextInpt1.ReadOnly = false;
            this.selTextInpt1.SelParam = null;
            this.selTextInpt1.ShowColNum = 0;
            this.selTextInpt1.ShowWidth = 0;
            this.selTextInpt1.Size = new System.Drawing.Size(120, 22);
            this.selTextInpt1.Sql = null;
            this.selTextInpt1.SqlStr = null;
            this.selTextInpt1.TabIndex = 2;
            this.selTextInpt1.TabStop = false;
            this.selTextInpt1.TvColName = null;
            this.selTextInpt1.Value = null;
            this.selTextInpt1.WatermarkText = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(49, 319);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 1;
            this.label12.Text = "备注";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(49, 275);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 1;
            this.label11.Text = "拼音码";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(311, 275);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 1;
            this.label10.Text = "五笔码";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(49, 230);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 1;
            this.label9.Text = "修改时间";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(311, 98);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 1;
            this.label8.Text = "操作员名称";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(311, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "操作员ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(311, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 12);
            this.label6.TabIndex = 1;
            this.label6.Text = "是否管理所有设备类别";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(311, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "是否使用";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(49, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "科室";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(49, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "库房名称";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(49, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "医疗机构编码";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(49, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "库房编码";
            // 
            // AddEQ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 411);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "AddEQ";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "输入库房信息";
            this.Load += new System.EventHandler(this.AddEQ_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox groupBox1;
        private YtWinContrl.com.contrl.YTextBox wbcode_yTextBox;
        private YtWinContrl.com.contrl.YTextBox pycode_yTextBox;
        private YtWinContrl.com.contrl.YTextBox memo_yTextBox;
        private YtWinContrl.com.contrl.YTextBox warecode_yTextBox1;
        private YtWinContrl.com.contrl.YTextBox choscode_yTextBox1;
        private YtWinContrl.com.contrl.YTextBox warename_yTextBox1;
        private YtWinContrl.com.contrl.YtComboBox ifuse_ytComboBox;
        private YtWinContrl.com.contrl.YtComboBox ifall_ytComboBox;
        private YtWinContrl.com.contrl.YTextBox userid_yTextBox;
        private YtWinContrl.com.contrl.YTextBox username_yTextBox;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;

    }
}