﻿namespace JiChuDictionary.form
{
    partial class Producters_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList5 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList6 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList7 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList8 = new YtWinContrl.com.datagrid.TvList();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.yTextBox_PY = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_User = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Name = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_WB = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Rec = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_ifUse = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_ChCode = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_UserID = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_IfMake = new YtWinContrl.com.contrl.YtComboBox();
            this.ytComboBox_IfAfford = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_Address = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Bank = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_BANKACCOUNT = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Fax = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_FRDB = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_JYXKZ = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Phone = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_POST = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_QYDM = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_RELMAN = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_SupplyID = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_YYZZ = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_Pperty = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_SWDJH = new YtWinContrl.com.contrl.YTextBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.yTextBox_PY);
            this.groupBox2.Controls.Add(this.yTextBox_User);
            this.groupBox2.Controls.Add(this.yTextBox_Name);
            this.groupBox2.Controls.Add(this.yTextBox_WB);
            this.groupBox2.Controls.Add(this.yTextBox_Rec);
            this.groupBox2.Controls.Add(this.ytComboBox_ifUse);
            this.groupBox2.Controls.Add(this.yTextBox_ChCode);
            this.groupBox2.Controls.Add(this.yTextBox_UserID);
            this.groupBox2.Controls.Add(this.ytComboBox_IfMake);
            this.groupBox2.Controls.Add(this.ytComboBox_IfAfford);
            this.groupBox2.Controls.Add(this.yTextBox_Address);
            this.groupBox2.Controls.Add(this.yTextBox_Bank);
            this.groupBox2.Controls.Add(this.yTextBox_BANKACCOUNT);
            this.groupBox2.Controls.Add(this.yTextBox_Fax);
            this.groupBox2.Controls.Add(this.yTextBox_FRDB);
            this.groupBox2.Controls.Add(this.yTextBox_JYXKZ);
            this.groupBox2.Controls.Add(this.yTextBox_Phone);
            this.groupBox2.Controls.Add(this.yTextBox_POST);
            this.groupBox2.Controls.Add(this.yTextBox_QYDM);
            this.groupBox2.Controls.Add(this.yTextBox_RELMAN);
            this.groupBox2.Controls.Add(this.yTextBox_SupplyID);
            this.groupBox2.Controls.Add(this.yTextBox_YYZZ);
            this.groupBox2.Controls.Add(this.ytComboBox_Pperty);
            this.groupBox2.Controls.Add(this.yTextBox_SWDJH);
            this.groupBox2.Location = new System.Drawing.Point(19, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(808, 289);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "基本信息";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(498, 224);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 42;
            this.label7.Text = "税务登记号";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label25.Location = new System.Drawing.Point(262, 222);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 41;
            this.label25.Text = "营业执照";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label24.Location = new System.Drawing.Point(32, 222);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 12);
            this.label24.TabIndex = 40;
            this.label24.Text = "经营许可证";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label23.Location = new System.Drawing.Point(262, 196);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 39;
            this.label23.Text = "传真号码";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label21.Location = new System.Drawing.Point(505, 196);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 38;
            this.label21.Text = "邮政编码";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label22.Location = new System.Drawing.Point(32, 171);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 12);
            this.label22.TabIndex = 37;
            this.label22.Text = "地址";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label20.Location = new System.Drawing.Point(505, 171);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 12);
            this.label20.TabIndex = 36;
            this.label20.Text = "联系人";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(505, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 35;
            this.label5.Text = "开户账号";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(505, 116);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 34;
            this.label14.Text = "开户银行";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(505, 88);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 33;
            this.label15.Text = "企业性质";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(32, 196);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 32;
            this.label16.Text = "联系电话";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(505, 60);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 30;
            this.label18.Text = "法人代表";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(505, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 29;
            this.label19.Text = "企业代码";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(262, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 28;
            this.label6.Text = "操作员ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(262, 116);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 12);
            this.label8.TabIndex = 27;
            this.label8.Text = "医疗机构编码";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(262, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 26;
            this.label11.Text = "是否生产厂家";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(262, 60);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 25;
            this.label12.Text = "是否供应商";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(262, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 24;
            this.label13.Text = "厂商ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(32, 250);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 23;
            this.label4.Text = "备注";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(32, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 22;
            this.label2.Text = "操作员名称";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(32, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "是否使用";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(32, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 13;
            this.label10.Text = "五笔码";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "拼音码";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(32, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "厂商名称";
            // 
            // yTextBox_PY
            // 
            // 
            // 
            // 
            this.yTextBox_PY.Border.Class = "TextBoxBorder";
            this.yTextBox_PY.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_PY.Location = new System.Drawing.Point(117, 53);
            this.yTextBox_PY.Name = "yTextBox_PY";
            this.yTextBox_PY.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_PY.TabIndex = 3;
            // 
            // yTextBox_User
            // 
            // 
            // 
            // 
            this.yTextBox_User.Border.Class = "TextBoxBorder";
            this.yTextBox_User.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_User.Location = new System.Drawing.Point(117, 139);
            this.yTextBox_User.Name = "yTextBox_User";
            this.yTextBox_User.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_User.TabIndex = 12;
            // 
            // yTextBox_Name
            // 
            // 
            // 
            // 
            this.yTextBox_Name.Border.Class = "TextBoxBorder";
            this.yTextBox_Name.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Name.Location = new System.Drawing.Point(117, 25);
            this.yTextBox_Name.Name = "yTextBox_Name";
            this.yTextBox_Name.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_Name.TabIndex = 0;
            // 
            // yTextBox_WB
            // 
            // 
            // 
            // 
            this.yTextBox_WB.Border.Class = "TextBoxBorder";
            this.yTextBox_WB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_WB.Location = new System.Drawing.Point(117, 80);
            this.yTextBox_WB.Name = "yTextBox_PY";
            this.yTextBox_WB.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_WB.TabIndex = 6;
            // 
            // yTextBox_Rec
            // 
            // 
            // 
            // 
            this.yTextBox_Rec.Border.Class = "TextBoxBorder";
            this.yTextBox_Rec.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Rec.Location = new System.Drawing.Point(117, 248);
            this.yTextBox_Rec.Name = "yTextBox_User";
            this.yTextBox_Rec.Size = new System.Drawing.Size(592, 21);
            this.yTextBox_Rec.TabIndex = 23;
            // 
            // ytComboBox_ifUse
            // 
            this.ytComboBox_ifUse.CacheKey = null;
            this.ytComboBox_ifUse.DbConn = null;
            this.ytComboBox_ifUse.DefText = null;
            this.ytComboBox_ifUse.DefValue = null;
            this.ytComboBox_ifUse.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_ifUse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_ifUse.EnableEmpty = true;
            this.ytComboBox_ifUse.FirstText = null;
            this.ytComboBox_ifUse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_ifUse.Fomart = null;
            this.ytComboBox_ifUse.ItemStr = "";
            this.ytComboBox_ifUse.Location = new System.Drawing.Point(117, 110);
            this.ytComboBox_ifUse.Name = "ytComboBox_ifUse";
            this.ytComboBox_ifUse.Param = null;
            this.ytComboBox_ifUse.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_ifUse.Sql = null;
            this.ytComboBox_ifUse.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_ifUse.TabIndex = 9;
            this.ytComboBox_ifUse.Tag = tvList5;
            this.ytComboBox_ifUse.Value = null;
            // 
            // yTextBox_ChCode
            // 
            // 
            // 
            // 
            this.yTextBox_ChCode.Border.Class = "TextBoxBorder";
            this.yTextBox_ChCode.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_ChCode.Location = new System.Drawing.Point(360, 110);
            this.yTextBox_ChCode.Name = "yTextBox_PY";
            this.yTextBox_ChCode.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_ChCode.TabIndex = 10;
            // 
            // yTextBox_UserID
            // 
            // 
            // 
            // 
            this.yTextBox_UserID.Border.Class = "TextBoxBorder";
            this.yTextBox_UserID.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_UserID.Location = new System.Drawing.Point(360, 139);
            this.yTextBox_UserID.Name = "yTextBox_User";
            this.yTextBox_UserID.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_UserID.TabIndex = 13;
            // 
            // ytComboBox_IfMake
            // 
            this.ytComboBox_IfMake.CacheKey = null;
            this.ytComboBox_IfMake.DbConn = null;
            this.ytComboBox_IfMake.DefText = null;
            this.ytComboBox_IfMake.DefValue = null;
            this.ytComboBox_IfMake.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_IfMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_IfMake.EnableEmpty = true;
            this.ytComboBox_IfMake.FirstText = null;
            this.ytComboBox_IfMake.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_IfMake.Fomart = null;
            this.ytComboBox_IfMake.ItemStr = "";
            this.ytComboBox_IfMake.Location = new System.Drawing.Point(360, 80);
            this.ytComboBox_IfMake.Name = "ytComboBox_ifUse";
            this.ytComboBox_IfMake.Param = null;
            this.ytComboBox_IfMake.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_IfMake.Sql = null;
            this.ytComboBox_IfMake.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_IfMake.TabIndex = 7;
            this.ytComboBox_IfMake.Tag = tvList6;
            this.ytComboBox_IfMake.Value = null;
            // 
            // ytComboBox_IfAfford
            // 
            this.ytComboBox_IfAfford.CacheKey = null;
            this.ytComboBox_IfAfford.DbConn = null;
            this.ytComboBox_IfAfford.DefText = null;
            this.ytComboBox_IfAfford.DefValue = null;
            this.ytComboBox_IfAfford.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_IfAfford.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_IfAfford.EnableEmpty = true;
            this.ytComboBox_IfAfford.FirstText = null;
            this.ytComboBox_IfAfford.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_IfAfford.Fomart = null;
            this.ytComboBox_IfAfford.ItemStr = "";
            this.ytComboBox_IfAfford.Location = new System.Drawing.Point(360, 52);
            this.ytComboBox_IfAfford.Name = "ytComboBox_ifUse";
            this.ytComboBox_IfAfford.Param = null;
            this.ytComboBox_IfAfford.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_IfAfford.Sql = null;
            this.ytComboBox_IfAfford.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_IfAfford.TabIndex = 4;
            this.ytComboBox_IfAfford.Tag = tvList7;
            this.ytComboBox_IfAfford.Value = null;
            // 
            // yTextBox_Address
            // 
            // 
            // 
            // 
            this.yTextBox_Address.Border.Class = "TextBoxBorder";
            this.yTextBox_Address.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Address.Location = new System.Drawing.Point(117, 168);
            this.yTextBox_Address.Name = "yTextBox_User";
            this.yTextBox_Address.Size = new System.Drawing.Size(361, 21);
            this.yTextBox_Address.TabIndex = 15;
            // 
            // yTextBox_Bank
            // 
            // 
            // 
            // 
            this.yTextBox_Bank.Border.Class = "TextBoxBorder";
            this.yTextBox_Bank.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Bank.Location = new System.Drawing.Point(586, 112);
            this.yTextBox_Bank.Name = "yTextBox_User";
            this.yTextBox_Bank.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_Bank.TabIndex = 11;
            // 
            // yTextBox_BANKACCOUNT
            // 
            // 
            // 
            // 
            this.yTextBox_BANKACCOUNT.Border.Class = "TextBoxBorder";
            this.yTextBox_BANKACCOUNT.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_BANKACCOUNT.Location = new System.Drawing.Point(586, 139);
            this.yTextBox_BANKACCOUNT.Name = "yTextBox_User";
            this.yTextBox_BANKACCOUNT.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_BANKACCOUNT.TabIndex = 14;
            // 
            // yTextBox_Fax
            // 
            // 
            // 
            // 
            this.yTextBox_Fax.Border.Class = "TextBoxBorder";
            this.yTextBox_Fax.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Fax.Location = new System.Drawing.Point(360, 194);
            this.yTextBox_Fax.Name = "yTextBox_User";
            this.yTextBox_Fax.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_Fax.TabIndex = 18;
            // 
            // yTextBox_FRDB
            // 
            // 
            // 
            // 
            this.yTextBox_FRDB.Border.Class = "TextBoxBorder";
            this.yTextBox_FRDB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_FRDB.Location = new System.Drawing.Point(585, 53);
            this.yTextBox_FRDB.Name = "yTextBox_PY";
            this.yTextBox_FRDB.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_FRDB.TabIndex = 5;
            // 
            // yTextBox_JYXKZ
            // 
            // 
            // 
            // 
            this.yTextBox_JYXKZ.Border.Class = "TextBoxBorder";
            this.yTextBox_JYXKZ.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_JYXKZ.Location = new System.Drawing.Point(117, 220);
            this.yTextBox_JYXKZ.Name = "yTextBox_User";
            this.yTextBox_JYXKZ.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_JYXKZ.TabIndex = 20;
            // 
            // yTextBox_Phone
            // 
            // 
            // 
            // 
            this.yTextBox_Phone.Border.Class = "TextBoxBorder";
            this.yTextBox_Phone.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Phone.Location = new System.Drawing.Point(117, 194);
            this.yTextBox_Phone.Name = "yTextBox_User";
            this.yTextBox_Phone.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_Phone.TabIndex = 17;
            // 
            // yTextBox_POST
            // 
            // 
            // 
            // 
            this.yTextBox_POST.Border.Class = "TextBoxBorder";
            this.yTextBox_POST.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_POST.Location = new System.Drawing.Point(586, 194);
            this.yTextBox_POST.Name = "yTextBox_User";
            this.yTextBox_POST.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_POST.TabIndex = 19;
            // 
            // yTextBox_QYDM
            // 
            // 
            // 
            // 
            this.yTextBox_QYDM.Border.Class = "TextBoxBorder";
            this.yTextBox_QYDM.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_QYDM.Location = new System.Drawing.Point(585, 25);
            this.yTextBox_QYDM.Name = "yTextBox_Name";
            this.yTextBox_QYDM.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_QYDM.TabIndex = 2;
            // 
            // yTextBox_RELMAN
            // 
            // 
            // 
            // 
            this.yTextBox_RELMAN.Border.Class = "TextBoxBorder";
            this.yTextBox_RELMAN.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_RELMAN.Location = new System.Drawing.Point(585, 168);
            this.yTextBox_RELMAN.Name = "yTextBox_User";
            this.yTextBox_RELMAN.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_RELMAN.TabIndex = 16;
            // 
            // yTextBox_SupplyID
            // 
            // 
            // 
            // 
            this.yTextBox_SupplyID.Border.Class = "TextBoxBorder";
            this.yTextBox_SupplyID.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_SupplyID.Location = new System.Drawing.Point(360, 25);
            this.yTextBox_SupplyID.Name = "yTextBox_Name";
            this.yTextBox_SupplyID.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_SupplyID.TabIndex = 1;
            // 
            // yTextBox_YYZZ
            // 
            // 
            // 
            // 
            this.yTextBox_YYZZ.Border.Class = "TextBoxBorder";
            this.yTextBox_YYZZ.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_YYZZ.Location = new System.Drawing.Point(360, 220);
            this.yTextBox_YYZZ.Name = "yTextBox_User";
            this.yTextBox_YYZZ.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_YYZZ.TabIndex = 21;
            // 
            // ytComboBox_Pperty
            // 
            this.ytComboBox_Pperty.CacheKey = null;
            this.ytComboBox_Pperty.DbConn = null;
            this.ytComboBox_Pperty.DefText = null;
            this.ytComboBox_Pperty.DefValue = null;
            this.ytComboBox_Pperty.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_Pperty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_Pperty.EnableEmpty = true;
            this.ytComboBox_Pperty.FirstText = null;
            this.ytComboBox_Pperty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_Pperty.Fomart = null;
            this.ytComboBox_Pperty.ItemStr = "";
            this.ytComboBox_Pperty.Location = new System.Drawing.Point(585, 83);
            this.ytComboBox_Pperty.Name = "ytComboBox_ifUse";
            this.ytComboBox_Pperty.Param = null;
            this.ytComboBox_Pperty.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_Pperty.Sql = null;
            this.ytComboBox_Pperty.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_Pperty.TabIndex = 8;
            this.ytComboBox_Pperty.Tag = tvList8;
            this.ytComboBox_Pperty.Value = null;
            // 
            // yTextBox_SWDJH
            // 
            // 
            // 
            // 
            this.yTextBox_SWDJH.Border.Class = "TextBoxBorder";
            this.yTextBox_SWDJH.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_SWDJH.Location = new System.Drawing.Point(586, 220);
            this.yTextBox_SWDJH.Name = "yTextBox_User";
            this.yTextBox_SWDJH.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_SWDJH.TabIndex = 22;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(461, 321);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(74, 26);
            this.btn_Cancel.TabIndex = 25;
            this.btn_Cancel.Text = "取消";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(248, 321);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(74, 26);
            this.btn_Save.TabIndex = 24;
            this.btn_Save.Text = "保存";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // Producters_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 368);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.groupBox2);
            this.Name = "Producters_Add";
            this.Text = "厂商信息";
            this.Load += new System.EventHandler(this.Producters_Add_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private YtWinContrl.com.contrl.YTextBox yTextBox_PY;
        private YtWinContrl.com.contrl.YTextBox yTextBox_User;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Name;
        private YtWinContrl.com.contrl.YTextBox yTextBox_WB;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Rec;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_ifUse;
        private YtWinContrl.com.contrl.YTextBox yTextBox_ChCode;
        private YtWinContrl.com.contrl.YTextBox yTextBox_UserID;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_IfMake;
        private YtWinContrl.com.contrl.YTextBox yTextBox_SupplyID;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_IfAfford;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private YtWinContrl.com.contrl.YTextBox yTextBox_QYDM;
        private YtWinContrl.com.contrl.YTextBox yTextBox_FRDB;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private YtWinContrl.com.contrl.YTextBox yTextBox_BANKACCOUNT;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Bank;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Address;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Phone;
        private YtWinContrl.com.contrl.YTextBox yTextBox_JYXKZ;
        private YtWinContrl.com.contrl.YTextBox yTextBox_RELMAN;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Fax;
        private YtWinContrl.com.contrl.YTextBox yTextBox_POST;
        private YtWinContrl.com.contrl.YTextBox yTextBox_YYZZ;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_Pperty;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label label7;
        private YtWinContrl.com.contrl.YTextBox yTextBox_SWDJH;
    }
}