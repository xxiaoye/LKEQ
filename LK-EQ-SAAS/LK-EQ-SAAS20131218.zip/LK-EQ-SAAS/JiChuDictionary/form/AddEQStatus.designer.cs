﻿namespace JiChuDictionary.form
{
    partial class AddEQStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList1 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList2 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList3 = new YtWinContrl.com.datagrid.TvList();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.statusname_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.statuscode_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.wbcode_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.pycode_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.userid_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.username_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.memo_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.choscode_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.ifdefault_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.ifdepreciation_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.ifuse_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(316, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "状态编码";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(30, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "状态名称";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(30, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "是否使用";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(30, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "是否计提折旧";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(30, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "是否默认值";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(316, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "操作员ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(30, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "操作员名称";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(316, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "修改时间";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(316, 115);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "医疗机构编码";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(316, 252);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "五笔码";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 252);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "拼音码";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(30, 292);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "备注";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(135, 347);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(333, 347);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnClose);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.statusname_yTextBox);
            this.groupBox1.Controls.Add(this.statuscode_yTextBox);
            this.groupBox1.Controls.Add(this.wbcode_yTextBox);
            this.groupBox1.Controls.Add(this.pycode_yTextBox);
            this.groupBox1.Controls.Add(this.userid_yTextBox);
            this.groupBox1.Controls.Add(this.username_yTextBox);
            this.groupBox1.Controls.Add(this.memo_yTextBox);
            this.groupBox1.Controls.Add(this.choscode_yTextBox);
            this.groupBox1.Controls.Add(this.ifdefault_ytComboBox);
            this.groupBox1.Controls.Add(this.ifdepreciation_ytComboBox);
            this.groupBox1.Controls.Add(this.ifuse_ytComboBox);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(553, 381);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "设备状态信息";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(409, 70);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // statusname_yTextBox
            // 
            // 
            // 
            // 
            this.statusname_yTextBox.Border.Class = "TextBoxBorder";
            this.statusname_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.statusname_yTextBox.Location = new System.Drawing.Point(125, 29);
            this.statusname_yTextBox.Name = "statusname_yTextBox";
            this.statusname_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.statusname_yTextBox.TabIndex = 1;
            // 
            // statuscode_yTextBox
            // 
            // 
            // 
            // 
            this.statuscode_yTextBox.Border.Class = "TextBoxBorder";
            this.statuscode_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.statuscode_yTextBox.Location = new System.Drawing.Point(410, 29);
            this.statuscode_yTextBox.Name = "statuscode_yTextBox";
            this.statuscode_yTextBox.ReadOnly = true;
            this.statuscode_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.statuscode_yTextBox.TabIndex = 0;
            this.statuscode_yTextBox.TabStop = false;
            // 
            // wbcode_yTextBox
            // 
            // 
            // 
            // 
            this.wbcode_yTextBox.Border.Class = "TextBoxBorder";
            this.wbcode_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.wbcode_yTextBox.Location = new System.Drawing.Point(410, 247);
            this.wbcode_yTextBox.Name = "wbcode_yTextBox";
            this.wbcode_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.wbcode_yTextBox.TabIndex = 7;
            // 
            // pycode_yTextBox
            // 
            // 
            // 
            // 
            this.pycode_yTextBox.Border.Class = "TextBoxBorder";
            this.pycode_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.pycode_yTextBox.Location = new System.Drawing.Point(125, 248);
            this.pycode_yTextBox.Name = "pycode_yTextBox";
            this.pycode_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.pycode_yTextBox.TabIndex = 6;
            // 
            // userid_yTextBox
            // 
            // 
            // 
            // 
            this.userid_yTextBox.Border.Class = "TextBoxBorder";
            this.userid_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.userid_yTextBox.Location = new System.Drawing.Point(410, 151);
            this.userid_yTextBox.Name = "userid_yTextBox";
            this.userid_yTextBox.ReadOnly = true;
            this.userid_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.userid_yTextBox.TabIndex = 0;
            this.userid_yTextBox.TabStop = false;
            // 
            // username_yTextBox
            // 
            // 
            // 
            // 
            this.username_yTextBox.Border.Class = "TextBoxBorder";
            this.username_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.username_yTextBox.Location = new System.Drawing.Point(125, 191);
            this.username_yTextBox.Name = "username_yTextBox";
            this.username_yTextBox.ReadOnly = true;
            this.username_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.username_yTextBox.TabIndex = 0;
            this.username_yTextBox.TabStop = false;
            // 
            // memo_yTextBox
            // 
            // 
            // 
            // 
            this.memo_yTextBox.Border.Class = "TextBoxBorder";
            this.memo_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.memo_yTextBox.Location = new System.Drawing.Point(125, 288);
            this.memo_yTextBox.Multiline = true;
            this.memo_yTextBox.Name = "memo_yTextBox";
            this.memo_yTextBox.Size = new System.Drawing.Size(405, 21);
            this.memo_yTextBox.TabIndex = 8;
            // 
            // choscode_yTextBox
            // 
            // 
            // 
            // 
            this.choscode_yTextBox.Border.Class = "TextBoxBorder";
            this.choscode_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.choscode_yTextBox.Location = new System.Drawing.Point(410, 112);
            this.choscode_yTextBox.Name = "choscode_yTextBox";
            this.choscode_yTextBox.ReadOnly = true;
            this.choscode_yTextBox.Size = new System.Drawing.Size(120, 21);
            this.choscode_yTextBox.TabIndex = 0;
            this.choscode_yTextBox.TabStop = false;
            // 
            // ifdefault_ytComboBox
            // 
            this.ifdefault_ytComboBox.CacheKey = null;
            this.ifdefault_ytComboBox.DbConn = null;
            this.ifdefault_ytComboBox.DefText = null;
            this.ifdefault_ytComboBox.DefValue = null;
            this.ifdefault_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ifdefault_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ifdefault_ytComboBox.EnableEmpty = true;
            this.ifdefault_ytComboBox.FirstText = null;
            this.ifdefault_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ifdefault_ytComboBox.Fomart = null;
            this.ifdefault_ytComboBox.ItemStr = "";
            this.ifdefault_ytComboBox.Location = new System.Drawing.Point(125, 153);
            this.ifdefault_ytComboBox.Name = "ifdefault_ytComboBox";
            this.ifdefault_ytComboBox.Param = null;
            this.ifdefault_ytComboBox.Size = new System.Drawing.Size(121, 22);
            this.ifdefault_ytComboBox.Sql = null;
            this.ifdefault_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ifdefault_ytComboBox.TabIndex = 5;
            this.ifdefault_ytComboBox.Tag = tvList1;
            this.ifdefault_ytComboBox.Value = null;
            // 
            // ifdepreciation_ytComboBox
            // 
            this.ifdepreciation_ytComboBox.CacheKey = null;
            this.ifdepreciation_ytComboBox.DbConn = null;
            this.ifdepreciation_ytComboBox.DefText = null;
            this.ifdepreciation_ytComboBox.DefValue = null;
            this.ifdepreciation_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ifdepreciation_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ifdepreciation_ytComboBox.EnableEmpty = true;
            this.ifdepreciation_ytComboBox.FirstText = null;
            this.ifdepreciation_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ifdepreciation_ytComboBox.Fomart = null;
            this.ifdepreciation_ytComboBox.ItemStr = "";
            this.ifdepreciation_ytComboBox.Location = new System.Drawing.Point(125, 111);
            this.ifdepreciation_ytComboBox.Name = "ifdepreciation_ytComboBox";
            this.ifdepreciation_ytComboBox.Param = null;
            this.ifdepreciation_ytComboBox.Size = new System.Drawing.Size(121, 22);
            this.ifdepreciation_ytComboBox.Sql = null;
            this.ifdepreciation_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ifdepreciation_ytComboBox.TabIndex = 4;
            this.ifdepreciation_ytComboBox.Tag = tvList2;
            this.ifdepreciation_ytComboBox.Value = null;
            // 
            // ifuse_ytComboBox
            // 
            this.ifuse_ytComboBox.CacheKey = null;
            this.ifuse_ytComboBox.DbConn = null;
            this.ifuse_ytComboBox.DefText = null;
            this.ifuse_ytComboBox.DefValue = null;
            this.ifuse_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ifuse_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ifuse_ytComboBox.EnableEmpty = true;
            this.ifuse_ytComboBox.FirstText = null;
            this.ifuse_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ifuse_ytComboBox.Fomart = null;
            this.ifuse_ytComboBox.ItemStr = "";
            this.ifuse_ytComboBox.Location = new System.Drawing.Point(125, 69);
            this.ifuse_ytComboBox.Name = "ifuse_ytComboBox";
            this.ifuse_ytComboBox.Param = null;
            this.ifuse_ytComboBox.Size = new System.Drawing.Size(121, 22);
            this.ifuse_ytComboBox.Sql = null;
            this.ifuse_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ifuse_ytComboBox.TabIndex = 2;
            this.ifuse_ytComboBox.Tag = tvList3;
            this.ifuse_ytComboBox.Value = null;
            // 
            // AddEQStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 411);
            this.Controls.Add(this.groupBox1);
            this.Name = "AddEQStatus";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "设备状态信息";
            this.Load += new System.EventHandler(this.AddEQStatus_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox groupBox1;
        private YtWinContrl.com.contrl.YTextBox choscode_yTextBox;
        private YtWinContrl.com.contrl.YTextBox username_yTextBox;
        private YtWinContrl.com.contrl.YTextBox userid_yTextBox;
        private YtWinContrl.com.contrl.YTextBox pycode_yTextBox;
        private YtWinContrl.com.contrl.YTextBox wbcode_yTextBox;
        private YtWinContrl.com.contrl.YTextBox memo_yTextBox;
        private YtWinContrl.com.contrl.YtComboBox ifuse_ytComboBox;
        private YtWinContrl.com.contrl.YtComboBox ifdepreciation_ytComboBox;
        private YtWinContrl.com.contrl.YtComboBox ifdefault_ytComboBox;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private YtWinContrl.com.contrl.YTextBox statuscode_yTextBox;
        private YtWinContrl.com.contrl.YTextBox statusname_yTextBox;
    }
}