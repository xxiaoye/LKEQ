﻿namespace JiChuDictionary.form
{
    partial class Kind_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList1 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList2 = new YtWinContrl.com.datagrid.TvList();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.yTextBox_PY = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_User = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Name = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_WB = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Rec = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_ifUse = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_ChCode = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_UpCode = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_UserID = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_IfEnd = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_LeiCode = new YtWinContrl.com.contrl.YTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.yTextBox_PY);
            this.groupBox2.Controls.Add(this.yTextBox_User);
            this.groupBox2.Controls.Add(this.yTextBox_Name);
            this.groupBox2.Controls.Add(this.yTextBox_WB);
            this.groupBox2.Controls.Add(this.yTextBox_Rec);
            this.groupBox2.Controls.Add(this.ytComboBox_ifUse);
            this.groupBox2.Controls.Add(this.yTextBox_ChCode);
            this.groupBox2.Controls.Add(this.yTextBox_UpCode);
            this.groupBox2.Controls.Add(this.yTextBox_UserID);
            this.groupBox2.Controls.Add(this.ytComboBox_IfEnd);
            this.groupBox2.Controls.Add(this.yTextBox_LeiCode);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(573, 230);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "基本信息";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(283, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 12);
            this.label6.TabIndex = 28;
            this.label6.Text = "设备卡号前缀字符";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(307, 113);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 12);
            this.label8.TabIndex = 27;
            this.label8.Text = "医疗机构编码";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(307, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 26;
            this.label11.Text = "是否末节点";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(307, 60);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 25;
            this.label12.Text = "上级编码";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(307, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 24;
            this.label13.Text = "类别编码";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(35, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 23;
            this.label4.Text = "备注";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(32, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 22;
            this.label2.Text = "操作员名称";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(32, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "是否使用";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(32, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 13;
            this.label10.Text = "五笔码";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "拼音码";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(32, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "类别名称";
            // 
            // yTextBox_PY
            // 
            // 
            // 
            // 
            this.yTextBox_PY.Border.Class = "TextBoxBorder";
            this.yTextBox_PY.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_PY.Location = new System.Drawing.Point(117, 53);
            this.yTextBox_PY.Name = "yTextBox_PY";
            this.yTextBox_PY.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_PY.TabIndex = 2;
            // 
            // yTextBox_User
            // 
            // 
            // 
            // 
            this.yTextBox_User.Border.Class = "TextBoxBorder";
            this.yTextBox_User.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_User.Location = new System.Drawing.Point(117, 137);
            this.yTextBox_User.Name = "yTextBox_User";
            this.yTextBox_User.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_User.TabIndex = 8;
            // 
            // yTextBox_Name
            // 
            // 
            // 
            // 
            this.yTextBox_Name.Border.Class = "TextBoxBorder";
            this.yTextBox_Name.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Name.Location = new System.Drawing.Point(117, 25);
            this.yTextBox_Name.Name = "yTextBox_Name";
            this.yTextBox_Name.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_Name.TabIndex = 0;
            // 
            // yTextBox_WB
            // 
            // 
            // 
            // 
            this.yTextBox_WB.Border.Class = "TextBoxBorder";
            this.yTextBox_WB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_WB.Location = new System.Drawing.Point(117, 80);
            this.yTextBox_WB.Name = "yTextBox_PY";
            this.yTextBox_WB.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_WB.TabIndex = 4;
            // 
            // yTextBox_Rec
            // 
            // 
            // 
            // 
            this.yTextBox_Rec.Border.Class = "TextBoxBorder";
            this.yTextBox_Rec.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Rec.Location = new System.Drawing.Point(117, 164);
            this.yTextBox_Rec.Name = "yTextBox_User";
            this.yTextBox_Rec.Size = new System.Drawing.Size(408, 21);
            this.yTextBox_Rec.TabIndex = 10;
            // 
            // ytComboBox_ifUse
            // 
            this.ytComboBox_ifUse.CacheKey = null;
            this.ytComboBox_ifUse.DbConn = null;
            this.ytComboBox_ifUse.DefText = null;
            this.ytComboBox_ifUse.DefValue = null;
            this.ytComboBox_ifUse.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_ifUse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_ifUse.EnableEmpty = true;
            this.ytComboBox_ifUse.FirstText = null;
            this.ytComboBox_ifUse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_ifUse.Fomart = null;
            this.ytComboBox_ifUse.ItemStr = "";
            this.ytComboBox_ifUse.Location = new System.Drawing.Point(117, 108);
            this.ytComboBox_ifUse.Name = "ytComboBox_ifUse";
            this.ytComboBox_ifUse.Param = null;
            this.ytComboBox_ifUse.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_ifUse.Sql = null;
            this.ytComboBox_ifUse.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_ifUse.TabIndex = 6;
            this.ytComboBox_ifUse.Tag = tvList1;
            this.ytComboBox_ifUse.Value = null;
            // 
            // yTextBox_ChCode
            // 
            // 
            // 
            // 
            this.yTextBox_ChCode.Border.Class = "TextBoxBorder";
            this.yTextBox_ChCode.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_ChCode.Location = new System.Drawing.Point(407, 108);
            this.yTextBox_ChCode.Name = "yTextBox_PY";
            this.yTextBox_ChCode.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_ChCode.TabIndex = 7;
            // 
            // yTextBox_UpCode
            // 
            // 
            // 
            // 
            this.yTextBox_UpCode.Border.Class = "TextBoxBorder";
            this.yTextBox_UpCode.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_UpCode.Location = new System.Drawing.Point(407, 53);
            this.yTextBox_UpCode.Name = "yTextBox_PY";
            this.yTextBox_UpCode.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_UpCode.TabIndex = 3;
            // 
            // yTextBox_UserID
            // 
            // 
            // 
            // 
            this.yTextBox_UserID.Border.Class = "TextBoxBorder";
            this.yTextBox_UserID.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_UserID.Location = new System.Drawing.Point(407, 136);
            this.yTextBox_UserID.Name = "yTextBox_User";
            this.yTextBox_UserID.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_UserID.TabIndex = 9;
            // 
            // ytComboBox_IfEnd
            // 
            this.ytComboBox_IfEnd.CacheKey = null;
            this.ytComboBox_IfEnd.DbConn = null;
            this.ytComboBox_IfEnd.DefText = null;
            this.ytComboBox_IfEnd.DefValue = null;
            this.ytComboBox_IfEnd.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_IfEnd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_IfEnd.EnableEmpty = true;
            this.ytComboBox_IfEnd.FirstText = null;
            this.ytComboBox_IfEnd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_IfEnd.Fomart = null;
            this.ytComboBox_IfEnd.ItemStr = "";
            this.ytComboBox_IfEnd.Location = new System.Drawing.Point(407, 80);
            this.ytComboBox_IfEnd.Name = "ytComboBox_ifUse";
            this.ytComboBox_IfEnd.Param = null;
            this.ytComboBox_IfEnd.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_IfEnd.Sql = null;
            this.ytComboBox_IfEnd.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_IfEnd.TabIndex = 5;
            this.ytComboBox_IfEnd.Tag = tvList2;
            this.ytComboBox_IfEnd.Value = null;
            // 
            // yTextBox_LeiCode
            // 
            // 
            // 
            // 
            this.yTextBox_LeiCode.Border.Class = "TextBoxBorder";
            this.yTextBox_LeiCode.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_LeiCode.Location = new System.Drawing.Point(407, 25);
            this.yTextBox_LeiCode.Name = "yTextBox_Name";
            this.yTextBox_LeiCode.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_LeiCode.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(355, 262);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(74, 26);
            this.button2.TabIndex = 12;
            this.button2.Text = "取消";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(142, 262);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 26);
            this.button1.TabIndex = 11;
            this.button1.Text = "保存";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Kind_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(598, 294);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Kind_Add";
            this.Text = "设备类别信息";
            this.Load += new System.EventHandler(this.EQKind_Add_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private YtWinContrl.com.contrl.YTextBox yTextBox_PY;
        private YtWinContrl.com.contrl.YTextBox yTextBox_User;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Name;
        private YtWinContrl.com.contrl.YTextBox yTextBox_WB;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Rec;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_ifUse;
        private YtWinContrl.com.contrl.YTextBox yTextBox_ChCode;
        private YtWinContrl.com.contrl.YTextBox yTextBox_UpCode;
        private YtWinContrl.com.contrl.YTextBox yTextBox_UserID;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_IfEnd;
        private YtWinContrl.com.contrl.YTextBox yTextBox_LeiCode;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
    }
}