﻿namespace JiChuDictionary.form
{
    partial class FixKind_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList3 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList4 = new YtWinContrl.com.datagrid.TvList();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ytDateTime_RECDATE = new YtWinContrl.com.contrl.YTDateTime();
            this.label20 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.yTextBox_PY = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_User = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Name = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_WB = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Rec = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_ifUse = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_ChCode = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_UserID = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_IfDefault = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_FixKindCode = new YtWinContrl.com.contrl.YTextBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ytDateTime_RECDATE);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.yTextBox_PY);
            this.groupBox2.Controls.Add(this.yTextBox_User);
            this.groupBox2.Controls.Add(this.yTextBox_Name);
            this.groupBox2.Controls.Add(this.yTextBox_WB);
            this.groupBox2.Controls.Add(this.yTextBox_Rec);
            this.groupBox2.Controls.Add(this.ytComboBox_ifUse);
            this.groupBox2.Controls.Add(this.yTextBox_ChCode);
            this.groupBox2.Controls.Add(this.yTextBox_UserID);
            this.groupBox2.Controls.Add(this.ytComboBox_IfDefault);
            this.groupBox2.Controls.Add(this.yTextBox_FixKindCode);
            this.groupBox2.Location = new System.Drawing.Point(19, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(646, 250);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "基本信息";
            // 
            // ytDateTime_RECDATE
            // 
            this.ytDateTime_RECDATE.CustomFormat = "yyyy-MM-dd HH:mm";
            this.ytDateTime_RECDATE.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ytDateTime_RECDATE.Location = new System.Drawing.Point(447, 157);
            this.ytDateTime_RECDATE.Name = "ytDateTime_RECDATE";
            this.ytDateTime_RECDATE.Size = new System.Drawing.Size(119, 21);
            this.ytDateTime_RECDATE.TabIndex = 9;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Blue;
            this.label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label20.Location = new System.Drawing.Point(351, 160);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 53;
            this.label20.Text = "修改时间";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(351, 132);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 28;
            this.label6.Text = "操作员ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(351, 104);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 12);
            this.label8.TabIndex = 27;
            this.label8.Text = "医疗机构编码";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(351, 77);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 25;
            this.label12.Text = "是否默认值";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(351, 46);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 24;
            this.label13.Text = "类别编码";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(68, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 23;
            this.label4.Text = "备注";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(66, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 22;
            this.label2.Text = "操作员名称";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(66, 132);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "是否使用";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(66, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 13;
            this.label10.Text = "五笔码";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "拼音码";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(66, 45);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "类别名称";
            // 
            // yTextBox_PY
            // 
            // 
            // 
            // 
            this.yTextBox_PY.Border.Class = "TextBoxBorder";
            this.yTextBox_PY.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_PY.Location = new System.Drawing.Point(151, 69);
            this.yTextBox_PY.Name = "yTextBox_PY";
            this.yTextBox_PY.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_PY.TabIndex = 2;
            // 
            // yTextBox_User
            // 
            // 
            // 
            // 
            this.yTextBox_User.Border.Class = "TextBoxBorder";
            this.yTextBox_User.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_User.Location = new System.Drawing.Point(151, 155);
            this.yTextBox_User.Name = "yTextBox_User";
            this.yTextBox_User.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_User.TabIndex = 8;
            // 
            // yTextBox_Name
            // 
            // 
            // 
            // 
            this.yTextBox_Name.Border.Class = "TextBoxBorder";
            this.yTextBox_Name.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Name.Location = new System.Drawing.Point(151, 41);
            this.yTextBox_Name.Name = "yTextBox_Name";
            this.yTextBox_Name.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_Name.TabIndex = 0;
            // 
            // yTextBox_WB
            // 
            // 
            // 
            // 
            this.yTextBox_WB.Border.Class = "TextBoxBorder";
            this.yTextBox_WB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_WB.Location = new System.Drawing.Point(151, 96);
            this.yTextBox_WB.Name = "yTextBox_PY";
            this.yTextBox_WB.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_WB.TabIndex = 4;
            // 
            // yTextBox_Rec
            // 
            // 
            // 
            // 
            this.yTextBox_Rec.Border.Class = "TextBoxBorder";
            this.yTextBox_Rec.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Rec.Location = new System.Drawing.Point(150, 187);
            this.yTextBox_Rec.Name = "yTextBox_User";
            this.yTextBox_Rec.Size = new System.Drawing.Size(417, 21);
            this.yTextBox_Rec.TabIndex = 10;
            // 
            // ytComboBox_ifUse
            // 
            this.ytComboBox_ifUse.CacheKey = null;
            this.ytComboBox_ifUse.DbConn = null;
            this.ytComboBox_ifUse.DefText = null;
            this.ytComboBox_ifUse.DefValue = null;
            this.ytComboBox_ifUse.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_ifUse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_ifUse.EnableEmpty = true;
            this.ytComboBox_ifUse.FirstText = null;
            this.ytComboBox_ifUse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_ifUse.Fomart = null;
            this.ytComboBox_ifUse.ItemStr = "";
            this.ytComboBox_ifUse.Location = new System.Drawing.Point(151, 126);
            this.ytComboBox_ifUse.Name = "ytComboBox_ifUse";
            this.ytComboBox_ifUse.Param = null;
            this.ytComboBox_ifUse.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_ifUse.Sql = null;
            this.ytComboBox_ifUse.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_ifUse.TabIndex = 6;
            this.ytComboBox_ifUse.Tag = tvList3;
            this.ytComboBox_ifUse.Value = null;
            // 
            // yTextBox_ChCode
            // 
            // 
            // 
            // 
            this.yTextBox_ChCode.Border.Class = "TextBoxBorder";
            this.yTextBox_ChCode.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_ChCode.Location = new System.Drawing.Point(449, 98);
            this.yTextBox_ChCode.Name = "yTextBox_PY";
            this.yTextBox_ChCode.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_ChCode.TabIndex = 5;
            // 
            // yTextBox_UserID
            // 
            // 
            // 
            // 
            this.yTextBox_UserID.Border.Class = "TextBoxBorder";
            this.yTextBox_UserID.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_UserID.Location = new System.Drawing.Point(449, 127);
            this.yTextBox_UserID.Name = "yTextBox_User";
            this.yTextBox_UserID.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_UserID.TabIndex = 7;
            // 
            // ytComboBox_IfDefault
            // 
            this.ytComboBox_IfDefault.CacheKey = null;
            this.ytComboBox_IfDefault.DbConn = null;
            this.ytComboBox_IfDefault.DefText = null;
            this.ytComboBox_IfDefault.DefValue = null;
            this.ytComboBox_IfDefault.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_IfDefault.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_IfDefault.EnableEmpty = true;
            this.ytComboBox_IfDefault.FirstText = null;
            this.ytComboBox_IfDefault.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_IfDefault.Fomart = null;
            this.ytComboBox_IfDefault.ItemStr = "";
            this.ytComboBox_IfDefault.Location = new System.Drawing.Point(449, 69);
            this.ytComboBox_IfDefault.Name = "ytComboBox_ifUse";
            this.ytComboBox_IfDefault.Param = null;
            this.ytComboBox_IfDefault.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_IfDefault.Sql = null;
            this.ytComboBox_IfDefault.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_IfDefault.TabIndex = 3;
            this.ytComboBox_IfDefault.Tag = tvList4;
            this.ytComboBox_IfDefault.Value = null;
            // 
            // yTextBox_FixKindCode
            // 
            // 
            // 
            // 
            this.yTextBox_FixKindCode.Border.Class = "TextBoxBorder";
            this.yTextBox_FixKindCode.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_FixKindCode.Location = new System.Drawing.Point(449, 42);
            this.yTextBox_FixKindCode.Name = "yTextBox_Name";
            this.yTextBox_FixKindCode.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_FixKindCode.TabIndex = 1;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(447, 285);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(74, 26);
            this.btn_Cancel.TabIndex = 12;
            this.btn_Cancel.Text = "取消";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(170, 285);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(74, 26);
            this.btn_Save.TabIndex = 11;
            this.btn_Save.Text = "保存";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // FixKind_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(698, 326);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.groupBox2);
            this.Name = "FixKind_Add";
            this.Text = "维修类别信息";
            this.Load += new System.EventHandler(this.FixKind_Add_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private YtWinContrl.com.contrl.YTextBox yTextBox_PY;
        private YtWinContrl.com.contrl.YTextBox yTextBox_User;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Name;
        private YtWinContrl.com.contrl.YTextBox yTextBox_WB;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Rec;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_ifUse;
        private YtWinContrl.com.contrl.YTextBox yTextBox_ChCode;
        private YtWinContrl.com.contrl.YTextBox yTextBox_UserID;
        private YtWinContrl.com.contrl.YTextBox yTextBox_FixKindCode;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_IfDefault;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Save;
        private YtWinContrl.com.contrl.YTDateTime ytDateTime_RECDATE;
        private System.Windows.Forms.Label label20;
    }
}