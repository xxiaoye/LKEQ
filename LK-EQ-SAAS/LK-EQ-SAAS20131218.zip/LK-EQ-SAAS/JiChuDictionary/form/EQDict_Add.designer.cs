﻿namespace JiChuDictionary.form
{
    partial class EQDict_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList8 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList9 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList10 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList11 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList12 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList13 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList14 = new YtWinContrl.com.datagrid.TvList();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ytDateTime_RECDATE = new YtWinContrl.com.contrl.YTDateTime();
            this.label20 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.selTextInpt_PRODUCTPLACE = new YtWinContrl.com.contrl.SelTextInpt();
            this.label5 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.yTextBox_PY = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_User = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Name = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_WB = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_Rec = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_ifUse = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_BM = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_UserID = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_CountCode = new YtWinContrl.com.contrl.YtComboBox();
            this.ytComboBox_KindCode = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_BMJM = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_GuiG = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_ZJRATE = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_JM = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_JC = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_EQID = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_SingerCode = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_TiaoXM = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_IFJL = new YtWinContrl.com.contrl.YtComboBox();
            this.ytComboBox_WORKUNITCODE = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_Choscode = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_XH = new YtWinContrl.com.contrl.YTextBox();
            this.ytComboBox_ZJTYPE = new YtWinContrl.com.contrl.YtComboBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ytDateTime_RECDATE);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.selTextInpt_PRODUCTPLACE);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.yTextBox_PY);
            this.groupBox2.Controls.Add(this.yTextBox_User);
            this.groupBox2.Controls.Add(this.yTextBox_Name);
            this.groupBox2.Controls.Add(this.yTextBox_WB);
            this.groupBox2.Controls.Add(this.yTextBox_Rec);
            this.groupBox2.Controls.Add(this.ytComboBox_ifUse);
            this.groupBox2.Controls.Add(this.yTextBox_BM);
            this.groupBox2.Controls.Add(this.yTextBox_UserID);
            this.groupBox2.Controls.Add(this.ytComboBox_CountCode);
            this.groupBox2.Controls.Add(this.ytComboBox_KindCode);
            this.groupBox2.Controls.Add(this.yTextBox_BMJM);
            this.groupBox2.Controls.Add(this.yTextBox_GuiG);
            this.groupBox2.Controls.Add(this.yTextBox_ZJRATE);
            this.groupBox2.Controls.Add(this.yTextBox_JM);
            this.groupBox2.Controls.Add(this.yTextBox_JC);
            this.groupBox2.Controls.Add(this.yTextBox_EQID);
            this.groupBox2.Controls.Add(this.ytComboBox_SingerCode);
            this.groupBox2.Controls.Add(this.yTextBox_TiaoXM);
            this.groupBox2.Controls.Add(this.ytComboBox_IFJL);
            this.groupBox2.Controls.Add(this.ytComboBox_WORKUNITCODE);
            this.groupBox2.Controls.Add(this.yTextBox_Choscode);
            this.groupBox2.Controls.Add(this.yTextBox_XH);
            this.groupBox2.Controls.Add(this.ytComboBox_ZJTYPE);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(808, 301);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "基本信息";
            // 
            // ytDateTime_RECDATE
            // 
            this.ytDateTime_RECDATE.CustomFormat = "yyyy-MM-dd hh:mm";
            this.ytDateTime_RECDATE.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ytDateTime_RECDATE.Location = new System.Drawing.Point(359, 224);
            this.ytDateTime_RECDATE.Name = "ytDateTime_RECDATE";
            this.ytDateTime_RECDATE.Size = new System.Drawing.Size(119, 21);
            this.ytDateTime_RECDATE.TabIndex = 22;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Blue;
            this.label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label20.Location = new System.Drawing.Point(260, 228);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 51;
            this.label20.Text = "修改时间";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(505, 171);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 49;
            this.label7.Text = "型号";
            // 
            // selTextInpt_PRODUCTPLACE
            // 
            this.selTextInpt_PRODUCTPLACE.ColDefText = null;
            this.selTextInpt_PRODUCTPLACE.ColStyle = null;
            this.selTextInpt_PRODUCTPLACE.DataType = null;
            this.selTextInpt_PRODUCTPLACE.DbConn = null;
            this.selTextInpt_PRODUCTPLACE.Location = new System.Drawing.Point(117, 166);
            this.selTextInpt_PRODUCTPLACE.Name = "selTextInpt_PRODUCTPLACE";
            this.selTextInpt_PRODUCTPLACE.NextFocusControl = null;
            this.selTextInpt_PRODUCTPLACE.ReadOnly = false;
            this.selTextInpt_PRODUCTPLACE.SelParam = null;
            this.selTextInpt_PRODUCTPLACE.ShowColNum = 0;
            this.selTextInpt_PRODUCTPLACE.ShowWidth = 0;
            this.selTextInpt_PRODUCTPLACE.Size = new System.Drawing.Size(117, 22);
            this.selTextInpt_PRODUCTPLACE.Sql = null;
            this.selTextInpt_PRODUCTPLACE.SqlStr = null;
            this.selTextInpt_PRODUCTPLACE.TabIndex = 15;
            this.selTextInpt_PRODUCTPLACE.TvColName = null;
            this.selTextInpt_PRODUCTPLACE.Value = null;
            this.selTextInpt_PRODUCTPLACE.WatermarkText = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(27, 228);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 47;
            this.label5.Text = "医疗机构编码";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label30.Location = new System.Drawing.Point(262, 144);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(41, 12);
            this.label30.TabIndex = 46;
            this.label30.Text = "条形码";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.Color.Blue;
            this.label26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label26.Location = new System.Drawing.Point(262, 171);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 12);
            this.label26.TabIndex = 43;
            this.label26.Text = "是否使用";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label17.Location = new System.Drawing.Point(505, 144);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 42;
            this.label17.Text = "规格";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Blue;
            this.label25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label25.Location = new System.Drawing.Point(22, 144);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 41;
            this.label25.Text = "是否计量设备";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label24.Location = new System.Drawing.Point(44, 171);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 12);
            this.label24.TabIndex = 40;
            this.label24.Text = "产地";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label23.Location = new System.Drawing.Point(262, 199);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 12);
            this.label23.TabIndex = 39;
            this.label23.Text = "年折旧百分比";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(505, 116);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 34;
            this.label14.Text = "别名简码";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(505, 88);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 33;
            this.label15.Text = "别名";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Blue;
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(32, 196);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 32;
            this.label16.Text = "折旧方式";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(505, 60);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 30;
            this.label18.Text = "简码";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(505, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 29;
            this.label19.Text = "简称";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(505, 199);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 28;
            this.label6.Text = "操作员ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(251, 116);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 12);
            this.label8.TabIndex = 27;
            this.label8.Text = "工作量单位编码";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(262, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 26;
            this.label11.Text = "统计编码";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(262, 60);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 25;
            this.label12.Text = "所属类别";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(262, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 24;
            this.label13.Text = "设备ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(32, 256);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 23;
            this.label4.Text = "备注";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(505, 227);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 22;
            this.label2.Text = "操作员名称";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(32, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "单位编码";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(32, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 13;
            this.label10.Text = "五笔码";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "拼音码";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(32, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "设备名称";
            // 
            // yTextBox_PY
            // 
            // 
            // 
            // 
            this.yTextBox_PY.Border.Class = "TextBoxBorder";
            this.yTextBox_PY.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_PY.Location = new System.Drawing.Point(117, 53);
            this.yTextBox_PY.Name = "yTextBox_PY";
            this.yTextBox_PY.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_PY.TabIndex = 3;
            // 
            // yTextBox_User
            // 
            // 
            // 
            // 
            this.yTextBox_User.Border.Class = "TextBoxBorder";
            this.yTextBox_User.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_User.Location = new System.Drawing.Point(586, 222);
            this.yTextBox_User.Name = "yTextBox_User";
            this.yTextBox_User.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_User.TabIndex = 23;
            // 
            // yTextBox_Name
            // 
            // 
            // 
            // 
            this.yTextBox_Name.Border.Class = "TextBoxBorder";
            this.yTextBox_Name.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Name.Location = new System.Drawing.Point(117, 25);
            this.yTextBox_Name.Name = "yTextBox_Name";
            this.yTextBox_Name.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_Name.TabIndex = 0;
            // 
            // yTextBox_WB
            // 
            // 
            // 
            // 
            this.yTextBox_WB.Border.Class = "TextBoxBorder";
            this.yTextBox_WB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_WB.Location = new System.Drawing.Point(117, 80);
            this.yTextBox_WB.Name = "yTextBox_PY";
            this.yTextBox_WB.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_WB.TabIndex = 6;
            // 
            // yTextBox_Rec
            // 
            // 
            // 
            // 
            this.yTextBox_Rec.Border.Class = "TextBoxBorder";
            this.yTextBox_Rec.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Rec.Location = new System.Drawing.Point(117, 251);
            this.yTextBox_Rec.Name = "yTextBox_User";
            this.yTextBox_Rec.Size = new System.Drawing.Size(587, 21);
            this.yTextBox_Rec.TabIndex = 24;
            // 
            // ytComboBox_ifUse
            // 
            this.ytComboBox_ifUse.CacheKey = null;
            this.ytComboBox_ifUse.DbConn = null;
            this.ytComboBox_ifUse.DefText = null;
            this.ytComboBox_ifUse.DefValue = null;
            this.ytComboBox_ifUse.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_ifUse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_ifUse.EnableEmpty = true;
            this.ytComboBox_ifUse.FirstText = null;
            this.ytComboBox_ifUse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_ifUse.Fomart = null;
            this.ytComboBox_ifUse.ItemStr = "";
            this.ytComboBox_ifUse.Location = new System.Drawing.Point(360, 165);
            this.ytComboBox_ifUse.Name = "ytComboBox_ifUse";
            this.ytComboBox_ifUse.Param = null;
            this.ytComboBox_ifUse.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_ifUse.Sql = null;
            this.ytComboBox_ifUse.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_ifUse.TabIndex = 16;
            this.ytComboBox_ifUse.Tag = tvList8;
            this.ytComboBox_ifUse.Value = null;
            // 
            // yTextBox_BM
            // 
            // 
            // 
            // 
            this.yTextBox_BM.Border.Class = "TextBoxBorder";
            this.yTextBox_BM.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_BM.Location = new System.Drawing.Point(585, 83);
            this.yTextBox_BM.Name = "yTextBox_PY";
            this.yTextBox_BM.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_BM.TabIndex = 8;
            // 
            // yTextBox_UserID
            // 
            // 
            // 
            // 
            this.yTextBox_UserID.Border.Class = "TextBoxBorder";
            this.yTextBox_UserID.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_UserID.Location = new System.Drawing.Point(586, 194);
            this.yTextBox_UserID.Name = "yTextBox_User";
            this.yTextBox_UserID.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_UserID.TabIndex = 20;
            // 
            // ytComboBox_CountCode
            // 
            this.ytComboBox_CountCode.CacheKey = null;
            this.ytComboBox_CountCode.DbConn = null;
            this.ytComboBox_CountCode.DefText = null;
            this.ytComboBox_CountCode.DefValue = null;
            this.ytComboBox_CountCode.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_CountCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_CountCode.EnableEmpty = true;
            this.ytComboBox_CountCode.FirstText = null;
            this.ytComboBox_CountCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_CountCode.Fomart = null;
            this.ytComboBox_CountCode.ItemStr = "";
            this.ytComboBox_CountCode.Location = new System.Drawing.Point(360, 80);
            this.ytComboBox_CountCode.Name = "ytComboBox_ifUse";
            this.ytComboBox_CountCode.Param = null;
            this.ytComboBox_CountCode.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_CountCode.Sql = null;
            this.ytComboBox_CountCode.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_CountCode.TabIndex = 7;
            this.ytComboBox_CountCode.Tag = tvList9;
            this.ytComboBox_CountCode.Value = null;
            // 
            // ytComboBox_KindCode
            // 
            this.ytComboBox_KindCode.CacheKey = null;
            this.ytComboBox_KindCode.DbConn = null;
            this.ytComboBox_KindCode.DefText = null;
            this.ytComboBox_KindCode.DefValue = null;
            this.ytComboBox_KindCode.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_KindCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_KindCode.EnableEmpty = true;
            this.ytComboBox_KindCode.FirstText = null;
            this.ytComboBox_KindCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_KindCode.Fomart = null;
            this.ytComboBox_KindCode.ItemStr = "";
            this.ytComboBox_KindCode.Location = new System.Drawing.Point(360, 52);
            this.ytComboBox_KindCode.Name = "ytComboBox_ifUse";
            this.ytComboBox_KindCode.Param = null;
            this.ytComboBox_KindCode.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_KindCode.Sql = null;
            this.ytComboBox_KindCode.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_KindCode.TabIndex = 4;
            this.ytComboBox_KindCode.Tag = tvList10;
            this.ytComboBox_KindCode.Value = null;
            // 
            // yTextBox_BMJM
            // 
            // 
            // 
            // 
            this.yTextBox_BMJM.Border.Class = "TextBoxBorder";
            this.yTextBox_BMJM.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_BMJM.Location = new System.Drawing.Point(586, 112);
            this.yTextBox_BMJM.Name = "yTextBox_User";
            this.yTextBox_BMJM.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_BMJM.TabIndex = 11;
            // 
            // yTextBox_GuiG
            // 
            // 
            // 
            // 
            this.yTextBox_GuiG.Border.Class = "TextBoxBorder";
            this.yTextBox_GuiG.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_GuiG.Location = new System.Drawing.Point(586, 139);
            this.yTextBox_GuiG.Name = "yTextBox_User";
            this.yTextBox_GuiG.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_GuiG.TabIndex = 14;
            // 
            // yTextBox_ZJRATE
            // 
            // 
            // 
            // 
            this.yTextBox_ZJRATE.Border.Class = "TextBoxBorder";
            this.yTextBox_ZJRATE.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_ZJRATE.Location = new System.Drawing.Point(360, 194);
            this.yTextBox_ZJRATE.Name = "yTextBox_User";
            this.yTextBox_ZJRATE.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_ZJRATE.TabIndex = 19;
            // 
            // yTextBox_JM
            // 
            // 
            // 
            // 
            this.yTextBox_JM.Border.Class = "TextBoxBorder";
            this.yTextBox_JM.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_JM.Location = new System.Drawing.Point(585, 54);
            this.yTextBox_JM.Name = "yTextBox_PY";
            this.yTextBox_JM.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_JM.TabIndex = 5;
            // 
            // yTextBox_JC
            // 
            // 
            // 
            // 
            this.yTextBox_JC.Border.Class = "TextBoxBorder";
            this.yTextBox_JC.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_JC.Location = new System.Drawing.Point(585, 26);
            this.yTextBox_JC.Name = "yTextBox_Name";
            this.yTextBox_JC.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_JC.TabIndex = 2;
            // 
            // yTextBox_EQID
            // 
            // 
            // 
            // 
            this.yTextBox_EQID.Border.Class = "TextBoxBorder";
            this.yTextBox_EQID.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_EQID.Location = new System.Drawing.Point(360, 25);
            this.yTextBox_EQID.Name = "yTextBox_Name";
            this.yTextBox_EQID.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_EQID.TabIndex = 1;
            // 
            // ytComboBox_SingerCode
            // 
            this.ytComboBox_SingerCode.CacheKey = null;
            this.ytComboBox_SingerCode.DbConn = null;
            this.ytComboBox_SingerCode.DefText = null;
            this.ytComboBox_SingerCode.DefValue = null;
            this.ytComboBox_SingerCode.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_SingerCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_SingerCode.EnableEmpty = true;
            this.ytComboBox_SingerCode.FirstText = null;
            this.ytComboBox_SingerCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_SingerCode.Fomart = null;
            this.ytComboBox_SingerCode.ItemStr = "";
            this.ytComboBox_SingerCode.Location = new System.Drawing.Point(117, 109);
            this.ytComboBox_SingerCode.Name = "ytComboBox_ifUse";
            this.ytComboBox_SingerCode.Param = null;
            this.ytComboBox_SingerCode.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_SingerCode.Sql = null;
            this.ytComboBox_SingerCode.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_SingerCode.TabIndex = 9;
            this.ytComboBox_SingerCode.Tag = tvList11;
            this.ytComboBox_SingerCode.Value = null;
            // 
            // yTextBox_TiaoXM
            // 
            // 
            // 
            // 
            this.yTextBox_TiaoXM.Border.Class = "TextBoxBorder";
            this.yTextBox_TiaoXM.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_TiaoXM.Location = new System.Drawing.Point(360, 138);
            this.yTextBox_TiaoXM.Name = "yTextBox_User";
            this.yTextBox_TiaoXM.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_TiaoXM.TabIndex = 13;
            // 
            // ytComboBox_IFJL
            // 
            this.ytComboBox_IFJL.CacheKey = null;
            this.ytComboBox_IFJL.DbConn = null;
            this.ytComboBox_IFJL.DefText = null;
            this.ytComboBox_IFJL.DefValue = null;
            this.ytComboBox_IFJL.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_IFJL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_IFJL.EnableEmpty = true;
            this.ytComboBox_IFJL.FirstText = null;
            this.ytComboBox_IFJL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_IFJL.Fomart = null;
            this.ytComboBox_IFJL.ItemStr = "";
            this.ytComboBox_IFJL.Location = new System.Drawing.Point(117, 139);
            this.ytComboBox_IFJL.Name = "ytComboBox_ifUse";
            this.ytComboBox_IFJL.Param = null;
            this.ytComboBox_IFJL.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_IFJL.Sql = null;
            this.ytComboBox_IFJL.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_IFJL.TabIndex = 12;
            this.ytComboBox_IFJL.Tag = tvList12;
            this.ytComboBox_IFJL.Value = null;
            // 
            // ytComboBox_WORKUNITCODE
            // 
            this.ytComboBox_WORKUNITCODE.CacheKey = null;
            this.ytComboBox_WORKUNITCODE.DbConn = null;
            this.ytComboBox_WORKUNITCODE.DefText = null;
            this.ytComboBox_WORKUNITCODE.DefValue = null;
            this.ytComboBox_WORKUNITCODE.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_WORKUNITCODE.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_WORKUNITCODE.EnableEmpty = true;
            this.ytComboBox_WORKUNITCODE.FirstText = null;
            this.ytComboBox_WORKUNITCODE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_WORKUNITCODE.Fomart = null;
            this.ytComboBox_WORKUNITCODE.ItemStr = "";
            this.ytComboBox_WORKUNITCODE.Location = new System.Drawing.Point(360, 109);
            this.ytComboBox_WORKUNITCODE.Name = "ytComboBox_ifUse";
            this.ytComboBox_WORKUNITCODE.Param = null;
            this.ytComboBox_WORKUNITCODE.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_WORKUNITCODE.Sql = null;
            this.ytComboBox_WORKUNITCODE.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_WORKUNITCODE.TabIndex = 10;
            this.ytComboBox_WORKUNITCODE.Tag = tvList13;
            this.ytComboBox_WORKUNITCODE.Value = null;
            // 
            // yTextBox_Choscode
            // 
            // 
            // 
            // 
            this.yTextBox_Choscode.Border.Class = "TextBoxBorder";
            this.yTextBox_Choscode.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_Choscode.Location = new System.Drawing.Point(117, 223);
            this.yTextBox_Choscode.Name = "yTextBox_User";
            this.yTextBox_Choscode.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_Choscode.TabIndex = 21;
            // 
            // yTextBox_XH
            // 
            // 
            // 
            // 
            this.yTextBox_XH.Border.Class = "TextBoxBorder";
            this.yTextBox_XH.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_XH.Location = new System.Drawing.Point(586, 166);
            this.yTextBox_XH.Name = "yTextBox_User";
            this.yTextBox_XH.Size = new System.Drawing.Size(117, 21);
            this.yTextBox_XH.TabIndex = 17;
            // 
            // ytComboBox_ZJTYPE
            // 
            this.ytComboBox_ZJTYPE.CacheKey = null;
            this.ytComboBox_ZJTYPE.DbConn = null;
            this.ytComboBox_ZJTYPE.DefText = null;
            this.ytComboBox_ZJTYPE.DefValue = null;
            this.ytComboBox_ZJTYPE.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_ZJTYPE.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_ZJTYPE.EnableEmpty = true;
            this.ytComboBox_ZJTYPE.FirstText = null;
            this.ytComboBox_ZJTYPE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_ZJTYPE.Fomart = null;
            this.ytComboBox_ZJTYPE.ItemStr = "";
            this.ytComboBox_ZJTYPE.Location = new System.Drawing.Point(117, 195);
            this.ytComboBox_ZJTYPE.Name = "ytComboBox_ifUse";
            this.ytComboBox_ZJTYPE.Param = null;
            this.ytComboBox_ZJTYPE.Size = new System.Drawing.Size(117, 22);
            this.ytComboBox_ZJTYPE.Sql = null;
            this.ytComboBox_ZJTYPE.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_ZJTYPE.TabIndex = 18;
            this.ytComboBox_ZJTYPE.Tag = tvList14;
            this.ytComboBox_ZJTYPE.Value = null;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(532, 342);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(74, 26);
            this.btn_Cancel.TabIndex = 26;
            this.btn_Cancel.Text = "取消";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(265, 342);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(74, 26);
            this.btn_Save.TabIndex = 25;
            this.btn_Save.Text = "保存";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // EQDict_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(842, 392);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.groupBox2);
            this.Name = "EQDict_Add";
            this.Text = "设备字典信息";
            this.Load += new System.EventHandler(this.WZDict_Add_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private YtWinContrl.com.contrl.YTextBox yTextBox_PY;
        private YtWinContrl.com.contrl.YTextBox yTextBox_User;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Name;
        private YtWinContrl.com.contrl.YTextBox yTextBox_WB;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Rec;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_ifUse;
        private YtWinContrl.com.contrl.YTextBox yTextBox_BM;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_CountCode;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_KindCode;
        private YtWinContrl.com.contrl.YTextBox yTextBox_BMJM;
        private YtWinContrl.com.contrl.YTextBox yTextBox_GuiG;
        private YtWinContrl.com.contrl.YTextBox yTextBox_ZJRATE;
        private YtWinContrl.com.contrl.YTextBox yTextBox_JM;
        private YtWinContrl.com.contrl.YTextBox yTextBox_JC;
        private YtWinContrl.com.contrl.YTextBox yTextBox_EQID;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_WORKUNITCODE;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label26;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_SingerCode;
        private YtWinContrl.com.contrl.YTextBox yTextBox_TiaoXM;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_IFJL;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label label5;
        private YtWinContrl.com.contrl.YTextBox yTextBox_Choscode;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt_PRODUCTPLACE;
        private System.Windows.Forms.Label label6;
        private YtWinContrl.com.contrl.YTextBox yTextBox_UserID;
        private System.Windows.Forms.Label label7;
        private YtWinContrl.com.contrl.YTextBox yTextBox_XH;
        private System.Windows.Forms.Label label20;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_ZJTYPE;
        private YtWinContrl.com.contrl.YTDateTime ytDateTime_RECDATE;
    }
}