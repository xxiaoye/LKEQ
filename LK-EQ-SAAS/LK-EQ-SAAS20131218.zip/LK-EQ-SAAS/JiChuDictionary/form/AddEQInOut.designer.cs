﻿namespace JiChuDictionary.form
{
    partial class AddEQInOut
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList7 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList8 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList9 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList10 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList11 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList12 = new YtWinContrl.com.datagrid.TvList();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.wbcode_textBox = new System.Windows.Forms.TextBox();
            this.memo_textBox = new System.Windows.Forms.TextBox();
            this.pycode_textBox = new System.Windows.Forms.TextBox();
            this.userid_textBox = new System.Windows.Forms.TextBox();
            this.username_textBox = new System.Windows.Forms.TextBox();
            this.choscode_textBox = new System.Windows.Forms.TextBox();
            this.recipelength_textBox = new System.Windows.Forms.TextBox();
            this.recipecode_textBox = new System.Windows.Forms.TextBox();
            this.ioname_textBox = new System.Windows.Forms.TextBox();
            this.ioid_textBox = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.ifdefault_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.recipemonth_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.recipeyear_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.ifuse_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.ioflag_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.opflag_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(35, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "入出库ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(35, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "入出名称";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(304, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "是否使用";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(35, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "单据前缀";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(34, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "单据编码长度";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(35, 170);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "单据年份";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(35, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "单据月份";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(304, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "入出标志";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(304, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "操作标志";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(304, 135);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "是否默认值";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.Location = new System.Drawing.Point(304, 205);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "操作员ID";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(304, 240);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "操作员名称";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(304, 170);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "修改时间";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(35, 240);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "医疗机构编码";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(304, 297);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "五笔码";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(42, 299);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 12);
            this.label16.TabIndex = 0;
            this.label16.Text = "拼音码";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(47, 324);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "备注";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.wbcode_textBox);
            this.groupBox1.Controls.Add(this.memo_textBox);
            this.groupBox1.Controls.Add(this.pycode_textBox);
            this.groupBox1.Controls.Add(this.userid_textBox);
            this.groupBox1.Controls.Add(this.username_textBox);
            this.groupBox1.Controls.Add(this.choscode_textBox);
            this.groupBox1.Controls.Add(this.recipelength_textBox);
            this.groupBox1.Controls.Add(this.recipecode_textBox);
            this.groupBox1.Controls.Add(this.ioname_textBox);
            this.groupBox1.Controls.Add(this.ioid_textBox);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.ifdefault_ytComboBox);
            this.groupBox1.Controls.Add(this.recipemonth_ytComboBox);
            this.groupBox1.Controls.Add(this.recipeyear_ytComboBox);
            this.groupBox1.Controls.Add(this.ifuse_ytComboBox);
            this.groupBox1.Controls.Add(this.ioflag_ytComboBox);
            this.groupBox1.Controls.Add(this.opflag_ytComboBox);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(571, 410);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "请填写设备出入库信息";
            // 
            // wbcode_textBox
            // 
            this.wbcode_textBox.Location = new System.Drawing.Point(386, 294);
            this.wbcode_textBox.Name = "wbcode_textBox";
            this.wbcode_textBox.Size = new System.Drawing.Size(120, 21);
            this.wbcode_textBox.TabIndex = 11;
            // 
            // memo_textBox
            // 
            this.memo_textBox.Location = new System.Drawing.Point(118, 321);
            this.memo_textBox.Multiline = true;
            this.memo_textBox.Name = "memo_textBox";
            this.memo_textBox.Size = new System.Drawing.Size(388, 21);
            this.memo_textBox.TabIndex = 12;
            // 
            // pycode_textBox
            // 
            this.pycode_textBox.Location = new System.Drawing.Point(118, 294);
            this.pycode_textBox.Name = "pycode_textBox";
            this.pycode_textBox.Size = new System.Drawing.Size(120, 21);
            this.pycode_textBox.TabIndex = 10;
            // 
            // userid_textBox
            // 
            this.userid_textBox.Location = new System.Drawing.Point(386, 205);
            this.userid_textBox.Name = "userid_textBox";
            this.userid_textBox.ReadOnly = true;
            this.userid_textBox.Size = new System.Drawing.Size(120, 21);
            this.userid_textBox.TabIndex = 4;
            this.userid_textBox.TabStop = false;
            // 
            // username_textBox
            // 
            this.username_textBox.Location = new System.Drawing.Point(386, 240);
            this.username_textBox.Name = "username_textBox";
            this.username_textBox.ReadOnly = true;
            this.username_textBox.Size = new System.Drawing.Size(120, 21);
            this.username_textBox.TabIndex = 4;
            this.username_textBox.TabStop = false;
            // 
            // choscode_textBox
            // 
            this.choscode_textBox.Location = new System.Drawing.Point(118, 237);
            this.choscode_textBox.Name = "choscode_textBox";
            this.choscode_textBox.ReadOnly = true;
            this.choscode_textBox.Size = new System.Drawing.Size(120, 21);
            this.choscode_textBox.TabIndex = 4;
            this.choscode_textBox.TabStop = false;
            // 
            // recipelength_textBox
            // 
            this.recipelength_textBox.Location = new System.Drawing.Point(118, 202);
            this.recipelength_textBox.Name = "recipelength_textBox";
            this.recipelength_textBox.Size = new System.Drawing.Size(120, 21);
            this.recipelength_textBox.TabIndex = 9;
            // 
            // recipecode_textBox
            // 
            this.recipecode_textBox.Location = new System.Drawing.Point(118, 97);
            this.recipecode_textBox.Name = "recipecode_textBox";
            this.recipecode_textBox.Size = new System.Drawing.Size(120, 21);
            this.recipecode_textBox.TabIndex = 3;
            // 
            // ioname_textBox
            // 
            this.ioname_textBox.Location = new System.Drawing.Point(118, 62);
            this.ioname_textBox.Name = "ioname_textBox";
            this.ioname_textBox.Size = new System.Drawing.Size(120, 21);
            this.ioname_textBox.TabIndex = 1;
            // 
            // ioid_textBox
            // 
            this.ioid_textBox.Location = new System.Drawing.Point(118, 27);
            this.ioid_textBox.Name = "ioid_textBox";
            this.ioid_textBox.ReadOnly = true;
            this.ioid_textBox.Size = new System.Drawing.Size(120, 21);
            this.ioid_textBox.TabIndex = 4;
            this.ioid_textBox.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(386, 166);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(368, 357);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 14;
            this.button2.Text = "关闭";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(149, 357);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "保存";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ifdefault_ytComboBox
            // 
            this.ifdefault_ytComboBox.CacheKey = null;
            this.ifdefault_ytComboBox.DbConn = null;
            this.ifdefault_ytComboBox.DefText = null;
            this.ifdefault_ytComboBox.DefValue = null;
            this.ifdefault_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ifdefault_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ifdefault_ytComboBox.EnableEmpty = true;
            this.ifdefault_ytComboBox.FirstText = null;
            this.ifdefault_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ifdefault_ytComboBox.Fomart = null;
            this.ifdefault_ytComboBox.ItemStr = "";
            this.ifdefault_ytComboBox.Location = new System.Drawing.Point(385, 131);
            this.ifdefault_ytComboBox.Name = "ifdefault_ytComboBox";
            this.ifdefault_ytComboBox.Param = null;
            this.ifdefault_ytComboBox.Size = new System.Drawing.Size(120, 22);
            this.ifdefault_ytComboBox.Sql = null;
            this.ifdefault_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ifdefault_ytComboBox.TabIndex = 6;
            this.ifdefault_ytComboBox.Tag = tvList7;
            this.ifdefault_ytComboBox.Value = null;
            // 
            // recipemonth_ytComboBox
            // 
            this.recipemonth_ytComboBox.CacheKey = null;
            this.recipemonth_ytComboBox.DbConn = null;
            this.recipemonth_ytComboBox.DefText = null;
            this.recipemonth_ytComboBox.DefValue = null;
            this.recipemonth_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.recipemonth_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.recipemonth_ytComboBox.EnableEmpty = true;
            this.recipemonth_ytComboBox.FirstText = null;
            this.recipemonth_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.recipemonth_ytComboBox.Fomart = null;
            this.recipemonth_ytComboBox.ItemStr = "";
            this.recipemonth_ytComboBox.Location = new System.Drawing.Point(118, 132);
            this.recipemonth_ytComboBox.Name = "recipemonth_ytComboBox";
            this.recipemonth_ytComboBox.Param = null;
            this.recipemonth_ytComboBox.Size = new System.Drawing.Size(121, 22);
            this.recipemonth_ytComboBox.Sql = null;
            this.recipemonth_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.recipemonth_ytComboBox.TabIndex = 5;
            this.recipemonth_ytComboBox.Tag = tvList8;
            this.recipemonth_ytComboBox.Value = null;
            // 
            // recipeyear_ytComboBox
            // 
            this.recipeyear_ytComboBox.CacheKey = null;
            this.recipeyear_ytComboBox.DbConn = null;
            this.recipeyear_ytComboBox.DefText = null;
            this.recipeyear_ytComboBox.DefValue = null;
            this.recipeyear_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.recipeyear_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.recipeyear_ytComboBox.EnableEmpty = true;
            this.recipeyear_ytComboBox.FirstText = null;
            this.recipeyear_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.recipeyear_ytComboBox.Fomart = null;
            this.recipeyear_ytComboBox.ItemStr = "";
            this.recipeyear_ytComboBox.Location = new System.Drawing.Point(118, 164);
            this.recipeyear_ytComboBox.Name = "recipeyear_ytComboBox";
            this.recipeyear_ytComboBox.Param = null;
            this.recipeyear_ytComboBox.Size = new System.Drawing.Size(121, 22);
            this.recipeyear_ytComboBox.Sql = null;
            this.recipeyear_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.recipeyear_ytComboBox.TabIndex = 7;
            this.recipeyear_ytComboBox.Tag = tvList9;
            this.recipeyear_ytComboBox.Value = null;
            // 
            // ifuse_ytComboBox
            // 
            this.ifuse_ytComboBox.CacheKey = null;
            this.ifuse_ytComboBox.DbConn = null;
            this.ifuse_ytComboBox.DefText = null;
            this.ifuse_ytComboBox.DefValue = null;
            this.ifuse_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ifuse_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ifuse_ytComboBox.EnableEmpty = true;
            this.ifuse_ytComboBox.FirstText = null;
            this.ifuse_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ifuse_ytComboBox.Fomart = null;
            this.ifuse_ytComboBox.ItemStr = "";
            this.ifuse_ytComboBox.Location = new System.Drawing.Point(385, 97);
            this.ifuse_ytComboBox.Name = "ifuse_ytComboBox";
            this.ifuse_ytComboBox.Param = null;
            this.ifuse_ytComboBox.Size = new System.Drawing.Size(121, 22);
            this.ifuse_ytComboBox.Sql = null;
            this.ifuse_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ifuse_ytComboBox.TabIndex = 4;
            this.ifuse_ytComboBox.Tag = tvList10;
            this.ifuse_ytComboBox.Value = null;
            // 
            // ioflag_ytComboBox
            // 
            this.ioflag_ytComboBox.CacheKey = null;
            this.ioflag_ytComboBox.DbConn = null;
            this.ioflag_ytComboBox.DefText = null;
            this.ioflag_ytComboBox.DefValue = null;
            this.ioflag_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ioflag_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ioflag_ytComboBox.EnableEmpty = true;
            this.ioflag_ytComboBox.FirstText = null;
            this.ioflag_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ioflag_ytComboBox.Fomart = null;
            this.ioflag_ytComboBox.ItemStr = "";
            this.ioflag_ytComboBox.Location = new System.Drawing.Point(385, 25);
            this.ioflag_ytComboBox.Name = "ioflag_ytComboBox";
            this.ioflag_ytComboBox.Param = null;
            this.ioflag_ytComboBox.Size = new System.Drawing.Size(120, 22);
            this.ioflag_ytComboBox.Sql = null;
            this.ioflag_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ioflag_ytComboBox.TabIndex = 0;
            this.ioflag_ytComboBox.Tag = tvList11;
            this.ioflag_ytComboBox.Value = null;
            // 
            // opflag_ytComboBox
            // 
            this.opflag_ytComboBox.CacheKey = null;
            this.opflag_ytComboBox.DbConn = null;
            this.opflag_ytComboBox.DefText = null;
            this.opflag_ytComboBox.DefValue = null;
            this.opflag_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.opflag_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.opflag_ytComboBox.EnableEmpty = true;
            this.opflag_ytComboBox.FirstText = null;
            this.opflag_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.opflag_ytComboBox.Fomart = null;
            this.opflag_ytComboBox.ItemStr = "";
            this.opflag_ytComboBox.Location = new System.Drawing.Point(385, 61);
            this.opflag_ytComboBox.Name = "opflag_ytComboBox";
            this.opflag_ytComboBox.Param = null;
            this.opflag_ytComboBox.Size = new System.Drawing.Size(120, 22);
            this.opflag_ytComboBox.Sql = null;
            this.opflag_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.opflag_ytComboBox.TabIndex = 2;
            this.opflag_ytComboBox.Tag = tvList12;
            this.opflag_ytComboBox.Value = null;
            // 
            // AddEQInOut
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 410);
            this.Controls.Add(this.groupBox1);
            this.Name = "AddEQInOut";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "设备出入库类型";
            this.Load += new System.EventHandler(this.AddEQInOut_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox wbcode_textBox;
        private System.Windows.Forms.TextBox memo_textBox;
        private System.Windows.Forms.TextBox pycode_textBox;
        private System.Windows.Forms.TextBox userid_textBox;
        private System.Windows.Forms.TextBox username_textBox;
        private System.Windows.Forms.TextBox choscode_textBox;
        private System.Windows.Forms.TextBox recipelength_textBox;
        private System.Windows.Forms.TextBox recipecode_textBox;
        private System.Windows.Forms.TextBox ioname_textBox;
        private System.Windows.Forms.TextBox ioid_textBox;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private YtWinContrl.com.contrl.YtComboBox ioflag_ytComboBox;
        private YtWinContrl.com.contrl.YtComboBox opflag_ytComboBox;
        private YtWinContrl.com.contrl.YtComboBox ifuse_ytComboBox;
        private YtWinContrl.com.contrl.YtComboBox ifdefault_ytComboBox;
        private YtWinContrl.com.contrl.YtComboBox recipeyear_ytComboBox;
        private YtWinContrl.com.contrl.YtComboBox recipemonth_ytComboBox;
    }
}