﻿namespace JiChuDictionary
{
    partial class SysValueManag
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            YtWinContrl.com.datagrid.TvList tvList1 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList2 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList3 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList4 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList5 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList6 = new YtWinContrl.com.datagrid.TvList();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ytComboBox_AllowDropOut = new YtWinContrl.com.contrl.YtComboBox();
            this.ytComboBox_AutoUse = new YtWinContrl.com.contrl.YtComboBox();
            this.ytComboBox_BuildCard = new YtWinContrl.com.contrl.YtComboBox();
            this.ytComboBox_MoreStype = new YtWinContrl.com.contrl.YtComboBox();
            this.ytComboBox_OnlyOneCard = new YtWinContrl.com.contrl.YtComboBox();
            this.ytComboBox_UseQian = new YtWinContrl.com.contrl.YtComboBox();
            this.yTextBox_CardsLong = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_XSWS = new YtWinContrl.com.contrl.YTextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(102, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "设备维修是否采用多个步骤：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(138, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "是否设备领用时建卡：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(102, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "是否一台设备建立一张卡片：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(138, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "是否使用千分位符号：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(102, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "建卡时，是否自动启用设备：";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(140, 313);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "修改";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(293, 313);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "取消";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.ytComboBox_AllowDropOut);
            this.groupBox1.Controls.Add(this.ytComboBox_AutoUse);
            this.groupBox1.Controls.Add(this.ytComboBox_BuildCard);
            this.groupBox1.Controls.Add(this.ytComboBox_MoreStype);
            this.groupBox1.Controls.Add(this.ytComboBox_OnlyOneCard);
            this.groupBox1.Controls.Add(this.ytComboBox_UseQian);
            this.groupBox1.Controls.Add(this.yTextBox_CardsLong);
            this.groupBox1.Controls.Add(this.yTextBox_XSWS);
            this.groupBox1.Location = new System.Drawing.Point(29, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(529, 357);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "系统参数";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(138, 267);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 12);
            this.label8.TabIndex = 14;
            this.label8.Text = "是否允许负库存出库：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(150, 237);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 12);
            this.label7.TabIndex = 13;
            this.label7.Text = "设备卡的卡号长度：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(198, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "小数位数：";
            // 
            // ytComboBox_AllowDropOut
            // 
            this.ytComboBox_AllowDropOut.CacheKey = null;
            this.ytComboBox_AllowDropOut.DbConn = null;
            this.ytComboBox_AllowDropOut.DefText = null;
            this.ytComboBox_AllowDropOut.DefValue = null;
            this.ytComboBox_AllowDropOut.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_AllowDropOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_AllowDropOut.EnableEmpty = true;
            this.ytComboBox_AllowDropOut.FirstText = null;
            this.ytComboBox_AllowDropOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_AllowDropOut.Fomart = null;
            this.ytComboBox_AllowDropOut.ItemStr = "";
            this.ytComboBox_AllowDropOut.Location = new System.Drawing.Point(281, 262);
            this.ytComboBox_AllowDropOut.Name = "ytComboBox_MoreStype";
            this.ytComboBox_AllowDropOut.Param = null;
            this.ytComboBox_AllowDropOut.Size = new System.Drawing.Size(121, 22);
            this.ytComboBox_AllowDropOut.Sql = null;
            this.ytComboBox_AllowDropOut.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_AllowDropOut.TabIndex = 7;
            this.ytComboBox_AllowDropOut.Tag = tvList1;
            this.ytComboBox_AllowDropOut.Value = null;
            // 
            // ytComboBox_AutoUse
            // 
            this.ytComboBox_AutoUse.CacheKey = null;
            this.ytComboBox_AutoUse.DbConn = null;
            this.ytComboBox_AutoUse.DefText = null;
            this.ytComboBox_AutoUse.DefValue = null;
            this.ytComboBox_AutoUse.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_AutoUse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_AutoUse.EnableEmpty = true;
            this.ytComboBox_AutoUse.FirstText = null;
            this.ytComboBox_AutoUse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_AutoUse.Fomart = null;
            this.ytComboBox_AutoUse.ItemStr = "";
            this.ytComboBox_AutoUse.Location = new System.Drawing.Point(281, 197);
            this.ytComboBox_AutoUse.Name = "ytComboBox_MoreStype";
            this.ytComboBox_AutoUse.Param = null;
            this.ytComboBox_AutoUse.Size = new System.Drawing.Size(121, 22);
            this.ytComboBox_AutoUse.Sql = null;
            this.ytComboBox_AutoUse.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_AutoUse.TabIndex = 5;
            this.ytComboBox_AutoUse.Tag = tvList2;
            this.ytComboBox_AutoUse.Value = null;
            // 
            // ytComboBox_BuildCard
            // 
            this.ytComboBox_BuildCard.CacheKey = null;
            this.ytComboBox_BuildCard.DbConn = null;
            this.ytComboBox_BuildCard.DefText = null;
            this.ytComboBox_BuildCard.DefValue = null;
            this.ytComboBox_BuildCard.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_BuildCard.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_BuildCard.EnableEmpty = true;
            this.ytComboBox_BuildCard.FirstText = null;
            this.ytComboBox_BuildCard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_BuildCard.Fomart = null;
            this.ytComboBox_BuildCard.ItemStr = "";
            this.ytComboBox_BuildCard.Location = new System.Drawing.Point(282, 70);
            this.ytComboBox_BuildCard.Name = "ytComboBox_MoreStype";
            this.ytComboBox_BuildCard.Param = null;
            this.ytComboBox_BuildCard.Size = new System.Drawing.Size(121, 22);
            this.ytComboBox_BuildCard.Sql = null;
            this.ytComboBox_BuildCard.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_BuildCard.TabIndex = 1;
            this.ytComboBox_BuildCard.Tag = tvList3;
            this.ytComboBox_BuildCard.Value = null;
            // 
            // ytComboBox_MoreStype
            // 
            this.ytComboBox_MoreStype.CacheKey = null;
            this.ytComboBox_MoreStype.DbConn = null;
            this.ytComboBox_MoreStype.DefText = null;
            this.ytComboBox_MoreStype.DefValue = null;
            this.ytComboBox_MoreStype.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_MoreStype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_MoreStype.EnableEmpty = true;
            this.ytComboBox_MoreStype.FirstText = null;
            this.ytComboBox_MoreStype.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_MoreStype.Fomart = null;
            this.ytComboBox_MoreStype.ItemStr = "";
            this.ytComboBox_MoreStype.Location = new System.Drawing.Point(282, 39);
            this.ytComboBox_MoreStype.Name = "ytComboBox_MoreStype";
            this.ytComboBox_MoreStype.Param = null;
            this.ytComboBox_MoreStype.Size = new System.Drawing.Size(121, 22);
            this.ytComboBox_MoreStype.Sql = null;
            this.ytComboBox_MoreStype.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_MoreStype.TabIndex = 0;
            this.ytComboBox_MoreStype.Tag = tvList4;
            this.ytComboBox_MoreStype.Value = null;
            // 
            // ytComboBox_OnlyOneCard
            // 
            this.ytComboBox_OnlyOneCard.CacheKey = null;
            this.ytComboBox_OnlyOneCard.DbConn = null;
            this.ytComboBox_OnlyOneCard.DefText = null;
            this.ytComboBox_OnlyOneCard.DefValue = null;
            this.ytComboBox_OnlyOneCard.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_OnlyOneCard.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_OnlyOneCard.EnableEmpty = true;
            this.ytComboBox_OnlyOneCard.FirstText = null;
            this.ytComboBox_OnlyOneCard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_OnlyOneCard.Fomart = null;
            this.ytComboBox_OnlyOneCard.ItemStr = "";
            this.ytComboBox_OnlyOneCard.Location = new System.Drawing.Point(283, 102);
            this.ytComboBox_OnlyOneCard.Name = "ytComboBox_MoreStype";
            this.ytComboBox_OnlyOneCard.Param = null;
            this.ytComboBox_OnlyOneCard.Size = new System.Drawing.Size(121, 22);
            this.ytComboBox_OnlyOneCard.Sql = null;
            this.ytComboBox_OnlyOneCard.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_OnlyOneCard.TabIndex = 2;
            this.ytComboBox_OnlyOneCard.Tag = tvList5;
            this.ytComboBox_OnlyOneCard.Value = null;
            // 
            // ytComboBox_UseQian
            // 
            this.ytComboBox_UseQian.CacheKey = null;
            this.ytComboBox_UseQian.DbConn = null;
            this.ytComboBox_UseQian.DefText = null;
            this.ytComboBox_UseQian.DefValue = null;
            this.ytComboBox_UseQian.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox_UseQian.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox_UseQian.EnableEmpty = true;
            this.ytComboBox_UseQian.FirstText = null;
            this.ytComboBox_UseQian.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox_UseQian.Fomart = null;
            this.ytComboBox_UseQian.ItemStr = "";
            this.ytComboBox_UseQian.Location = new System.Drawing.Point(282, 164);
            this.ytComboBox_UseQian.Name = "ytComboBox_MoreStype";
            this.ytComboBox_UseQian.Param = null;
            this.ytComboBox_UseQian.Size = new System.Drawing.Size(121, 22);
            this.ytComboBox_UseQian.Sql = null;
            this.ytComboBox_UseQian.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox_UseQian.TabIndex = 4;
            this.ytComboBox_UseQian.Tag = tvList6;
            this.ytComboBox_UseQian.Value = null;
            // 
            // yTextBox_CardsLong
            // 
            // 
            // 
            // 
            this.yTextBox_CardsLong.Border.Class = "TextBoxBorder";
            this.yTextBox_CardsLong.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_CardsLong.Location = new System.Drawing.Point(281, 231);
            this.yTextBox_CardsLong.Name = "yTextBox_XSWS";
            this.yTextBox_CardsLong.Size = new System.Drawing.Size(121, 21);
            this.yTextBox_CardsLong.TabIndex = 6;
            // 
            // yTextBox_XSWS
            // 
            // 
            // 
            // 
            this.yTextBox_XSWS.Border.Class = "TextBoxBorder";
            this.yTextBox_XSWS.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_XSWS.Location = new System.Drawing.Point(282, 132);
            this.yTextBox_XSWS.Name = "yTextBox_XSWS";
            this.yTextBox_XSWS.Size = new System.Drawing.Size(121, 21);
            this.yTextBox_XSWS.TabIndex = 3;
            // 
            // SysValueManag
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 412);
            this.Controls.Add(this.groupBox1);
            this.Name = "SysValueManag";
            this.Text = "系统参数管理";
            this.Load += new System.EventHandler(this.SysValueManag_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_MoreStype;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_BuildCard;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_OnlyOneCard;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_UseQian;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_AutoUse;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox_AllowDropOut;
        private YtWinContrl.com.contrl.YTextBox yTextBox_XSWS;
        private YtWinContrl.com.contrl.YTextBox yTextBox_CardsLong;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}