﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// 有关程序集的常规信息通过下列属性集
// 控制。更改这些属性值可修改
// 与程序集关联的信息。
[assembly: AssemblyTitle("联科医院信息系统( HIS )")]
[assembly: AssemblyDescription("联科医院信息系统（LK-HIS-SAAS）")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("贵州联科软件科技发展有限公司")]
[assembly: AssemblyProduct("联科医院信息系统（LK-HIS-SAAS）")]
[assembly: AssemblyCopyright("Copyright © 联科软件 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// 将 ComVisible 设置为 false 使此程序集中的类型
// 对 COM 组件不可见。如果需要从 COM 访问此程序集中的类型，
// 则将该类型上的 ComVisible 属性设置为 true。
[assembly: ComVisible(false)]

// 如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
[assembly: Guid("283b6f64-6f4e-465f-9dd2-c092e3b6f700")]

// 程序集的版本信息由下面四个值组成:
//
//      主版本
//      次版本 
//      内部版本号
//      修订号
//
// 可以指定所有这些值，也可以使用“内部版本号”和“修订号”的默认值，
// 方法是按如下所示使用“*”:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("2.0.4.26")]
[assembly: AssemblyFileVersion("2.0.4.26")]
