﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CHisMain
{
    [Serializable]
    public    class Login
    {
      public string ChosName { get; set; }
      public string Choscode { get; set; } 
      public string Useraccount { get; set; }
      public int UserId { get; set; }
      public string UserName { get; set; }
      public string Sj { get; set; }
      
    }
}
