﻿namespace EQWareManag.form
{
    partial class AddEQBuildCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddEQBuildCard));
            YtWinContrl.com.datagrid.TvList tvList1 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList2 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList3 = new YtWinContrl.com.datagrid.TvList();
            YtWinContrl.com.datagrid.TvList tvList4 = new YtWinContrl.com.datagrid.TvList();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.CardRec_tab = new System.Windows.Forms.TabPage();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.maskedTextBox8 = new System.Windows.Forms.MaskedTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.maskedTextBox9 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox10 = new System.Windows.Forms.MaskedTextBox();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.BFRQ_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.AZSJ_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.LYSJ_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.CCSJdateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dinggou_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.synx_textBox = new System.Windows.Forms.TextBox();
            this.YSYNX_textBox = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BFR_textBox = new System.Windows.Forms.TextBox();
            this.yanshourenyuan_txtBox = new System.Windows.Forms.TextBox();
            this.yanshoujilu_textBox = new System.Windows.Forms.TextBox();
            this.memo_textBox = new System.Windows.Forms.TextBox();
            this.AZR_textBox = new System.Windows.Forms.TextBox();
            this.zhiliangqingkuang_textBox = new System.Windows.Forms.TextBox();
            this.yuanzhi_textBox = new System.Windows.Forms.TextBox();
            this.LYR_textBox = new System.Windows.Forms.TextBox();
            this.zhuyaoyongtu_textBox = new System.Windows.Forms.TextBox();
            this.jiage_textBox = new System.Windows.Forms.TextBox();
            this.CCH_textBox = new System.Windows.Forms.TextBox();
            this.canzhilv_textBox = new System.Windows.Forms.TextBox();
            this.hetonghao_textBox = new System.Windows.Forms.TextBox();
            this.baoguanren_textBox = new System.Windows.Forms.TextBox();
            this.leijizhejiu_textBox = new System.Windows.Forms.TextBox();
            this.txm_textBox = new System.Windows.Forms.TextBox();
            this.shoufeibiaozhun_textBox = new System.Windows.Forms.TextBox();
            this.guobie_textBox = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolstrip_cardcode_status = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.eqname_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lb34 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.checkZQ_txtbox = new System.Windows.Forms.TextBox();
            this.checkrange_txtbox = new System.Windows.Forms.TextBox();
            this.checklevel_txtbox = new System.Windows.Forms.TextBox();
            this.jdlevel_txtbox = new System.Windows.Forms.TextBox();
            this.fdvalue_txtbox = new System.Windows.Forms.TextBox();
            this.stockflowno_ytComboBox = new YtWinContrl.com.contrl.SelTextInpt();
            this.statuscode_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.Deptid_selText = new YtWinContrl.com.contrl.SelTextInpt();
            this.Status_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.eqnum_txtbox = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.totaledwork_txtbox = new System.Windows.Forms.TextBox();
            this.totalwork_txtbox = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cardcode_txtbox = new System.Windows.Forms.TextBox();
            this.username_txtbox = new System.Windows.Forms.TextBox();
            this.userid_txtbox = new System.Windows.Forms.TextBox();
            this.recdate_txtbox = new System.Windows.Forms.TextBox();
            this.choscode_txtbox = new System.Windows.Forms.TextBox();
            this.eqId_txtbox = new System.Windows.Forms.TextBox();
            this.stockid_txtbox = new System.Windows.Forms.TextBox();
            this.cardId_txtbox = new System.Windows.Forms.TextBox();
            this.CardFJ_tab = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.FJ_addtoolStrip = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.FJ_DeltoolStrip = new System.Windows.Forms.ToolStripButton();
            this.CardJLRec_tab = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.JL_AddtoolStrip = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.JL_DeltoolStrip = new System.Windows.Forms.ToolStripButton();
            this.CardCC_tab = new System.Windows.Forms.TabPage();
            this.CCgroupBox = new System.Windows.Forms.GroupBox();
            this.CCGet_groupBox = new System.Windows.Forms.GroupBox();
            this.CCbuydate_textBox = new System.Windows.Forms.DateTimePicker();
            this.label48 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.CCnewold_textBox = new System.Windows.Forms.TextBox();
            this.CCsupply_textBox = new System.Windows.Forms.TextBox();
            this.CCcsname_textBox = new System.Windows.Forms.TextBox();
            this.CCother_textBox = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.CCNO_groupBo = new System.Windows.Forms.GroupBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.CCuseridtextBox = new System.Windows.Forms.TextBox();
            this.CCchosode_textBox = new System.Windows.Forms.TextBox();
            this.CCcardid_textBox = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.CCusername_textBox = new System.Windows.Forms.TextBox();
            this.CCrecdate_textBox = new System.Windows.Forms.TextBox();
            this.CCcc_textBox = new System.Windows.Forms.TextBox();
            this.CCprice_textBox = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.CardExplain_tab = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.SMexplainNum_textBox = new System.Windows.Forms.TextBox();
            this.SMusrtid_textBox = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.TextBox();
            this.SMchoscode_textBox = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.SMboxthing_textBox = new System.Windows.Forms.TextBox();
            this.SMusername_textBox = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.SMteachnum_textBox = new System.Windows.Forms.TextBox();
            this.SMother_textBox = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.SMcertificate_textBox = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.SMcardid_textBox = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.SMext_textBox = new System.Windows.Forms.TextBox();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox5 = new System.Windows.Forms.MaskedTextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel6 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel7 = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.ytComboBox1 = new YtWinContrl.com.contrl.YtComboBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.selTextInpt1 = new YtWinContrl.com.contrl.SelTextInpt();
            this.selTextInpt2 = new YtWinContrl.com.contrl.SelTextInpt();
            this.selTextInpt3 = new YtWinContrl.com.contrl.SelTextInpt();
            this.ytComboBox2 = new YtWinContrl.com.contrl.YtComboBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.dataGView1 = new YtWinContrl.com.datagrid.DataGView();
            this.FJ_CardIdCloumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FJ_RowNoColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FJ_unitColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.FJ_NUMColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FJ_PriceColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FJ_MoneyColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FJ_Status = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JinEHeJi = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.TiaoSu = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.dataGView2 = new YtWinContrl.com.datagrid.DataGView();
            this.JL_CardIdColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JL_RowNOColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JL_CheckdateColumn = new YtWinContrl.com.datagrid.CalendarColumn();
            this.JL_CheckDate_Column = new YtWinContrl.com.datagrid.CalendarColumn();
            this.JL_StatusColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.CardRec_tab.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.CardFJ_tab.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.CardJLRec_tab.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.CardCC_tab.SuspendLayout();
            this.CCgroupBox.SuspendLayout();
            this.CCGet_groupBox.SuspendLayout();
            this.CCNO_groupBo.SuspendLayout();
            this.CardExplain_tab.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.statusStrip2.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1284, 540);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "设备卡片信息";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.CardRec_tab);
            this.tabControl1.Controls.Add(this.CardFJ_tab);
            this.tabControl1.Controls.Add(this.CardJLRec_tab);
            this.tabControl1.Controls.Add(this.CardCC_tab);
            this.tabControl1.Controls.Add(this.CardExplain_tab);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ItemSize = new System.Drawing.Size(137, 17);
            this.tabControl1.Location = new System.Drawing.Point(3, 17);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1278, 520);
            this.tabControl1.TabIndex = 0;
            // 
            // CardRec_tab
            // 
            this.CardRec_tab.AutoScroll = true;
            this.CardRec_tab.Controls.Add(this.groupBox15);
            this.CardRec_tab.Controls.Add(this.groupBox11);
            this.CardRec_tab.Controls.Add(this.statusStrip1);
            this.CardRec_tab.Controls.Add(this.groupBox2);
            this.CardRec_tab.Location = new System.Drawing.Point(4, 21);
            this.CardRec_tab.Margin = new System.Windows.Forms.Padding(0);
            this.CardRec_tab.Name = "CardRec_tab";
            this.CardRec_tab.Padding = new System.Windows.Forms.Padding(5);
            this.CardRec_tab.Size = new System.Drawing.Size(1270, 495);
            this.CardRec_tab.TabIndex = 0;
            this.CardRec_tab.Text = "卡片信息";
            this.CardRec_tab.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.button2);
            this.groupBox15.Controls.Add(this.maskedTextBox8);
            this.groupBox15.Controls.Add(this.button1);
            this.groupBox15.Controls.Add(this.maskedTextBox9);
            this.groupBox15.Controls.Add(this.maskedTextBox10);
            this.groupBox15.Controls.Add(this.label117);
            this.groupBox15.Controls.Add(this.label118);
            this.groupBox15.Controls.Add(this.label123);
            this.groupBox15.Controls.Add(this.label124);
            this.groupBox15.Controls.Add(this.label125);
            this.groupBox15.Controls.Add(this.label127);
            this.groupBox15.Controls.Add(this.label128);
            this.groupBox15.Controls.Add(this.label130);
            this.groupBox15.Controls.Add(this.label138);
            this.groupBox15.Controls.Add(this.textBox39);
            this.groupBox15.Controls.Add(this.textBox40);
            this.groupBox15.Controls.Add(this.textBox41);
            this.groupBox15.Controls.Add(this.textBox42);
            this.groupBox15.Controls.Add(this.textBox44);
            this.groupBox15.Controls.Add(this.textBox51);
            this.groupBox15.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox15.Location = new System.Drawing.Point(5, 450);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(1260, 40);
            this.groupBox15.TabIndex = 6;
            this.groupBox15.TabStop = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(817, 11);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 34;
            this.button2.Text = "取消";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // maskedTextBox8
            // 
            this.maskedTextBox8.Location = new System.Drawing.Point(1035, 154);
            this.maskedTextBox8.Mask = "0000-00-00";
            this.maskedTextBox8.Name = "maskedTextBox8";
            this.maskedTextBox8.Size = new System.Drawing.Size(179, 21);
            this.maskedTextBox8.TabIndex = 82;
            this.maskedTextBox8.ValidatingType = typeof(System.DateTime);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(457, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 33;
            this.button1.Text = "保存";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // maskedTextBox9
            // 
            this.maskedTextBox9.Location = new System.Drawing.Point(1035, 211);
            this.maskedTextBox9.Mask = "0000-00-00";
            this.maskedTextBox9.Name = "maskedTextBox9";
            this.maskedTextBox9.Size = new System.Drawing.Size(179, 21);
            this.maskedTextBox9.TabIndex = 84;
            this.maskedTextBox9.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox10
            // 
            this.maskedTextBox10.Location = new System.Drawing.Point(1035, 181);
            this.maskedTextBox10.Mask = "0000-00-00";
            this.maskedTextBox10.Name = "maskedTextBox10";
            this.maskedTextBox10.Size = new System.Drawing.Size(179, 21);
            this.maskedTextBox10.TabIndex = 83;
            this.maskedTextBox10.ValidatingType = typeof(System.DateTime);
            // 
            // label117
            // 
            this.label117.Location = new System.Drawing.Point(960, 153);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(72, 21);
            this.label117.TabIndex = 54;
            this.label117.Text = "领用时间";
            this.label117.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label118
            // 
            this.label118.Location = new System.Drawing.Point(14, 207);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(50, 21);
            this.label118.TabIndex = 55;
            this.label118.Text = "备注";
            this.label118.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label123
            // 
            this.label123.Location = new System.Drawing.Point(587, 152);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(60, 21);
            this.label123.TabIndex = 40;
            this.label123.Text = "报废人";
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label124
            // 
            this.label124.Location = new System.Drawing.Point(960, 180);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(72, 21);
            this.label124.TabIndex = 35;
            this.label124.Text = "安装时间";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label125
            // 
            this.label125.Location = new System.Drawing.Point(953, 210);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(72, 21);
            this.label125.TabIndex = 36;
            this.label125.Text = "报废日期";
            this.label125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label127
            // 
            this.label127.Location = new System.Drawing.Point(14, 180);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(63, 21);
            this.label127.TabIndex = 44;
            this.label127.Text = "验收人员";
            this.label127.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label128
            // 
            this.label128.Location = new System.Drawing.Point(577, 179);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(60, 21);
            this.label128.TabIndex = 45;
            this.label128.Text = "验收记录";
            this.label128.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label130
            // 
            this.label130.Location = new System.Drawing.Point(304, 153);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(75, 21);
            this.label130.TabIndex = 41;
            this.label130.Text = "质量情况";
            this.label130.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label138
            // 
            this.label138.Location = new System.Drawing.Point(24, 151);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(50, 21);
            this.label138.TabIndex = 53;
            this.label138.Text = "合同号";
            this.label138.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(669, 153);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(191, 21);
            this.textBox39.TabIndex = 77;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(89, 180);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(427, 21);
            this.textBox40.TabIndex = 71;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(669, 179);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(191, 21);
            this.textBox41.TabIndex = 78;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(89, 208);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(771, 21);
            this.textBox42.TabIndex = 70;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(385, 152);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(131, 21);
            this.textBox44.TabIndex = 68;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(89, 153);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(121, 21);
            this.textBox51.TabIndex = 61;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.BFRQ_dateTimePicker);
            this.groupBox11.Controls.Add(this.AZSJ_dateTimePicker);
            this.groupBox11.Controls.Add(this.LYSJ_dateTimePicker);
            this.groupBox11.Controls.Add(this.CCSJdateTimePicker2);
            this.groupBox11.Controls.Add(this.dinggou_dateTimePicker1);
            this.groupBox11.Controls.Add(this.synx_textBox);
            this.groupBox11.Controls.Add(this.YSYNX_textBox);
            this.groupBox11.Controls.Add(this.label38);
            this.groupBox11.Controls.Add(this.label32);
            this.groupBox11.Controls.Add(this.label13);
            this.groupBox11.Controls.Add(this.label37);
            this.groupBox11.Controls.Add(this.label31);
            this.groupBox11.Controls.Add(this.label12);
            this.groupBox11.Controls.Add(this.label36);
            this.groupBox11.Controls.Add(this.label30);
            this.groupBox11.Controls.Add(this.label35);
            this.groupBox11.Controls.Add(this.label11);
            this.groupBox11.Controls.Add(this.label34);
            this.groupBox11.Controls.Add(this.label29);
            this.groupBox11.Controls.Add(this.label58);
            this.groupBox11.Controls.Add(this.label28);
            this.groupBox11.Controls.Add(this.label10);
            this.groupBox11.Controls.Add(this.label27);
            this.groupBox11.Controls.Add(this.label9);
            this.groupBox11.Controls.Add(this.label8);
            this.groupBox11.Controls.Add(this.label7);
            this.groupBox11.Controls.Add(this.label6);
            this.groupBox11.Controls.Add(this.label5);
            this.groupBox11.Controls.Add(this.label4);
            this.groupBox11.Controls.Add(this.label3);
            this.groupBox11.Controls.Add(this.label2);
            this.groupBox11.Controls.Add(this.label1);
            this.groupBox11.Controls.Add(this.BFR_textBox);
            this.groupBox11.Controls.Add(this.yanshourenyuan_txtBox);
            this.groupBox11.Controls.Add(this.yanshoujilu_textBox);
            this.groupBox11.Controls.Add(this.memo_textBox);
            this.groupBox11.Controls.Add(this.AZR_textBox);
            this.groupBox11.Controls.Add(this.zhiliangqingkuang_textBox);
            this.groupBox11.Controls.Add(this.yuanzhi_textBox);
            this.groupBox11.Controls.Add(this.LYR_textBox);
            this.groupBox11.Controls.Add(this.zhuyaoyongtu_textBox);
            this.groupBox11.Controls.Add(this.jiage_textBox);
            this.groupBox11.Controls.Add(this.CCH_textBox);
            this.groupBox11.Controls.Add(this.canzhilv_textBox);
            this.groupBox11.Controls.Add(this.hetonghao_textBox);
            this.groupBox11.Controls.Add(this.baoguanren_textBox);
            this.groupBox11.Controls.Add(this.leijizhejiu_textBox);
            this.groupBox11.Controls.Add(this.txm_textBox);
            this.groupBox11.Controls.Add(this.shoufeibiaozhun_textBox);
            this.groupBox11.Controls.Add(this.guobie_textBox);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox11.Location = new System.Drawing.Point(5, 212);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(1260, 278);
            this.groupBox11.TabIndex = 5;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "基本信息";
            // 
            // BFRQ_dateTimePicker
            // 
            this.BFRQ_dateTimePicker.CustomFormat = "yyyy-MM-dd hh:mm";
            this.BFRQ_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.BFRQ_dateTimePicker.Location = new System.Drawing.Point(1032, 211);
            this.BFRQ_dateTimePicker.Name = "BFRQ_dateTimePicker";
            this.BFRQ_dateTimePicker.Size = new System.Drawing.Size(182, 21);
            this.BFRQ_dateTimePicker.TabIndex = 31;
            // 
            // AZSJ_dateTimePicker
            // 
            this.AZSJ_dateTimePicker.CustomFormat = "yyyy-MM-dd hh:mm";
            this.AZSJ_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.AZSJ_dateTimePicker.Location = new System.Drawing.Point(1032, 182);
            this.AZSJ_dateTimePicker.Name = "AZSJ_dateTimePicker";
            this.AZSJ_dateTimePicker.Size = new System.Drawing.Size(182, 21);
            this.AZSJ_dateTimePicker.TabIndex = 30;
            // 
            // LYSJ_dateTimePicker
            // 
            this.LYSJ_dateTimePicker.CustomFormat = "yyyy-MM-dd hh:mm";
            this.LYSJ_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.LYSJ_dateTimePicker.Location = new System.Drawing.Point(1032, 153);
            this.LYSJ_dateTimePicker.Name = "LYSJ_dateTimePicker";
            this.LYSJ_dateTimePicker.Size = new System.Drawing.Size(182, 21);
            this.LYSJ_dateTimePicker.TabIndex = 29;
            // 
            // CCSJdateTimePicker2
            // 
            this.CCSJdateTimePicker2.CustomFormat = "yyyy-MM-dd hh:mm";
            this.CCSJdateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.CCSJdateTimePicker2.Location = new System.Drawing.Point(1032, 124);
            this.CCSJdateTimePicker2.Name = "CCSJdateTimePicker2";
            this.CCSJdateTimePicker2.Size = new System.Drawing.Size(182, 21);
            this.CCSJdateTimePicker2.TabIndex = 28;
            // 
            // dinggou_dateTimePicker1
            // 
            this.dinggou_dateTimePicker1.CustomFormat = "yyyy-MM-dd hh:mm";
            this.dinggou_dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dinggou_dateTimePicker1.Location = new System.Drawing.Point(1033, 95);
            this.dinggou_dateTimePicker1.Name = "dinggou_dateTimePicker1";
            this.dinggou_dateTimePicker1.Size = new System.Drawing.Size(181, 21);
            this.dinggou_dateTimePicker1.TabIndex = 27;
            // 
            // synx_textBox
            // 
            this.synx_textBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.synx_textBox.Location = new System.Drawing.Point(1035, 30);
            this.synx_textBox.Name = "synx_textBox";
            this.synx_textBox.Size = new System.Drawing.Size(179, 21);
            this.synx_textBox.TabIndex = 25;
            // 
            // YSYNX_textBox
            // 
            this.YSYNX_textBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.YSYNX_textBox.Location = new System.Drawing.Point(1035, 62);
            this.YSYNX_textBox.Name = "YSYNX_textBox";
            this.YSYNX_textBox.Size = new System.Drawing.Size(179, 21);
            this.YSYNX_textBox.TabIndex = 26;
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(587, 28);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(60, 21);
            this.label38.TabIndex = 58;
            this.label38.Text = "保管人";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(940, 62);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(92, 21);
            this.label32.TabIndex = 59;
            this.label32.Text = "已使用年限(月)";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(960, 153);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 21);
            this.label13.TabIndex = 54;
            this.label13.Text = "领用时间";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.Location = new System.Drawing.Point(14, 207);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(50, 21);
            this.label37.TabIndex = 55;
            this.label37.Text = "备注";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.Location = new System.Drawing.Point(304, 29);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(75, 21);
            this.label31.TabIndex = 56;
            this.label31.Text = "累计折旧";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(587, 94);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 21);
            this.label12.TabIndex = 47;
            this.label12.Text = "领用人";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(24, 29);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(50, 21);
            this.label36.TabIndex = 38;
            this.label36.Text = "条形码";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(306, 94);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(75, 21);
            this.label30.TabIndex = 39;
            this.label30.Text = "残值率";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.Location = new System.Drawing.Point(587, 152);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(60, 21);
            this.label35.TabIndex = 40;
            this.label35.Text = "报废人";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(960, 180);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 21);
            this.label11.TabIndex = 35;
            this.label11.Text = "安装时间";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(953, 210);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(72, 21);
            this.label34.TabIndex = 36;
            this.label34.Text = "报废日期";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.Location = new System.Drawing.Point(304, 124);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(75, 21);
            this.label29.TabIndex = 37;
            this.label29.Text = "主要用途";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.Location = new System.Drawing.Point(14, 180);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(63, 21);
            this.label58.TabIndex = 44;
            this.label58.Text = "验收人员";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(578, 178);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 21);
            this.label28.TabIndex = 45;
            this.label28.Text = "验收记录";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(587, 124);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 21);
            this.label10.TabIndex = 46;
            this.label10.Text = "安装人";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(304, 153);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(75, 21);
            this.label27.TabIndex = 41;
            this.label27.Text = "质量情况";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(587, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 21);
            this.label9.TabIndex = 42;
            this.label9.Text = "出厂号";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(953, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 21);
            this.label8.TabIndex = 51;
            this.label8.Text = "使用年限(月)";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(960, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 21);
            this.label7.TabIndex = 43;
            this.label7.Text = "出厂时间";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(960, 94);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 21);
            this.label6.TabIndex = 57;
            this.label6.Text = "订购时间";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(304, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 21);
            this.label5.TabIndex = 50;
            this.label5.Text = "收费标准";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(24, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 21);
            this.label4.TabIndex = 49;
            this.label4.Text = "原值";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(24, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 21);
            this.label3.TabIndex = 48;
            this.label3.Text = "价格";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(24, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 21);
            this.label2.TabIndex = 53;
            this.label2.Text = "合同号";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(24, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 21);
            this.label1.TabIndex = 52;
            this.label1.Text = "国别";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BFR_textBox
            // 
            this.BFR_textBox.Location = new System.Drawing.Point(669, 153);
            this.BFR_textBox.Name = "BFR_textBox";
            this.BFR_textBox.Size = new System.Drawing.Size(191, 21);
            this.BFR_textBox.TabIndex = 23;
            // 
            // yanshourenyuan_txtBox
            // 
            this.yanshourenyuan_txtBox.Location = new System.Drawing.Point(89, 180);
            this.yanshourenyuan_txtBox.Name = "yanshourenyuan_txtBox";
            this.yanshourenyuan_txtBox.Size = new System.Drawing.Size(427, 21);
            this.yanshourenyuan_txtBox.TabIndex = 18;
            // 
            // yanshoujilu_textBox
            // 
            this.yanshoujilu_textBox.Location = new System.Drawing.Point(669, 179);
            this.yanshoujilu_textBox.Name = "yanshoujilu_textBox";
            this.yanshoujilu_textBox.Size = new System.Drawing.Size(191, 21);
            this.yanshoujilu_textBox.TabIndex = 24;
            // 
            // memo_textBox
            // 
            this.memo_textBox.Location = new System.Drawing.Point(89, 208);
            this.memo_textBox.Name = "memo_textBox";
            this.memo_textBox.Size = new System.Drawing.Size(771, 21);
            this.memo_textBox.TabIndex = 32;
            // 
            // AZR_textBox
            // 
            this.AZR_textBox.Location = new System.Drawing.Point(669, 124);
            this.AZR_textBox.Name = "AZR_textBox";
            this.AZR_textBox.Size = new System.Drawing.Size(191, 21);
            this.AZR_textBox.TabIndex = 22;
            // 
            // zhiliangqingkuang_textBox
            // 
            this.zhiliangqingkuang_textBox.Location = new System.Drawing.Point(385, 152);
            this.zhiliangqingkuang_textBox.Name = "zhiliangqingkuang_textBox";
            this.zhiliangqingkuang_textBox.Size = new System.Drawing.Size(131, 21);
            this.zhiliangqingkuang_textBox.TabIndex = 17;
            // 
            // yuanzhi_textBox
            // 
            this.yuanzhi_textBox.Location = new System.Drawing.Point(89, 94);
            this.yuanzhi_textBox.Name = "yuanzhi_textBox";
            this.yuanzhi_textBox.ReadOnly = true;
            this.yuanzhi_textBox.Size = new System.Drawing.Size(121, 21);
            this.yuanzhi_textBox.TabIndex = 69;
            this.yuanzhi_textBox.TabStop = false;
            // 
            // LYR_textBox
            // 
            this.LYR_textBox.Location = new System.Drawing.Point(669, 93);
            this.LYR_textBox.Name = "LYR_textBox";
            this.LYR_textBox.Size = new System.Drawing.Size(191, 21);
            this.LYR_textBox.TabIndex = 21;
            // 
            // zhuyaoyongtu_textBox
            // 
            this.zhuyaoyongtu_textBox.Location = new System.Drawing.Point(385, 124);
            this.zhuyaoyongtu_textBox.Name = "zhuyaoyongtu_textBox";
            this.zhuyaoyongtu_textBox.Size = new System.Drawing.Size(131, 21);
            this.zhuyaoyongtu_textBox.TabIndex = 16;
            // 
            // jiage_textBox
            // 
            this.jiage_textBox.Location = new System.Drawing.Point(89, 62);
            this.jiage_textBox.Name = "jiage_textBox";
            this.jiage_textBox.ReadOnly = true;
            this.jiage_textBox.Size = new System.Drawing.Size(121, 21);
            this.jiage_textBox.TabIndex = 67;
            this.jiage_textBox.TabStop = false;
            // 
            // CCH_textBox
            // 
            this.CCH_textBox.Location = new System.Drawing.Point(669, 62);
            this.CCH_textBox.Name = "CCH_textBox";
            this.CCH_textBox.Size = new System.Drawing.Size(191, 21);
            this.CCH_textBox.TabIndex = 20;
            // 
            // canzhilv_textBox
            // 
            this.canzhilv_textBox.Location = new System.Drawing.Point(385, 90);
            this.canzhilv_textBox.Name = "canzhilv_textBox";
            this.canzhilv_textBox.Size = new System.Drawing.Size(131, 21);
            this.canzhilv_textBox.TabIndex = 15;
            // 
            // hetonghao_textBox
            // 
            this.hetonghao_textBox.Location = new System.Drawing.Point(89, 153);
            this.hetonghao_textBox.Name = "hetonghao_textBox";
            this.hetonghao_textBox.Size = new System.Drawing.Size(121, 21);
            this.hetonghao_textBox.TabIndex = 12;
            // 
            // baoguanren_textBox
            // 
            this.baoguanren_textBox.Location = new System.Drawing.Point(669, 31);
            this.baoguanren_textBox.Name = "baoguanren_textBox";
            this.baoguanren_textBox.Size = new System.Drawing.Size(191, 21);
            this.baoguanren_textBox.TabIndex = 19;
            // 
            // leijizhejiu_textBox
            // 
            this.leijizhejiu_textBox.Location = new System.Drawing.Point(385, 28);
            this.leijizhejiu_textBox.Name = "leijizhejiu_textBox";
            this.leijizhejiu_textBox.Size = new System.Drawing.Size(131, 21);
            this.leijizhejiu_textBox.TabIndex = 13;
            // 
            // txm_textBox
            // 
            this.txm_textBox.Location = new System.Drawing.Point(89, 30);
            this.txm_textBox.Name = "txm_textBox";
            this.txm_textBox.ReadOnly = true;
            this.txm_textBox.Size = new System.Drawing.Size(121, 21);
            this.txm_textBox.TabIndex = 63;
            this.txm_textBox.TabStop = false;
            // 
            // shoufeibiaozhun_textBox
            // 
            this.shoufeibiaozhun_textBox.Location = new System.Drawing.Point(385, 59);
            this.shoufeibiaozhun_textBox.Name = "shoufeibiaozhun_textBox";
            this.shoufeibiaozhun_textBox.Size = new System.Drawing.Size(131, 21);
            this.shoufeibiaozhun_textBox.TabIndex = 14;
            // 
            // guobie_textBox
            // 
            this.guobie_textBox.Location = new System.Drawing.Point(89, 124);
            this.guobie_textBox.Name = "guobie_textBox";
            this.guobie_textBox.Size = new System.Drawing.Size(121, 21);
            this.guobie_textBox.TabIndex = 11;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolstrip_cardcode_status});
            this.statusStrip1.Location = new System.Drawing.Point(5, 468);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1264, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.Visible = false;
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripStatusLabel1.Image")));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(69, 17);
            this.toolStripStatusLabel1.Text = "医院软件";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(11, 17);
            this.toolStripStatusLabel2.Text = "|";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(89, 17);
            this.toolStripStatusLabel3.Text = "上一张卡号为：";
            // 
            // toolstrip_cardcode_status
            // 
            this.toolstrip_cardcode_status.Name = "toolstrip_cardcode_status";
            this.toolstrip_cardcode_status.Size = new System.Drawing.Size(0, 17);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.eqname_ytComboBox);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.stockflowno_ytComboBox);
            this.groupBox2.Controls.Add(this.statuscode_selText);
            this.groupBox2.Controls.Add(this.Deptid_selText);
            this.groupBox2.Controls.Add(this.Status_ytComboBox);
            this.groupBox2.Controls.Add(this.eqnum_txtbox);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Controls.Add(this.label41);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.cardcode_txtbox);
            this.groupBox2.Controls.Add(this.username_txtbox);
            this.groupBox2.Controls.Add(this.userid_txtbox);
            this.groupBox2.Controls.Add(this.recdate_txtbox);
            this.groupBox2.Controls.Add(this.choscode_txtbox);
            this.groupBox2.Controls.Add(this.eqId_txtbox);
            this.groupBox2.Controls.Add(this.stockid_txtbox);
            this.groupBox2.Controls.Add(this.cardId_txtbox);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox2.Location = new System.Drawing.Point(5, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1260, 207);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "必填项(*)";
            // 
            // eqname_ytComboBox
            // 
            this.eqname_ytComboBox.CacheKey = null;
            this.eqname_ytComboBox.DbConn = null;
            this.eqname_ytComboBox.DefText = null;
            this.eqname_ytComboBox.DefValue = null;
            this.eqname_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.eqname_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.eqname_ytComboBox.Enabled = false;
            this.eqname_ytComboBox.EnableEmpty = true;
            this.eqname_ytComboBox.FirstText = null;
            this.eqname_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eqname_ytComboBox.Fomart = null;
            this.eqname_ytComboBox.ItemStr = "";
            this.eqname_ytComboBox.Location = new System.Drawing.Point(534, 142);
            this.eqname_ytComboBox.Name = "eqname_ytComboBox";
            this.eqname_ytComboBox.Param = null;
            this.eqname_ytComboBox.Size = new System.Drawing.Size(150, 22);
            this.eqname_ytComboBox.Sql = null;
            this.eqname_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.eqname_ytComboBox.TabIndex = 3;
            this.eqname_ytComboBox.Tag = tvList1;
            this.eqname_ytComboBox.Value = null;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lb34);
            this.groupBox4.Controls.Add(this.label47);
            this.groupBox4.Controls.Add(this.label43);
            this.groupBox4.Controls.Add(this.label44);
            this.groupBox4.Controls.Add(this.label45);
            this.groupBox4.Controls.Add(this.checkZQ_txtbox);
            this.groupBox4.Controls.Add(this.checkrange_txtbox);
            this.groupBox4.Controls.Add(this.checklevel_txtbox);
            this.groupBox4.Controls.Add(this.jdlevel_txtbox);
            this.groupBox4.Controls.Add(this.fdvalue_txtbox);
            this.groupBox4.ForeColor = System.Drawing.Color.Blue;
            this.groupBox4.Location = new System.Drawing.Point(1019, 16);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(239, 188);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "计量设备必填项";
            // 
            // lb34
            // 
            this.lb34.ForeColor = System.Drawing.Color.Blue;
            this.lb34.Location = new System.Drawing.Point(11, 127);
            this.lb34.Name = "lb34";
            this.lb34.Size = new System.Drawing.Size(79, 21);
            this.lb34.TabIndex = 4;
            this.lb34.Text = "测量范围";
            this.lb34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.ForeColor = System.Drawing.Color.Blue;
            this.label47.Location = new System.Drawing.Point(12, 158);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(79, 21);
            this.label47.TabIndex = 4;
            this.label47.Text = "检定周期(月)";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.ForeColor = System.Drawing.Color.Blue;
            this.label43.Location = new System.Drawing.Point(12, 26);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(78, 21);
            this.label43.TabIndex = 50;
            this.label43.Text = "分度值";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label44
            // 
            this.label44.ForeColor = System.Drawing.Color.Blue;
            this.label44.Location = new System.Drawing.Point(11, 57);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(79, 21);
            this.label44.TabIndex = 4;
            this.label44.Text = "精度等级";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.ForeColor = System.Drawing.Color.Blue;
            this.label45.Location = new System.Drawing.Point(11, 91);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(79, 21);
            this.label45.TabIndex = 4;
            this.label45.Text = "检定等级";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // checkZQ_txtbox
            // 
            this.checkZQ_txtbox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.checkZQ_txtbox.Location = new System.Drawing.Point(108, 158);
            this.checkZQ_txtbox.Name = "checkZQ_txtbox";
            this.checkZQ_txtbox.Size = new System.Drawing.Size(108, 21);
            this.checkZQ_txtbox.TabIndex = 10;
            // 
            // checkrange_txtbox
            // 
            this.checkrange_txtbox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.checkrange_txtbox.Location = new System.Drawing.Point(108, 126);
            this.checkrange_txtbox.Name = "checkrange_txtbox";
            this.checkrange_txtbox.Size = new System.Drawing.Size(108, 21);
            this.checkrange_txtbox.TabIndex = 9;
            // 
            // checklevel_txtbox
            // 
            this.checklevel_txtbox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.checklevel_txtbox.Location = new System.Drawing.Point(108, 92);
            this.checklevel_txtbox.Name = "checklevel_txtbox";
            this.checklevel_txtbox.Size = new System.Drawing.Size(108, 21);
            this.checklevel_txtbox.TabIndex = 8;
            // 
            // jdlevel_txtbox
            // 
            this.jdlevel_txtbox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.jdlevel_txtbox.Location = new System.Drawing.Point(108, 58);
            this.jdlevel_txtbox.Name = "jdlevel_txtbox";
            this.jdlevel_txtbox.Size = new System.Drawing.Size(108, 21);
            this.jdlevel_txtbox.TabIndex = 7;
            // 
            // fdvalue_txtbox
            // 
            this.fdvalue_txtbox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.fdvalue_txtbox.Location = new System.Drawing.Point(108, 27);
            this.fdvalue_txtbox.Name = "fdvalue_txtbox";
            this.fdvalue_txtbox.Size = new System.Drawing.Size(108, 21);
            this.fdvalue_txtbox.TabIndex = 6;
            // 
            // stockflowno_ytComboBox
            // 
            this.stockflowno_ytComboBox.ColDefText = null;
            this.stockflowno_ytComboBox.ColStyle = null;
            this.stockflowno_ytComboBox.DataType = null;
            this.stockflowno_ytComboBox.DbConn = null;
            this.stockflowno_ytComboBox.Location = new System.Drawing.Point(534, 46);
            this.stockflowno_ytComboBox.Name = "stockflowno_ytComboBox";
            this.stockflowno_ytComboBox.NextFocusControl = null;
            this.stockflowno_ytComboBox.ReadOnly = false;
            this.stockflowno_ytComboBox.SelParam = null;
            this.stockflowno_ytComboBox.ShowColNum = 0;
            this.stockflowno_ytComboBox.ShowWidth = 0;
            this.stockflowno_ytComboBox.Size = new System.Drawing.Size(150, 22);
            this.stockflowno_ytComboBox.Sql = null;
            this.stockflowno_ytComboBox.SqlStr = null;
            this.stockflowno_ytComboBox.TabIndex = 1;
            this.stockflowno_ytComboBox.TvColName = null;
            this.stockflowno_ytComboBox.Value = null;
            this.stockflowno_ytComboBox.WatermarkText = "";
            // 
            // statuscode_selText
            // 
            this.statuscode_selText.ColDefText = null;
            this.statuscode_selText.ColStyle = null;
            this.statuscode_selText.DataType = null;
            this.statuscode_selText.DbConn = null;
            this.statuscode_selText.Location = new System.Drawing.Point(534, 79);
            this.statuscode_selText.Name = "statuscode_selText";
            this.statuscode_selText.NextFocusControl = null;
            this.statuscode_selText.ReadOnly = false;
            this.statuscode_selText.SelParam = null;
            this.statuscode_selText.ShowColNum = 0;
            this.statuscode_selText.ShowWidth = 0;
            this.statuscode_selText.Size = new System.Drawing.Size(150, 22);
            this.statuscode_selText.Sql = null;
            this.statuscode_selText.SqlStr = null;
            this.statuscode_selText.TabIndex = 2;
            this.statuscode_selText.TvColName = null;
            this.statuscode_selText.Value = null;
            this.statuscode_selText.WatermarkText = "";
            // 
            // Deptid_selText
            // 
            this.Deptid_selText.ColDefText = null;
            this.Deptid_selText.ColStyle = null;
            this.Deptid_selText.DataType = null;
            this.Deptid_selText.DbConn = null;
            this.Deptid_selText.Location = new System.Drawing.Point(534, 16);
            this.Deptid_selText.Name = "Deptid_selText";
            this.Deptid_selText.NextFocusControl = null;
            this.Deptid_selText.ReadOnly = false;
            this.Deptid_selText.SelParam = null;
            this.Deptid_selText.ShowColNum = 0;
            this.Deptid_selText.ShowWidth = 0;
            this.Deptid_selText.Size = new System.Drawing.Size(150, 22);
            this.Deptid_selText.Sql = null;
            this.Deptid_selText.SqlStr = null;
            this.Deptid_selText.TabIndex = 0;
            this.Deptid_selText.TvColName = null;
            this.Deptid_selText.Value = null;
            this.Deptid_selText.WatermarkText = "";
            // 
            // Status_ytComboBox
            // 
            this.Status_ytComboBox.CacheKey = null;
            this.Status_ytComboBox.DbConn = null;
            this.Status_ytComboBox.DefText = null;
            this.Status_ytComboBox.DefValue = null;
            this.Status_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Status_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Status_ytComboBox.Enabled = false;
            this.Status_ytComboBox.EnableEmpty = true;
            this.Status_ytComboBox.FirstText = null;
            this.Status_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Status_ytComboBox.Fomart = null;
            this.Status_ytComboBox.ItemStr = "";
            this.Status_ytComboBox.Location = new System.Drawing.Point(534, 112);
            this.Status_ytComboBox.Name = "ytComboBox1";
            this.Status_ytComboBox.Param = null;
            this.Status_ytComboBox.Size = new System.Drawing.Size(150, 22);
            this.Status_ytComboBox.Sql = null;
            this.Status_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Status_ytComboBox.TabIndex = 5;
            this.Status_ytComboBox.Tag = tvList2;
            this.Status_ytComboBox.Value = null;
            // 
            // eqnum_txtbox
            // 
            this.eqnum_txtbox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.eqnum_txtbox.Location = new System.Drawing.Point(534, 179);
            this.eqnum_txtbox.Name = "eqnum_txtbox";
            this.eqnum_txtbox.Size = new System.Drawing.Size(150, 21);
            this.eqnum_txtbox.TabIndex = 3;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.totaledwork_txtbox);
            this.groupBox3.Controls.Add(this.totalwork_txtbox);
            this.groupBox3.Location = new System.Drawing.Point(753, 20);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(238, 180);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "工作量法计提折旧必填";
            // 
            // label15
            // 
            this.label15.ForeColor = System.Drawing.Color.Blue;
            this.label15.Location = new System.Drawing.Point(9, 49);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 21);
            this.label15.TabIndex = 4;
            this.label15.Text = "总工作量";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.ForeColor = System.Drawing.Color.Blue;
            this.label16.Location = new System.Drawing.Point(9, 122);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 21);
            this.label16.TabIndex = 4;
            this.label16.Text = "累计工作量";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totaledwork_txtbox
            // 
            this.totaledwork_txtbox.Location = new System.Drawing.Point(92, 122);
            this.totaledwork_txtbox.Name = "totaledwork_txtbox";
            this.totaledwork_txtbox.Size = new System.Drawing.Size(120, 21);
            this.totaledwork_txtbox.TabIndex = 5;
            this.totaledwork_txtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // totalwork_txtbox
            // 
            this.totalwork_txtbox.Location = new System.Drawing.Point(92, 49);
            this.totalwork_txtbox.Name = "totalwork_txtbox";
            this.totalwork_txtbox.Size = new System.Drawing.Size(120, 21);
            this.totalwork_txtbox.TabIndex = 4;
            this.totalwork_txtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.ForeColor = System.Drawing.Color.Blue;
            this.label42.Location = new System.Drawing.Point(210, 179);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(83, 21);
            this.label42.TabIndex = 4;
            this.label42.Text = "制卡时间";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.ForeColor = System.Drawing.Color.Blue;
            this.label41.Location = new System.Drawing.Point(13, 137);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(75, 21);
            this.label41.TabIndex = 4;
            this.label41.Text = "操作员姓名";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.ForeColor = System.Drawing.Color.Blue;
            this.label40.Location = new System.Drawing.Point(457, 82);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(72, 21);
            this.label40.TabIndex = 4;
            this.label40.Text = "使用状态";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(455, 17);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 21);
            this.label14.TabIndex = 4;
            this.label14.Text = "使用科室ID";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.ForeColor = System.Drawing.Color.Blue;
            this.label17.Location = new System.Drawing.Point(210, 94);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(83, 21);
            this.label17.TabIndex = 4;
            this.label17.Text = "医疗机构编码";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.ForeColor = System.Drawing.Color.Blue;
            this.label18.Location = new System.Drawing.Point(457, 108);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(50, 22);
            this.label18.TabIndex = 4;
            this.label18.Text = "状态";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.ForeColor = System.Drawing.Color.Blue;
            this.label19.Location = new System.Drawing.Point(15, 174);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(75, 21);
            this.label19.TabIndex = 4;
            this.label19.Text = "操作员ID";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.ForeColor = System.Drawing.Color.Blue;
            this.label20.Location = new System.Drawing.Point(455, 179);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(72, 21);
            this.label20.TabIndex = 4;
            this.label20.Text = "设备数量";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.ForeColor = System.Drawing.Color.Blue;
            this.label21.Location = new System.Drawing.Point(456, 143);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(73, 21);
            this.label21.TabIndex = 4;
            this.label21.Text = "设备名称";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.ForeColor = System.Drawing.Color.Blue;
            this.label22.Location = new System.Drawing.Point(15, 95);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(50, 21);
            this.label22.TabIndex = 4;
            this.label22.Text = "设备ID";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.ForeColor = System.Drawing.Color.Blue;
            this.label23.Location = new System.Drawing.Point(15, 55);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(50, 21);
            this.label23.TabIndex = 4;
            this.label23.Text = "库存ID";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.ForeColor = System.Drawing.Color.Blue;
            this.label24.Location = new System.Drawing.Point(457, 48);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(73, 21);
            this.label24.TabIndex = 4;
            this.label24.Text = "库存流水";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.ForeColor = System.Drawing.Color.Blue;
            this.label25.Location = new System.Drawing.Point(210, 17);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(73, 21);
            this.label25.TabIndex = 4;
            this.label25.Text = "卡号";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.ForeColor = System.Drawing.Color.Blue;
            this.label26.Location = new System.Drawing.Point(15, 17);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(50, 21);
            this.label26.TabIndex = 4;
            this.label26.Text = "卡片ID";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cardcode_txtbox
            // 
            this.cardcode_txtbox.Location = new System.Drawing.Point(299, 20);
            this.cardcode_txtbox.Name = "cardcode_txtbox";
            this.cardcode_txtbox.ReadOnly = true;
            this.cardcode_txtbox.Size = new System.Drawing.Size(133, 21);
            this.cardcode_txtbox.TabIndex = 3;
            this.cardcode_txtbox.TabStop = false;
            // 
            // username_txtbox
            // 
            this.username_txtbox.Location = new System.Drawing.Point(94, 137);
            this.username_txtbox.Name = "username_txtbox";
            this.username_txtbox.ReadOnly = true;
            this.username_txtbox.Size = new System.Drawing.Size(107, 21);
            this.username_txtbox.TabIndex = 3;
            this.username_txtbox.TabStop = false;
            // 
            // userid_txtbox
            // 
            this.userid_txtbox.Location = new System.Drawing.Point(94, 174);
            this.userid_txtbox.Name = "userid_txtbox";
            this.userid_txtbox.ReadOnly = true;
            this.userid_txtbox.Size = new System.Drawing.Size(107, 21);
            this.userid_txtbox.TabIndex = 3;
            this.userid_txtbox.TabStop = false;
            // 
            // recdate_txtbox
            // 
            this.recdate_txtbox.Location = new System.Drawing.Point(299, 179);
            this.recdate_txtbox.Name = "recdate_txtbox";
            this.recdate_txtbox.ReadOnly = true;
            this.recdate_txtbox.Size = new System.Drawing.Size(133, 21);
            this.recdate_txtbox.TabIndex = 3;
            this.recdate_txtbox.TabStop = false;
            // 
            // choscode_txtbox
            // 
            this.choscode_txtbox.Location = new System.Drawing.Point(299, 94);
            this.choscode_txtbox.Name = "choscode_txtbox";
            this.choscode_txtbox.ReadOnly = true;
            this.choscode_txtbox.Size = new System.Drawing.Size(133, 21);
            this.choscode_txtbox.TabIndex = 3;
            this.choscode_txtbox.TabStop = false;
            // 
            // eqId_txtbox
            // 
            this.eqId_txtbox.Location = new System.Drawing.Point(76, 96);
            this.eqId_txtbox.Name = "eqId_txtbox";
            this.eqId_txtbox.ReadOnly = true;
            this.eqId_txtbox.Size = new System.Drawing.Size(125, 21);
            this.eqId_txtbox.TabIndex = 3;
            this.eqId_txtbox.TabStop = false;
            // 
            // stockid_txtbox
            // 
            this.stockid_txtbox.Location = new System.Drawing.Point(76, 56);
            this.stockid_txtbox.Name = "stockid_txtbox";
            this.stockid_txtbox.ReadOnly = true;
            this.stockid_txtbox.Size = new System.Drawing.Size(125, 21);
            this.stockid_txtbox.TabIndex = 3;
            this.stockid_txtbox.TabStop = false;
            // 
            // cardId_txtbox
            // 
            this.cardId_txtbox.Location = new System.Drawing.Point(76, 18);
            this.cardId_txtbox.Name = "cardId_txtbox";
            this.cardId_txtbox.ReadOnly = true;
            this.cardId_txtbox.Size = new System.Drawing.Size(125, 21);
            this.cardId_txtbox.TabIndex = 3;
            this.cardId_txtbox.TabStop = false;
            // 
            // CardFJ_tab
            // 
            this.CardFJ_tab.Controls.Add(this.groupBox5);
            this.CardFJ_tab.Location = new System.Drawing.Point(4, 21);
            this.CardFJ_tab.Margin = new System.Windows.Forms.Padding(10);
            this.CardFJ_tab.Name = "CardFJ_tab";
            this.CardFJ_tab.Padding = new System.Windows.Forms.Padding(5);
            this.CardFJ_tab.Size = new System.Drawing.Size(1270, 495);
            this.CardFJ_tab.TabIndex = 1;
            this.CardFJ_tab.Text = "设备附件";
            this.CardFJ_tab.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dataGView1);
            this.groupBox5.Controls.Add(this.groupBox8);
            this.groupBox5.Controls.Add(this.toolStrip1);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(5, 5);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1260, 485);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "设备附件清单";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.White;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FJ_addtoolStrip,
            this.toolStripSeparator2,
            this.FJ_DeltoolStrip});
            this.toolStrip1.Location = new System.Drawing.Point(3, 17);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1254, 25);
            this.toolStrip1.TabIndex = 7;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // FJ_addtoolStrip
            // 
            this.FJ_addtoolStrip.BackColor = System.Drawing.Color.LightGray;
            this.FJ_addtoolStrip.Image = ((System.Drawing.Image)(resources.GetObject("FJ_addtoolStrip.Image")));
            this.FJ_addtoolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.FJ_addtoolStrip.Name = "FJ_addtoolStrip";
            this.FJ_addtoolStrip.Size = new System.Drawing.Size(97, 22);
            this.FJ_addtoolStrip.Text = "新增附件信息";
            this.FJ_addtoolStrip.Click += new System.EventHandler(this.FJ_addtoolStrip_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // FJ_DeltoolStrip
            // 
            this.FJ_DeltoolStrip.BackColor = System.Drawing.Color.LightGray;
            this.FJ_DeltoolStrip.Image = ((System.Drawing.Image)(resources.GetObject("FJ_DeltoolStrip.Image")));
            this.FJ_DeltoolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.FJ_DeltoolStrip.Name = "FJ_DeltoolStrip";
            this.FJ_DeltoolStrip.Size = new System.Drawing.Size(97, 22);
            this.FJ_DeltoolStrip.Text = "删除附件信息";
            this.FJ_DeltoolStrip.Click += new System.EventHandler(this.FJ_DeltoolStrip_Click);
            // 
            // CardJLRec_tab
            // 
            this.CardJLRec_tab.Controls.Add(this.groupBox6);
            this.CardJLRec_tab.Location = new System.Drawing.Point(4, 21);
            this.CardJLRec_tab.Margin = new System.Windows.Forms.Padding(10);
            this.CardJLRec_tab.Name = "CardJLRec_tab";
            this.CardJLRec_tab.Padding = new System.Windows.Forms.Padding(5);
            this.CardJLRec_tab.Size = new System.Drawing.Size(1270, 495);
            this.CardJLRec_tab.TabIndex = 2;
            this.CardJLRec_tab.Text = "计量设备";
            this.CardJLRec_tab.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dataGView2);
            this.groupBox6.Controls.Add(this.groupBox10);
            this.groupBox6.Controls.Add(this.toolStrip2);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(5, 5);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1260, 485);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "设备维修记录";
            // 
            // toolStrip2
            // 
            this.toolStrip2.BackColor = System.Drawing.Color.White;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.JL_AddtoolStrip,
            this.toolStripSeparator1,
            this.JL_DeltoolStrip});
            this.toolStrip2.Location = new System.Drawing.Point(3, 17);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(1254, 25);
            this.toolStrip2.TabIndex = 4;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // JL_AddtoolStrip
            // 
            this.JL_AddtoolStrip.BackColor = System.Drawing.Color.LightGray;
            this.JL_AddtoolStrip.Image = ((System.Drawing.Image)(resources.GetObject("JL_AddtoolStrip.Image")));
            this.JL_AddtoolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.JL_AddtoolStrip.Name = "JL_AddtoolStrip";
            this.JL_AddtoolStrip.Size = new System.Drawing.Size(97, 22);
            this.JL_AddtoolStrip.Text = "新增维修记录";
            this.JL_AddtoolStrip.Click += new System.EventHandler(this.JL_AddtoolStrip_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // JL_DeltoolStrip
            // 
            this.JL_DeltoolStrip.BackColor = System.Drawing.Color.LightGray;
            this.JL_DeltoolStrip.Image = ((System.Drawing.Image)(resources.GetObject("JL_DeltoolStrip.Image")));
            this.JL_DeltoolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.JL_DeltoolStrip.Name = "JL_DeltoolStrip";
            this.JL_DeltoolStrip.Size = new System.Drawing.Size(97, 22);
            this.JL_DeltoolStrip.Text = "删除维修记录";
            this.JL_DeltoolStrip.Click += new System.EventHandler(this.JL_DeltoolStrip_Click);
            // 
            // CardCC_tab
            // 
            this.CardCC_tab.Controls.Add(this.CCgroupBox);
            this.CardCC_tab.Location = new System.Drawing.Point(4, 21);
            this.CardCC_tab.Margin = new System.Windows.Forms.Padding(10);
            this.CardCC_tab.Name = "CardCC_tab";
            this.CardCC_tab.Padding = new System.Windows.Forms.Padding(5);
            this.CardCC_tab.Size = new System.Drawing.Size(1270, 495);
            this.CardCC_tab.TabIndex = 3;
            this.CardCC_tab.Text = "设备财产管理";
            this.CardCC_tab.UseVisualStyleBackColor = true;
            // 
            // CCgroupBox
            // 
            this.CCgroupBox.Controls.Add(this.CCGet_groupBox);
            this.CCgroupBox.Controls.Add(this.CCNO_groupBo);
            this.CCgroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CCgroupBox.Location = new System.Drawing.Point(5, 5);
            this.CCgroupBox.Name = "CCgroupBox";
            this.CCgroupBox.Size = new System.Drawing.Size(1260, 485);
            this.CCgroupBox.TabIndex = 18;
            this.CCgroupBox.TabStop = false;
            this.CCgroupBox.Text = "设备财产信息";
            // 
            // CCGet_groupBox
            // 
            this.CCGet_groupBox.Controls.Add(this.CCbuydate_textBox);
            this.CCGet_groupBox.Controls.Add(this.label48);
            this.CCGet_groupBox.Controls.Add(this.label52);
            this.CCGet_groupBox.Controls.Add(this.label49);
            this.CCGet_groupBox.Controls.Add(this.label50);
            this.CCGet_groupBox.Controls.Add(this.CCnewold_textBox);
            this.CCGet_groupBox.Controls.Add(this.CCsupply_textBox);
            this.CCGet_groupBox.Controls.Add(this.CCcsname_textBox);
            this.CCGet_groupBox.Controls.Add(this.CCother_textBox);
            this.CCGet_groupBox.Controls.Add(this.label51);
            this.CCGet_groupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CCGet_groupBox.Location = new System.Drawing.Point(645, 17);
            this.CCGet_groupBox.Name = "CCGet_groupBox";
            this.CCGet_groupBox.Size = new System.Drawing.Size(612, 465);
            this.CCGet_groupBox.TabIndex = 19;
            this.CCGet_groupBox.TabStop = false;
            this.CCGet_groupBox.Text = "请手工填写";
            // 
            // CCbuydate_textBox
            // 
            this.CCbuydate_textBox.CustomFormat = "yyyy-MM-dd hh:mm";
            this.CCbuydate_textBox.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.CCbuydate_textBox.Location = new System.Drawing.Point(179, 69);
            this.CCbuydate_textBox.Name = "CCbuydate_textBox";
            this.CCbuydate_textBox.Size = new System.Drawing.Size(210, 21);
            this.CCbuydate_textBox.TabIndex = 2;
            // 
            // label48
            // 
            this.label48.Location = new System.Drawing.Point(79, 25);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(82, 25);
            this.label48.TabIndex = 16;
            this.label48.Text = "供货单位";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.Location = new System.Drawing.Point(79, 209);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(82, 25);
            this.label52.TabIndex = 16;
            this.label52.Text = "其他";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.Location = new System.Drawing.Point(79, 115);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(82, 25);
            this.label49.TabIndex = 16;
            this.label49.Text = "产商名称";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.Location = new System.Drawing.Point(79, 70);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(82, 25);
            this.label50.TabIndex = 16;
            this.label50.Text = "购置日期";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CCnewold_textBox
            // 
            this.CCnewold_textBox.Location = new System.Drawing.Point(179, 160);
            this.CCnewold_textBox.Multiline = true;
            this.CCnewold_textBox.Name = "CCnewold_textBox";
            this.CCnewold_textBox.Size = new System.Drawing.Size(210, 25);
            this.CCnewold_textBox.TabIndex = 4;
            // 
            // CCsupply_textBox
            // 
            this.CCsupply_textBox.Location = new System.Drawing.Point(179, 25);
            this.CCsupply_textBox.Multiline = true;
            this.CCsupply_textBox.Name = "CCsupply_textBox";
            this.CCsupply_textBox.Size = new System.Drawing.Size(210, 25);
            this.CCsupply_textBox.TabIndex = 1;
            // 
            // CCcsname_textBox
            // 
            this.CCcsname_textBox.Location = new System.Drawing.Point(179, 115);
            this.CCcsname_textBox.Multiline = true;
            this.CCcsname_textBox.Name = "CCcsname_textBox";
            this.CCcsname_textBox.Size = new System.Drawing.Size(210, 25);
            this.CCcsname_textBox.TabIndex = 3;
            // 
            // CCother_textBox
            // 
            this.CCother_textBox.Location = new System.Drawing.Point(179, 213);
            this.CCother_textBox.Multiline = true;
            this.CCother_textBox.Name = "CCother_textBox";
            this.CCother_textBox.Size = new System.Drawing.Size(210, 107);
            this.CCother_textBox.TabIndex = 5;
            // 
            // label51
            // 
            this.label51.Location = new System.Drawing.Point(79, 160);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(82, 25);
            this.label51.TabIndex = 16;
            this.label51.Text = "新旧程度";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CCNO_groupBo
            // 
            this.CCNO_groupBo.Controls.Add(this.label39);
            this.CCNO_groupBo.Controls.Add(this.label56);
            this.CCNO_groupBo.Controls.Add(this.label46);
            this.CCNO_groupBo.Controls.Add(this.label53);
            this.CCNO_groupBo.Controls.Add(this.CCuseridtextBox);
            this.CCNO_groupBo.Controls.Add(this.CCchosode_textBox);
            this.CCNO_groupBo.Controls.Add(this.CCcardid_textBox);
            this.CCNO_groupBo.Controls.Add(this.label55);
            this.CCNO_groupBo.Controls.Add(this.CCusername_textBox);
            this.CCNO_groupBo.Controls.Add(this.CCrecdate_textBox);
            this.CCNO_groupBo.Controls.Add(this.CCcc_textBox);
            this.CCNO_groupBo.Controls.Add(this.CCprice_textBox);
            this.CCNO_groupBo.Controls.Add(this.label54);
            this.CCNO_groupBo.Controls.Add(this.label33);
            this.CCNO_groupBo.Dock = System.Windows.Forms.DockStyle.Left;
            this.CCNO_groupBo.Location = new System.Drawing.Point(3, 17);
            this.CCNO_groupBo.Name = "CCNO_groupBo";
            this.CCNO_groupBo.Size = new System.Drawing.Size(642, 465);
            this.CCNO_groupBo.TabIndex = 18;
            this.CCNO_groupBo.TabStop = false;
            this.CCNO_groupBo.Text = "保存时自动从主表获取";
            // 
            // label39
            // 
            this.label39.Location = new System.Drawing.Point(73, 70);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(82, 21);
            this.label39.TabIndex = 16;
            this.label39.Text = "价格";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.Location = new System.Drawing.Point(73, 295);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(82, 21);
            this.label56.TabIndex = 16;
            this.label56.Text = "医疗机构编码";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.Location = new System.Drawing.Point(73, 115);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(82, 21);
            this.label46.TabIndex = 16;
            this.label46.Text = "出厂日期";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.Location = new System.Drawing.Point(73, 250);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(82, 21);
            this.label53.TabIndex = 16;
            this.label53.Text = "操作员ID";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CCuseridtextBox
            // 
            this.CCuseridtextBox.Location = new System.Drawing.Point(176, 250);
            this.CCuseridtextBox.Multiline = true;
            this.CCuseridtextBox.Name = "CCuseridtextBox";
            this.CCuseridtextBox.ReadOnly = true;
            this.CCuseridtextBox.Size = new System.Drawing.Size(150, 21);
            this.CCuseridtextBox.TabIndex = 17;
            this.CCuseridtextBox.TabStop = false;
            // 
            // CCchosode_textBox
            // 
            this.CCchosode_textBox.Location = new System.Drawing.Point(176, 295);
            this.CCchosode_textBox.Multiline = true;
            this.CCchosode_textBox.Name = "CCchosode_textBox";
            this.CCchosode_textBox.ReadOnly = true;
            this.CCchosode_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCchosode_textBox.TabIndex = 17;
            this.CCchosode_textBox.TabStop = false;
            // 
            // CCcardid_textBox
            // 
            this.CCcardid_textBox.Location = new System.Drawing.Point(176, 24);
            this.CCcardid_textBox.Multiline = true;
            this.CCcardid_textBox.Name = "CCcardid_textBox";
            this.CCcardid_textBox.ReadOnly = true;
            this.CCcardid_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCcardid_textBox.TabIndex = 17;
            this.CCcardid_textBox.TabStop = false;
            // 
            // label55
            // 
            this.label55.Location = new System.Drawing.Point(73, 160);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(82, 21);
            this.label55.TabIndex = 16;
            this.label55.Text = "修改时间";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CCusername_textBox
            // 
            this.CCusername_textBox.Location = new System.Drawing.Point(176, 209);
            this.CCusername_textBox.Multiline = true;
            this.CCusername_textBox.Name = "CCusername_textBox";
            this.CCusername_textBox.ReadOnly = true;
            this.CCusername_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCusername_textBox.TabIndex = 17;
            this.CCusername_textBox.TabStop = false;
            // 
            // CCrecdate_textBox
            // 
            this.CCrecdate_textBox.Location = new System.Drawing.Point(176, 160);
            this.CCrecdate_textBox.Multiline = true;
            this.CCrecdate_textBox.Name = "CCrecdate_textBox";
            this.CCrecdate_textBox.ReadOnly = true;
            this.CCrecdate_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCrecdate_textBox.TabIndex = 17;
            this.CCrecdate_textBox.TabStop = false;
            // 
            // CCcc_textBox
            // 
            this.CCcc_textBox.Location = new System.Drawing.Point(176, 115);
            this.CCcc_textBox.Multiline = true;
            this.CCcc_textBox.Name = "CCcc_textBox";
            this.CCcc_textBox.ReadOnly = true;
            this.CCcc_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCcc_textBox.TabIndex = 17;
            this.CCcc_textBox.TabStop = false;
            // 
            // CCprice_textBox
            // 
            this.CCprice_textBox.Location = new System.Drawing.Point(176, 70);
            this.CCprice_textBox.Multiline = true;
            this.CCprice_textBox.Name = "CCprice_textBox";
            this.CCprice_textBox.ReadOnly = true;
            this.CCprice_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCprice_textBox.TabIndex = 17;
            this.CCprice_textBox.TabStop = false;
            // 
            // label54
            // 
            this.label54.Location = new System.Drawing.Point(73, 209);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(82, 21);
            this.label54.TabIndex = 16;
            this.label54.Text = "操作员名称";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(73, 25);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(82, 21);
            this.label33.TabIndex = 16;
            this.label33.Text = "卡片ID";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CardExplain_tab
            // 
            this.CardExplain_tab.Controls.Add(this.button3);
            this.CardExplain_tab.Controls.Add(this.groupBox7);
            this.CardExplain_tab.Controls.Add(this.label66);
            this.CardExplain_tab.Controls.Add(this.label68);
            this.CardExplain_tab.Controls.Add(this.label67);
            this.CardExplain_tab.Controls.Add(this.label61);
            this.CardExplain_tab.Controls.Add(this.SMexplainNum_textBox);
            this.CardExplain_tab.Controls.Add(this.SMusrtid_textBox);
            this.CardExplain_tab.Controls.Add(this.dateTimePicker1);
            this.CardExplain_tab.Controls.Add(this.SMchoscode_textBox);
            this.CardExplain_tab.Controls.Add(this.label65);
            this.CardExplain_tab.Controls.Add(this.label60);
            this.CardExplain_tab.Controls.Add(this.SMboxthing_textBox);
            this.CardExplain_tab.Controls.Add(this.SMusername_textBox);
            this.CardExplain_tab.Controls.Add(this.label64);
            this.CardExplain_tab.Controls.Add(this.label59);
            this.CardExplain_tab.Controls.Add(this.SMteachnum_textBox);
            this.CardExplain_tab.Controls.Add(this.SMother_textBox);
            this.CardExplain_tab.Controls.Add(this.label63);
            this.CardExplain_tab.Controls.Add(this.SMcertificate_textBox);
            this.CardExplain_tab.Controls.Add(this.label62);
            this.CardExplain_tab.Controls.Add(this.SMcardid_textBox);
            this.CardExplain_tab.Controls.Add(this.label57);
            this.CardExplain_tab.Controls.Add(this.SMext_textBox);
            this.CardExplain_tab.Location = new System.Drawing.Point(4, 21);
            this.CardExplain_tab.Margin = new System.Windows.Forms.Padding(10);
            this.CardExplain_tab.Name = "CardExplain_tab";
            this.CardExplain_tab.Padding = new System.Windows.Forms.Padding(5);
            this.CardExplain_tab.Size = new System.Drawing.Size(1270, 495);
            this.CardExplain_tab.TabIndex = 4;
            this.CardExplain_tab.Text = "设备说明书";
            this.CardExplain_tab.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(604, 39);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(106, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "(更改)上传图纸";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.pictureBox1);
            this.groupBox7.Location = new System.Drawing.Point(739, 24);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(273, 272);
            this.groupBox7.TabIndex = 19;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "图纸";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(3, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(267, 252);
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // label66
            // 
            this.label66.Location = new System.Drawing.Point(49, 393);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(95, 21);
            this.label66.TabIndex = 16;
            this.label66.Text = "验收合格证";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.Location = new System.Drawing.Point(39, 199);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(106, 21);
            this.label68.TabIndex = 16;
            this.label68.Text = "医疗机构编码";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.Location = new System.Drawing.Point(39, 79);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(106, 21);
            this.label67.TabIndex = 16;
            this.label67.Text = "修改时间";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.Location = new System.Drawing.Point(49, 162);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(95, 21);
            this.label61.TabIndex = 16;
            this.label61.Text = "操作员名称";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMexplainNum_textBox
            // 
            this.SMexplainNum_textBox.Location = new System.Drawing.Point(184, 239);
            this.SMexplainNum_textBox.Name = "SMexplainNum_textBox";
            this.SMexplainNum_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMexplainNum_textBox.TabIndex = 1;
            // 
            // SMusrtid_textBox
            // 
            this.SMusrtid_textBox.Location = new System.Drawing.Point(184, 119);
            this.SMusrtid_textBox.Name = "SMusrtid_textBox";
            this.SMusrtid_textBox.ReadOnly = true;
            this.SMusrtid_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMusrtid_textBox.TabIndex = 17;
            this.SMusrtid_textBox.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(184, 81);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.ReadOnly = true;
            this.dateTimePicker1.Size = new System.Drawing.Size(164, 21);
            this.dateTimePicker1.TabIndex = 17;
            this.dateTimePicker1.TabStop = false;
            // 
            // SMchoscode_textBox
            // 
            this.SMchoscode_textBox.Location = new System.Drawing.Point(184, 197);
            this.SMchoscode_textBox.Name = "SMchoscode_textBox";
            this.SMchoscode_textBox.ReadOnly = true;
            this.SMchoscode_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMchoscode_textBox.TabIndex = 17;
            this.SMchoscode_textBox.TabStop = false;
            // 
            // label65
            // 
            this.label65.Location = new System.Drawing.Point(49, 355);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(95, 21);
            this.label65.TabIndex = 16;
            this.label65.Text = "装箱单";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.Location = new System.Drawing.Point(49, 120);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(95, 21);
            this.label60.TabIndex = 16;
            this.label60.Text = "操作员ID";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMboxthing_textBox
            // 
            this.SMboxthing_textBox.Location = new System.Drawing.Point(184, 356);
            this.SMboxthing_textBox.Name = "SMboxthing_textBox";
            this.SMboxthing_textBox.Size = new System.Drawing.Size(825, 21);
            this.SMboxthing_textBox.TabIndex = 4;
            // 
            // SMusername_textBox
            // 
            this.SMusername_textBox.Location = new System.Drawing.Point(184, 159);
            this.SMusername_textBox.Name = "SMusername_textBox";
            this.SMusername_textBox.ReadOnly = true;
            this.SMusername_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMusername_textBox.TabIndex = 17;
            this.SMusername_textBox.TabStop = false;
            // 
            // label64
            // 
            this.label64.Location = new System.Drawing.Point(49, 275);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(95, 21);
            this.label64.TabIndex = 16;
            this.label64.Text = "技术说明书份数";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.Location = new System.Drawing.Point(604, 310);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(106, 21);
            this.label59.TabIndex = 16;
            this.label59.Text = "图纸文件格式";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMteachnum_textBox
            // 
            this.SMteachnum_textBox.Location = new System.Drawing.Point(184, 275);
            this.SMteachnum_textBox.Name = "SMteachnum_textBox";
            this.SMteachnum_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMteachnum_textBox.TabIndex = 2;
            // 
            // SMother_textBox
            // 
            this.SMother_textBox.Location = new System.Drawing.Point(184, 315);
            this.SMother_textBox.Multiline = true;
            this.SMother_textBox.Name = "SMother_textBox";
            this.SMother_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMother_textBox.TabIndex = 3;
            // 
            // label63
            // 
            this.label63.Location = new System.Drawing.Point(50, 239);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(95, 21);
            this.label63.TabIndex = 16;
            this.label63.Text = "使用说明书份数";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMcertificate_textBox
            // 
            this.SMcertificate_textBox.Location = new System.Drawing.Point(184, 396);
            this.SMcertificate_textBox.Multiline = true;
            this.SMcertificate_textBox.Name = "SMcertificate_textBox";
            this.SMcertificate_textBox.Size = new System.Drawing.Size(825, 21);
            this.SMcertificate_textBox.TabIndex = 5;
            // 
            // label62
            // 
            this.label62.Location = new System.Drawing.Point(49, 38);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(95, 21);
            this.label62.TabIndex = 16;
            this.label62.Text = "卡片ID";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMcardid_textBox
            // 
            this.SMcardid_textBox.Location = new System.Drawing.Point(184, 39);
            this.SMcardid_textBox.Name = "SMcardid_textBox";
            this.SMcardid_textBox.ReadOnly = true;
            this.SMcardid_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMcardid_textBox.TabIndex = 17;
            this.SMcardid_textBox.TabStop = false;
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.Color.White;
            this.label57.Location = new System.Drawing.Point(39, 314);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(106, 21);
            this.label57.TabIndex = 16;
            this.label57.Text = "其他";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMext_textBox
            // 
            this.SMext_textBox.Location = new System.Drawing.Point(742, 310);
            this.SMext_textBox.Name = "SMext_textBox";
            this.SMext_textBox.ReadOnly = true;
            this.SMext_textBox.Size = new System.Drawing.Size(267, 21);
            this.SMext_textBox.TabIndex = 17;
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(73, 22);
            this.toolStripButton1.Text = "新增附件";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(73, 22);
            this.toolStripButton2.Text = "删除附件";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(73, 22);
            this.toolStripButton3.Text = "新增附件";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(73, 22);
            this.toolStripButton4.Text = "删除附件";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button4);
            this.groupBox9.Controls.Add(this.button5);
            this.groupBox9.Controls.Add(this.maskedTextBox1);
            this.groupBox9.Controls.Add(this.maskedTextBox2);
            this.groupBox9.Controls.Add(this.maskedTextBox3);
            this.groupBox9.Controls.Add(this.maskedTextBox4);
            this.groupBox9.Controls.Add(this.maskedTextBox5);
            this.groupBox9.Controls.Add(this.textBox1);
            this.groupBox9.Controls.Add(this.textBox2);
            this.groupBox9.Controls.Add(this.label69);
            this.groupBox9.Controls.Add(this.label70);
            this.groupBox9.Controls.Add(this.label71);
            this.groupBox9.Controls.Add(this.label72);
            this.groupBox9.Controls.Add(this.label73);
            this.groupBox9.Controls.Add(this.label74);
            this.groupBox9.Controls.Add(this.label75);
            this.groupBox9.Controls.Add(this.label76);
            this.groupBox9.Controls.Add(this.label77);
            this.groupBox9.Controls.Add(this.label78);
            this.groupBox9.Controls.Add(this.label79);
            this.groupBox9.Controls.Add(this.label80);
            this.groupBox9.Controls.Add(this.label81);
            this.groupBox9.Controls.Add(this.label82);
            this.groupBox9.Controls.Add(this.label83);
            this.groupBox9.Controls.Add(this.label84);
            this.groupBox9.Controls.Add(this.label85);
            this.groupBox9.Controls.Add(this.label86);
            this.groupBox9.Controls.Add(this.label87);
            this.groupBox9.Controls.Add(this.label88);
            this.groupBox9.Controls.Add(this.label89);
            this.groupBox9.Controls.Add(this.label90);
            this.groupBox9.Controls.Add(this.label91);
            this.groupBox9.Controls.Add(this.label92);
            this.groupBox9.Controls.Add(this.label93);
            this.groupBox9.Controls.Add(this.textBox3);
            this.groupBox9.Controls.Add(this.textBox4);
            this.groupBox9.Controls.Add(this.textBox5);
            this.groupBox9.Controls.Add(this.textBox6);
            this.groupBox9.Controls.Add(this.textBox7);
            this.groupBox9.Controls.Add(this.textBox8);
            this.groupBox9.Controls.Add(this.textBox9);
            this.groupBox9.Controls.Add(this.textBox10);
            this.groupBox9.Controls.Add(this.textBox11);
            this.groupBox9.Controls.Add(this.textBox12);
            this.groupBox9.Controls.Add(this.textBox13);
            this.groupBox9.Controls.Add(this.textBox14);
            this.groupBox9.Controls.Add(this.textBox15);
            this.groupBox9.Controls.Add(this.textBox16);
            this.groupBox9.Controls.Add(this.textBox17);
            this.groupBox9.Controls.Add(this.textBox18);
            this.groupBox9.Controls.Add(this.textBox19);
            this.groupBox9.Controls.Add(this.textBox20);
            this.groupBox9.Location = new System.Drawing.Point(0, 218);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(1048, 220);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "基本信息";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(522, 98);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 40;
            this.button4.Text = "取消";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(225, 107);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 39;
            this.button5.Text = "保存";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(1035, 94);
            this.maskedTextBox1.Mask = "0000-00-00";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(179, 21);
            this.maskedTextBox1.TabIndex = 80;
            this.maskedTextBox1.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(1035, 125);
            this.maskedTextBox2.Mask = "0000-00-00";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(179, 21);
            this.maskedTextBox2.TabIndex = 81;
            this.maskedTextBox2.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.Location = new System.Drawing.Point(1035, 154);
            this.maskedTextBox3.Mask = "0000-00-00";
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(179, 21);
            this.maskedTextBox3.TabIndex = 82;
            this.maskedTextBox3.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox4
            // 
            this.maskedTextBox4.Location = new System.Drawing.Point(1035, 211);
            this.maskedTextBox4.Mask = "0000-00-00";
            this.maskedTextBox4.Name = "maskedTextBox4";
            this.maskedTextBox4.Size = new System.Drawing.Size(179, 21);
            this.maskedTextBox4.TabIndex = 84;
            this.maskedTextBox4.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox5
            // 
            this.maskedTextBox5.Location = new System.Drawing.Point(1035, 181);
            this.maskedTextBox5.Mask = "0000-00-00";
            this.maskedTextBox5.Name = "maskedTextBox5";
            this.maskedTextBox5.Size = new System.Drawing.Size(179, 21);
            this.maskedTextBox5.TabIndex = 83;
            this.maskedTextBox5.ValidatingType = typeof(System.DateTime);
            // 
            // textBox1
            // 
            this.textBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox1.Location = new System.Drawing.Point(1035, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(179, 21);
            this.textBox1.TabIndex = 72;
            // 
            // textBox2
            // 
            this.textBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox2.Location = new System.Drawing.Point(1035, 62);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(179, 21);
            this.textBox2.TabIndex = 79;
            // 
            // label69
            // 
            this.label69.Location = new System.Drawing.Point(587, 28);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(60, 21);
            this.label69.TabIndex = 58;
            this.label69.Text = "保管人";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label70
            // 
            this.label70.Location = new System.Drawing.Point(940, 62);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(92, 21);
            this.label70.TabIndex = 59;
            this.label70.Text = "已使用年限(月)";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label71
            // 
            this.label71.Location = new System.Drawing.Point(960, 153);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(72, 21);
            this.label71.TabIndex = 54;
            this.label71.Text = "领用时间";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.Location = new System.Drawing.Point(14, 207);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(50, 21);
            this.label72.TabIndex = 55;
            this.label72.Text = "备注";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label73
            // 
            this.label73.Location = new System.Drawing.Point(304, 61);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(75, 21);
            this.label73.TabIndex = 56;
            this.label73.Text = "累计折旧";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label74
            // 
            this.label74.Location = new System.Drawing.Point(587, 94);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(60, 21);
            this.label74.TabIndex = 47;
            this.label74.Text = "领用人";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label75
            // 
            this.label75.Location = new System.Drawing.Point(24, 29);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(50, 21);
            this.label75.TabIndex = 38;
            this.label75.Text = "条形码";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.Location = new System.Drawing.Point(306, 94);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(75, 21);
            this.label76.TabIndex = 39;
            this.label76.Text = "残值率";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label77
            // 
            this.label77.Location = new System.Drawing.Point(587, 152);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(60, 21);
            this.label77.TabIndex = 40;
            this.label77.Text = "报废人";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label78
            // 
            this.label78.Location = new System.Drawing.Point(960, 180);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(72, 21);
            this.label78.TabIndex = 35;
            this.label78.Text = "安装时间";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label79
            // 
            this.label79.Location = new System.Drawing.Point(953, 210);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(72, 21);
            this.label79.TabIndex = 36;
            this.label79.Text = "报废日期";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label80
            // 
            this.label80.Location = new System.Drawing.Point(304, 124);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(75, 21);
            this.label80.TabIndex = 37;
            this.label80.Text = "主要用途";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label81
            // 
            this.label81.Location = new System.Drawing.Point(14, 180);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(63, 21);
            this.label81.TabIndex = 44;
            this.label81.Text = "验收人员";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label82
            // 
            this.label82.Location = new System.Drawing.Point(577, 179);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(60, 21);
            this.label82.TabIndex = 45;
            this.label82.Text = "验收记录";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label83
            // 
            this.label83.Location = new System.Drawing.Point(587, 124);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(60, 21);
            this.label83.TabIndex = 46;
            this.label83.Text = "安装人";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label84
            // 
            this.label84.Location = new System.Drawing.Point(304, 153);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(75, 21);
            this.label84.TabIndex = 41;
            this.label84.Text = "质量情况";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label85
            // 
            this.label85.Location = new System.Drawing.Point(587, 61);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(60, 21);
            this.label85.TabIndex = 42;
            this.label85.Text = "出厂号";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label86
            // 
            this.label86.Location = new System.Drawing.Point(953, 30);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(79, 21);
            this.label86.TabIndex = 51;
            this.label86.Text = "使用年限(月)";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label87
            // 
            this.label87.Location = new System.Drawing.Point(960, 124);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(72, 21);
            this.label87.TabIndex = 43;
            this.label87.Text = "出厂时间";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label88
            // 
            this.label88.Location = new System.Drawing.Point(960, 94);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(72, 21);
            this.label88.TabIndex = 57;
            this.label88.Text = "订购时间";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.Location = new System.Drawing.Point(304, 30);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(75, 21);
            this.label89.TabIndex = 50;
            this.label89.Text = "收费标准";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label90
            // 
            this.label90.Location = new System.Drawing.Point(24, 93);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(50, 21);
            this.label90.TabIndex = 49;
            this.label90.Text = "原值";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label91
            // 
            this.label91.Location = new System.Drawing.Point(24, 62);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(50, 21);
            this.label91.TabIndex = 48;
            this.label91.Text = "价格";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label92
            // 
            this.label92.Location = new System.Drawing.Point(24, 151);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(50, 21);
            this.label92.TabIndex = 53;
            this.label92.Text = "合同号";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label93
            // 
            this.label93.Location = new System.Drawing.Point(24, 124);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(50, 21);
            this.label93.TabIndex = 52;
            this.label93.Text = "国别";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(669, 153);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(191, 21);
            this.textBox3.TabIndex = 77;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(89, 180);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(427, 21);
            this.textBox4.TabIndex = 71;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(669, 179);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(191, 21);
            this.textBox5.TabIndex = 78;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(89, 208);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(771, 21);
            this.textBox6.TabIndex = 70;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(669, 124);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(191, 21);
            this.textBox7.TabIndex = 76;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(385, 152);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(131, 21);
            this.textBox8.TabIndex = 68;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(89, 94);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(121, 21);
            this.textBox9.TabIndex = 69;
            this.textBox9.TabStop = false;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(669, 93);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(191, 21);
            this.textBox10.TabIndex = 75;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(385, 124);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(131, 21);
            this.textBox11.TabIndex = 66;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(89, 62);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(121, 21);
            this.textBox12.TabIndex = 67;
            this.textBox12.TabStop = false;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(669, 62);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(191, 21);
            this.textBox13.TabIndex = 74;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(385, 90);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(131, 21);
            this.textBox14.TabIndex = 65;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(89, 153);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(121, 21);
            this.textBox15.TabIndex = 61;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(669, 31);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(191, 21);
            this.textBox16.TabIndex = 73;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(385, 59);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(131, 21);
            this.textBox17.TabIndex = 64;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(89, 30);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(121, 21);
            this.textBox18.TabIndex = 63;
            this.textBox18.TabStop = false;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(385, 29);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(131, 21);
            this.textBox19.TabIndex = 62;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(89, 124);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(121, 21);
            this.textBox20.TabIndex = 60;
            // 
            // statusStrip2
            // 
            this.statusStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel4,
            this.toolStripStatusLabel5,
            this.toolStripStatusLabel6,
            this.toolStripStatusLabel7});
            this.statusStrip2.Location = new System.Drawing.Point(5, 468);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Size = new System.Drawing.Size(1264, 22);
            this.statusStrip2.TabIndex = 1;
            this.statusStrip2.Text = "statusStrip1";
            this.statusStrip2.Visible = false;
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripStatusLabel4.Image")));
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(69, 17);
            this.toolStripStatusLabel4.Text = "医院软件";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(11, 17);
            this.toolStripStatusLabel5.Text = "|";
            // 
            // toolStripStatusLabel6
            // 
            this.toolStripStatusLabel6.Name = "toolStripStatusLabel6";
            this.toolStripStatusLabel6.Size = new System.Drawing.Size(89, 17);
            this.toolStripStatusLabel6.Text = "上一张卡号为：";
            // 
            // toolStripStatusLabel7
            // 
            this.toolStripStatusLabel7.Name = "toolStripStatusLabel7";
            this.toolStripStatusLabel7.Size = new System.Drawing.Size(0, 17);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.ytComboBox1);
            this.groupBox12.Controls.Add(this.groupBox13);
            this.groupBox12.Controls.Add(this.selTextInpt1);
            this.groupBox12.Controls.Add(this.selTextInpt2);
            this.groupBox12.Controls.Add(this.selTextInpt3);
            this.groupBox12.Controls.Add(this.ytComboBox2);
            this.groupBox12.Controls.Add(this.textBox26);
            this.groupBox12.Controls.Add(this.groupBox14);
            this.groupBox12.Controls.Add(this.label101);
            this.groupBox12.Controls.Add(this.label102);
            this.groupBox12.Controls.Add(this.label103);
            this.groupBox12.Controls.Add(this.label104);
            this.groupBox12.Controls.Add(this.label105);
            this.groupBox12.Controls.Add(this.label106);
            this.groupBox12.Controls.Add(this.label107);
            this.groupBox12.Controls.Add(this.label108);
            this.groupBox12.Controls.Add(this.label109);
            this.groupBox12.Controls.Add(this.label110);
            this.groupBox12.Controls.Add(this.label111);
            this.groupBox12.Controls.Add(this.label112);
            this.groupBox12.Controls.Add(this.label113);
            this.groupBox12.Controls.Add(this.label114);
            this.groupBox12.Controls.Add(this.textBox29);
            this.groupBox12.Controls.Add(this.textBox30);
            this.groupBox12.Controls.Add(this.textBox31);
            this.groupBox12.Controls.Add(this.textBox32);
            this.groupBox12.Controls.Add(this.textBox33);
            this.groupBox12.Controls.Add(this.textBox34);
            this.groupBox12.Controls.Add(this.textBox35);
            this.groupBox12.Controls.Add(this.textBox36);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox12.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox12.Location = new System.Drawing.Point(5, 5);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(1264, 207);
            this.groupBox12.TabIndex = 0;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "必填项(*)";
            // 
            // ytComboBox1
            // 
            this.ytComboBox1.CacheKey = null;
            this.ytComboBox1.DbConn = null;
            this.ytComboBox1.DefText = null;
            this.ytComboBox1.DefValue = null;
            this.ytComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox1.EnableEmpty = true;
            this.ytComboBox1.FirstText = null;
            this.ytComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox1.Fomart = null;
            this.ytComboBox1.ItemStr = "";
            this.ytComboBox1.Location = new System.Drawing.Point(534, 111);
            this.ytComboBox1.Name = "eqname_ytComboBox";
            this.ytComboBox1.Param = null;
            this.ytComboBox1.Size = new System.Drawing.Size(150, 22);
            this.ytComboBox1.Sql = null;
            this.ytComboBox1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox1.TabIndex = 3;
            this.ytComboBox1.Tag = tvList3;
            this.ytComboBox1.Value = null;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label94);
            this.groupBox13.Controls.Add(this.label95);
            this.groupBox13.Controls.Add(this.label96);
            this.groupBox13.Controls.Add(this.label97);
            this.groupBox13.Controls.Add(this.label98);
            this.groupBox13.Controls.Add(this.textBox21);
            this.groupBox13.Controls.Add(this.textBox22);
            this.groupBox13.Controls.Add(this.textBox23);
            this.groupBox13.Controls.Add(this.textBox24);
            this.groupBox13.Controls.Add(this.textBox25);
            this.groupBox13.Location = new System.Drawing.Point(1019, 16);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(239, 188);
            this.groupBox13.TabIndex = 9;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "计量设备必填项";
            // 
            // label94
            // 
            this.label94.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label94.Location = new System.Drawing.Point(11, 127);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(79, 21);
            this.label94.TabIndex = 4;
            this.label94.Text = "测量范围";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label95
            // 
            this.label95.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label95.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label95.Location = new System.Drawing.Point(12, 158);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(79, 21);
            this.label95.TabIndex = 4;
            this.label95.Text = "检定周期(月)";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label96
            // 
            this.label96.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label96.Location = new System.Drawing.Point(12, 26);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(78, 21);
            this.label96.TabIndex = 50;
            this.label96.Text = "分度值";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label97
            // 
            this.label97.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label97.Location = new System.Drawing.Point(11, 57);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(79, 21);
            this.label97.TabIndex = 4;
            this.label97.Text = "精度等级";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label98
            // 
            this.label98.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label98.Location = new System.Drawing.Point(11, 91);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(79, 21);
            this.label98.TabIndex = 4;
            this.label98.Text = "检定等级";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox21
            // 
            this.textBox21.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox21.Location = new System.Drawing.Point(108, 158);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(108, 21);
            this.textBox21.TabIndex = 12;
            // 
            // textBox22
            // 
            this.textBox22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox22.Location = new System.Drawing.Point(108, 126);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(108, 21);
            this.textBox22.TabIndex = 11;
            // 
            // textBox23
            // 
            this.textBox23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox23.Location = new System.Drawing.Point(108, 92);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(108, 21);
            this.textBox23.TabIndex = 10;
            // 
            // textBox24
            // 
            this.textBox24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox24.Location = new System.Drawing.Point(108, 58);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(108, 21);
            this.textBox24.TabIndex = 9;
            // 
            // textBox25
            // 
            this.textBox25.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox25.Location = new System.Drawing.Point(108, 27);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(108, 21);
            this.textBox25.TabIndex = 8;
            // 
            // selTextInpt1
            // 
            this.selTextInpt1.ColDefText = null;
            this.selTextInpt1.ColStyle = null;
            this.selTextInpt1.DataType = null;
            this.selTextInpt1.DbConn = null;
            this.selTextInpt1.Location = new System.Drawing.Point(534, 46);
            this.selTextInpt1.Name = "selTextInpt1";
            this.selTextInpt1.NextFocusControl = null;
            this.selTextInpt1.ReadOnly = false;
            this.selTextInpt1.SelParam = null;
            this.selTextInpt1.ShowColNum = 0;
            this.selTextInpt1.ShowWidth = 0;
            this.selTextInpt1.Size = new System.Drawing.Size(150, 22);
            this.selTextInpt1.Sql = null;
            this.selTextInpt1.SqlStr = null;
            this.selTextInpt1.TabIndex = 1;
            this.selTextInpt1.TvColName = null;
            this.selTextInpt1.Value = null;
            this.selTextInpt1.WatermarkText = "";
            // 
            // selTextInpt2
            // 
            this.selTextInpt2.ColDefText = null;
            this.selTextInpt2.ColStyle = null;
            this.selTextInpt2.DataType = null;
            this.selTextInpt2.DbConn = null;
            this.selTextInpt2.Location = new System.Drawing.Point(534, 79);
            this.selTextInpt2.Name = "selTextInpt2";
            this.selTextInpt2.NextFocusControl = null;
            this.selTextInpt2.ReadOnly = false;
            this.selTextInpt2.SelParam = null;
            this.selTextInpt2.ShowColNum = 0;
            this.selTextInpt2.ShowWidth = 0;
            this.selTextInpt2.Size = new System.Drawing.Size(150, 22);
            this.selTextInpt2.Sql = null;
            this.selTextInpt2.SqlStr = null;
            this.selTextInpt2.TabIndex = 2;
            this.selTextInpt2.TvColName = null;
            this.selTextInpt2.Value = null;
            this.selTextInpt2.WatermarkText = "";
            // 
            // selTextInpt3
            // 
            this.selTextInpt3.ColDefText = null;
            this.selTextInpt3.ColStyle = null;
            this.selTextInpt3.DataType = null;
            this.selTextInpt3.DbConn = null;
            this.selTextInpt3.Location = new System.Drawing.Point(534, 16);
            this.selTextInpt3.Name = "selTextInpt3";
            this.selTextInpt3.NextFocusControl = null;
            this.selTextInpt3.ReadOnly = false;
            this.selTextInpt3.SelParam = null;
            this.selTextInpt3.ShowColNum = 0;
            this.selTextInpt3.ShowWidth = 0;
            this.selTextInpt3.Size = new System.Drawing.Size(150, 22);
            this.selTextInpt3.Sql = null;
            this.selTextInpt3.SqlStr = null;
            this.selTextInpt3.TabIndex = 0;
            this.selTextInpt3.TvColName = null;
            this.selTextInpt3.Value = null;
            this.selTextInpt3.WatermarkText = "";
            // 
            // ytComboBox2
            // 
            this.ytComboBox2.CacheKey = null;
            this.ytComboBox2.DbConn = null;
            this.ytComboBox2.DefText = null;
            this.ytComboBox2.DefValue = null;
            this.ytComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox2.EnableEmpty = true;
            this.ytComboBox2.FirstText = null;
            this.ytComboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox2.Fomart = null;
            this.ytComboBox2.ItemStr = "";
            this.ytComboBox2.Location = new System.Drawing.Point(534, 144);
            this.ytComboBox2.Name = "ytComboBox1";
            this.ytComboBox2.Param = null;
            this.ytComboBox2.Size = new System.Drawing.Size(150, 22);
            this.ytComboBox2.Sql = null;
            this.ytComboBox2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox2.TabIndex = 5;
            this.ytComboBox2.Tag = tvList4;
            this.ytComboBox2.Value = null;
            // 
            // textBox26
            // 
            this.textBox26.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox26.Location = new System.Drawing.Point(534, 179);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(150, 21);
            this.textBox26.TabIndex = 4;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label99);
            this.groupBox14.Controls.Add(this.label100);
            this.groupBox14.Controls.Add(this.textBox27);
            this.groupBox14.Controls.Add(this.textBox28);
            this.groupBox14.Location = new System.Drawing.Point(753, 20);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(238, 180);
            this.groupBox14.TabIndex = 6;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "工作量法计提折旧必填";
            // 
            // label99
            // 
            this.label99.Location = new System.Drawing.Point(9, 49);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(72, 21);
            this.label99.TabIndex = 4;
            this.label99.Text = "总工作量";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label100
            // 
            this.label100.Location = new System.Drawing.Point(9, 122);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(72, 21);
            this.label100.TabIndex = 4;
            this.label100.Text = "累计工作量";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(92, 122);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(120, 21);
            this.textBox27.TabIndex = 7;
            this.textBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(92, 49);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(120, 21);
            this.textBox28.TabIndex = 6;
            this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label101
            // 
            this.label101.BackColor = System.Drawing.Color.Transparent;
            this.label101.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label101.Location = new System.Drawing.Point(210, 179);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(83, 21);
            this.label101.TabIndex = 4;
            this.label101.Text = "制卡时间";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label102
            // 
            this.label102.BackColor = System.Drawing.Color.Transparent;
            this.label102.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label102.Location = new System.Drawing.Point(13, 137);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(75, 21);
            this.label102.TabIndex = 4;
            this.label102.Text = "操作员姓名";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label103
            // 
            this.label103.BackColor = System.Drawing.Color.Transparent;
            this.label103.ForeColor = System.Drawing.Color.Crimson;
            this.label103.Location = new System.Drawing.Point(457, 82);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(72, 21);
            this.label103.TabIndex = 4;
            this.label103.Text = "使用状态";
            this.label103.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label104
            // 
            this.label104.BackColor = System.Drawing.Color.Transparent;
            this.label104.ForeColor = System.Drawing.Color.Crimson;
            this.label104.Location = new System.Drawing.Point(455, 17);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(72, 21);
            this.label104.TabIndex = 4;
            this.label104.Text = "使用科室ID";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label105
            // 
            this.label105.BackColor = System.Drawing.Color.Transparent;
            this.label105.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label105.Location = new System.Drawing.Point(210, 94);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(83, 21);
            this.label105.TabIndex = 4;
            this.label105.Text = "医疗机构编码";
            this.label105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label106
            // 
            this.label106.BackColor = System.Drawing.Color.Transparent;
            this.label106.ForeColor = System.Drawing.Color.Crimson;
            this.label106.Location = new System.Drawing.Point(457, 143);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(50, 22);
            this.label106.TabIndex = 4;
            this.label106.Text = "状态";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label107
            // 
            this.label107.BackColor = System.Drawing.Color.Transparent;
            this.label107.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label107.Location = new System.Drawing.Point(15, 174);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(75, 21);
            this.label107.TabIndex = 4;
            this.label107.Text = "操作员ID";
            this.label107.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label108
            // 
            this.label108.BackColor = System.Drawing.Color.Transparent;
            this.label108.ForeColor = System.Drawing.Color.Crimson;
            this.label108.Location = new System.Drawing.Point(455, 179);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(72, 21);
            this.label108.TabIndex = 4;
            this.label108.Text = "设备数量";
            this.label108.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label109
            // 
            this.label109.BackColor = System.Drawing.Color.Transparent;
            this.label109.ForeColor = System.Drawing.Color.Crimson;
            this.label109.Location = new System.Drawing.Point(457, 112);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(73, 21);
            this.label109.TabIndex = 4;
            this.label109.Text = "设备名称";
            this.label109.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label110
            // 
            this.label110.BackColor = System.Drawing.Color.Transparent;
            this.label110.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label110.Location = new System.Drawing.Point(15, 95);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(50, 21);
            this.label110.TabIndex = 4;
            this.label110.Text = "设备ID";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label111
            // 
            this.label111.BackColor = System.Drawing.Color.Transparent;
            this.label111.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label111.Location = new System.Drawing.Point(15, 55);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(50, 21);
            this.label111.TabIndex = 4;
            this.label111.Text = "库存ID";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label112
            // 
            this.label112.BackColor = System.Drawing.Color.Transparent;
            this.label112.ForeColor = System.Drawing.Color.Crimson;
            this.label112.Location = new System.Drawing.Point(457, 48);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(73, 21);
            this.label112.TabIndex = 4;
            this.label112.Text = "库存流水";
            this.label112.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label113
            // 
            this.label113.BackColor = System.Drawing.Color.Transparent;
            this.label113.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label113.Location = new System.Drawing.Point(210, 17);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(73, 21);
            this.label113.TabIndex = 4;
            this.label113.Text = "卡号";
            this.label113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label114
            // 
            this.label114.BackColor = System.Drawing.Color.Transparent;
            this.label114.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label114.Location = new System.Drawing.Point(15, 17);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(50, 21);
            this.label114.TabIndex = 4;
            this.label114.Text = "卡片ID";
            this.label114.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(299, 20);
            this.textBox29.Name = "textBox29";
            this.textBox29.ReadOnly = true;
            this.textBox29.Size = new System.Drawing.Size(133, 21);
            this.textBox29.TabIndex = 3;
            this.textBox29.TabStop = false;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(94, 137);
            this.textBox30.Name = "textBox30";
            this.textBox30.ReadOnly = true;
            this.textBox30.Size = new System.Drawing.Size(107, 21);
            this.textBox30.TabIndex = 3;
            this.textBox30.TabStop = false;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(94, 174);
            this.textBox31.Name = "textBox31";
            this.textBox31.ReadOnly = true;
            this.textBox31.Size = new System.Drawing.Size(107, 21);
            this.textBox31.TabIndex = 3;
            this.textBox31.TabStop = false;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(299, 179);
            this.textBox32.Name = "textBox32";
            this.textBox32.ReadOnly = true;
            this.textBox32.Size = new System.Drawing.Size(133, 21);
            this.textBox32.TabIndex = 3;
            this.textBox32.TabStop = false;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(299, 94);
            this.textBox33.Name = "textBox33";
            this.textBox33.ReadOnly = true;
            this.textBox33.Size = new System.Drawing.Size(133, 21);
            this.textBox33.TabIndex = 3;
            this.textBox33.TabStop = false;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(76, 96);
            this.textBox34.Name = "textBox34";
            this.textBox34.ReadOnly = true;
            this.textBox34.Size = new System.Drawing.Size(125, 21);
            this.textBox34.TabIndex = 3;
            this.textBox34.TabStop = false;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(76, 56);
            this.textBox35.Name = "textBox35";
            this.textBox35.ReadOnly = true;
            this.textBox35.Size = new System.Drawing.Size(125, 21);
            this.textBox35.TabIndex = 3;
            this.textBox35.TabStop = false;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(76, 18);
            this.textBox36.Name = "textBox36";
            this.textBox36.ReadOnly = true;
            this.textBox36.Size = new System.Drawing.Size(125, 21);
            this.textBox36.TabIndex = 3;
            this.textBox36.TabStop = false;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.JinEHeJi);
            this.groupBox8.Controls.Add(this.label115);
            this.groupBox8.Controls.Add(this.TiaoSu);
            this.groupBox8.Controls.Add(this.label116);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox8.Location = new System.Drawing.Point(3, 439);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1254, 43);
            this.groupBox8.TabIndex = 9;
            this.groupBox8.TabStop = false;
            // 
            // dataGView1
            // 
            this.dataGView1.AllowUserToAddRows = false;
            this.dataGView1.AllowUserToDeleteRows = false;
            this.dataGView1.AllowUserToResizeRows = false;
            this.dataGView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGView1.ChangeDataColumName = null;
            this.dataGView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FJ_CardIdCloumn,
            this.FJ_RowNoColumn,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.FJ_unitColumn,
            this.FJ_NUMColumn,
            this.FJ_PriceColumn,
            this.FJ_MoneyColumn,
            this.FJ_Status,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15});
            this.dataGView1.DbConn = null;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGView1.DwColIndex = 0;
            this.dataGView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView1.IsEditOnEnter = true;
            this.dataGView1.IsFillForm = true;
            this.dataGView1.IsPage = false;
            this.dataGView1.Key = null;
            this.dataGView1.Location = new System.Drawing.Point(3, 42);
            this.dataGView1.MultiSelect = false;
            this.dataGView1.Name = "dataGView1";
            this.dataGView1.RowHeadersWidth = 20;
            this.dataGView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView1.RowTemplate.Height = 23;
            this.dataGView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView1.Size = new System.Drawing.Size(1254, 397);
            this.dataGView1.TabIndex = 10;
            this.dataGView1.TjFmtStr = null;
            this.dataGView1.TjFormat = null;
            this.dataGView1.Url = null;
            this.dataGView1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGView1_CellValueChanged);
            this.dataGView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGView1_RowPostPaint);
            // 
            // FJ_CardIdCloumn
            // 
            this.FJ_CardIdCloumn.DataPropertyName = "CARDID";
            this.FJ_CardIdCloumn.HeaderText = "卡片ID";
            this.FJ_CardIdCloumn.Name = "FJ_CardIdCloumn";
            this.FJ_CardIdCloumn.ReadOnly = true;
            this.FJ_CardIdCloumn.Width = 66;
            // 
            // FJ_RowNoColumn
            // 
            this.FJ_RowNoColumn.DataPropertyName = "ROWNO";
            this.FJ_RowNoColumn.HeaderText = "行号";
            this.FJ_RowNoColumn.Name = "FJ_RowNoColumn";
            this.FJ_RowNoColumn.ReadOnly = true;
            this.FJ_RowNoColumn.Width = 54;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "FJNAME";
            this.Column3.HeaderText = "附件名称";
            this.Column3.Name = "Column3";
            this.Column3.Width = 78;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "COUNTRY";
            this.Column4.HeaderText = "国别";
            this.Column4.Name = "Column4";
            this.Column4.Width = 54;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "GGXH";
            this.Column5.HeaderText = "规格型号";
            this.Column5.Name = "Column5";
            this.Column5.Width = 78;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "CCCODE";
            this.Column6.HeaderText = "出厂号";
            this.Column6.Name = "Column6";
            this.Column6.Width = 66;
            // 
            // FJ_unitColumn
            // 
            this.FJ_unitColumn.DataPropertyName = "UNIT";
            this.FJ_unitColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.FJ_unitColumn.HeaderText = "单位";
            this.FJ_unitColumn.Name = "FJ_unitColumn";
            this.FJ_unitColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.FJ_unitColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.FJ_unitColumn.Width = 54;
            // 
            // FJ_NUMColumn
            // 
            this.FJ_NUMColumn.DataPropertyName = "NUM";
            this.FJ_NUMColumn.HeaderText = "数量";
            this.FJ_NUMColumn.Name = "FJ_NUMColumn";
            this.FJ_NUMColumn.Width = 54;
            // 
            // FJ_PriceColumn
            // 
            this.FJ_PriceColumn.DataPropertyName = "PRICE";
            this.FJ_PriceColumn.HeaderText = "单价";
            this.FJ_PriceColumn.Name = "FJ_PriceColumn";
            this.FJ_PriceColumn.Width = 54;
            // 
            // FJ_MoneyColumn
            // 
            this.FJ_MoneyColumn.DataPropertyName = "TOTALMONEY";
            this.FJ_MoneyColumn.HeaderText = "金额";
            this.FJ_MoneyColumn.Name = "FJ_MoneyColumn";
            this.FJ_MoneyColumn.ReadOnly = true;
            this.FJ_MoneyColumn.Width = 54;
            // 
            // FJ_Status
            // 
            this.FJ_Status.DataPropertyName = "STATUS";
            this.FJ_Status.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.FJ_Status.HeaderText = "状态";
            this.FJ_Status.Name = "FJ_Status";
            this.FJ_Status.ReadOnly = true;
            this.FJ_Status.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.FJ_Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.FJ_Status.Width = 54;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "USERID";
            this.Column12.HeaderText = "操作员ID";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 78;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "USERNAME";
            this.Column13.HeaderText = "操作员名称";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Width = 90;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "RECDATE";
            this.Column14.HeaderText = "修改时间";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column14.Width = 78;
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "CHOSCODE";
            this.Column15.HeaderText = "医疗机构编码";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Width = 102;
            // 
            // JinEHeJi
            // 
            this.JinEHeJi.AutoSize = true;
            this.JinEHeJi.Location = new System.Drawing.Point(497, 17);
            this.JinEHeJi.Name = "JinEHeJi";
            this.JinEHeJi.Size = new System.Drawing.Size(23, 12);
            this.JinEHeJi.TabIndex = 37;
            this.JinEHeJi.Text = "0元";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(424, 17);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(77, 12);
            this.label115.TabIndex = 36;
            this.label115.Text = "总金额合计：";
            // 
            // TiaoSu
            // 
            this.TiaoSu.AutoSize = true;
            this.TiaoSu.Location = new System.Drawing.Point(79, 17);
            this.TiaoSu.Name = "TiaoSu";
            this.TiaoSu.Size = new System.Drawing.Size(23, 12);
            this.TiaoSu.TabIndex = 35;
            this.TiaoSu.Text = "0笔";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(54, 17);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(29, 12);
            this.label116.TabIndex = 34;
            this.label116.Text = "共：";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label119);
            this.groupBox10.Controls.Add(this.label120);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox10.Location = new System.Drawing.Point(3, 445);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(1254, 37);
            this.groupBox10.TabIndex = 5;
            this.groupBox10.TabStop = false;
            // 
            // dataGView2
            // 
            this.dataGView2.AllowUserToAddRows = false;
            this.dataGView2.AllowUserToDeleteRows = false;
            this.dataGView2.AllowUserToResizeRows = false;
            this.dataGView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGView2.ChangeDataColumName = null;
            this.dataGView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.JL_CardIdColumn,
            this.JL_RowNOColumn,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.JL_CheckdateColumn,
            this.JL_CheckDate_Column,
            this.JL_StatusColumn,
            this.dataGridViewTextBoxColumn36,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39});
            this.dataGView2.DbConn = null;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGView2.DwColIndex = 0;
            this.dataGView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView2.IsEditOnEnter = true;
            this.dataGView2.IsFillForm = true;
            this.dataGView2.IsPage = false;
            this.dataGView2.Key = null;
            this.dataGView2.Location = new System.Drawing.Point(3, 42);
            this.dataGView2.MultiSelect = false;
            this.dataGView2.Name = "dataGView2";
            this.dataGView2.RowHeadersWidth = 20;
            this.dataGView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView2.RowTemplate.Height = 23;
            this.dataGView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView2.Size = new System.Drawing.Size(1254, 403);
            this.dataGView2.TabIndex = 8;
            this.dataGView2.TjFmtStr = null;
            this.dataGView2.TjFormat = null;
            this.dataGView2.Url = null;
            this.dataGView2.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGView2_RowPostPaint);
            // 
            // JL_CardIdColumn
            // 
            this.JL_CardIdColumn.DataPropertyName = "CARDID";
            this.JL_CardIdColumn.HeaderText = "卡片ID";
            this.JL_CardIdColumn.Name = "JL_CardIdColumn";
            this.JL_CardIdColumn.ReadOnly = true;
            this.JL_CardIdColumn.Width = 66;
            // 
            // JL_RowNOColumn
            // 
            this.JL_RowNOColumn.DataPropertyName = "ROWNO";
            this.JL_RowNOColumn.HeaderText = "行号";
            this.JL_RowNOColumn.Name = "JL_RowNOColumn";
            this.JL_RowNOColumn.ReadOnly = true;
            this.JL_RowNOColumn.Width = 54;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "REPAIRTHING";
            this.dataGridViewTextBoxColumn29.HeaderText = "维修内容摘要";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.Width = 102;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "JL";
            this.dataGridViewTextBoxColumn30.HeaderText = "结论";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.Width = 54;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "REPAIRPEOPLE";
            this.dataGridViewTextBoxColumn31.HeaderText = "维修人";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.Width = 66;
            // 
            // JL_CheckdateColumn
            // 
            this.JL_CheckdateColumn.DataPropertyName = "REPAIRDATE";
            this.JL_CheckdateColumn.Formt = null;
            this.JL_CheckdateColumn.HeaderText = "维修日期";
            this.JL_CheckdateColumn.Name = "JL_CheckdateColumn";
            this.JL_CheckdateColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.JL_CheckdateColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.JL_CheckdateColumn.Width = 78;
            // 
            // JL_CheckDate_Column
            // 
            this.JL_CheckDate_Column.DataPropertyName = "CHECKDATE";
            this.JL_CheckDate_Column.Formt = null;
            this.JL_CheckDate_Column.HeaderText = "检定日期";
            this.JL_CheckDate_Column.Name = "JL_CheckDate_Column";
            this.JL_CheckDate_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.JL_CheckDate_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.JL_CheckDate_Column.Width = 78;
            // 
            // JL_StatusColumn
            // 
            this.JL_StatusColumn.DataPropertyName = "STATUS";
            this.JL_StatusColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.JL_StatusColumn.HeaderText = "状态";
            this.JL_StatusColumn.Name = "JL_StatusColumn";
            this.JL_StatusColumn.ReadOnly = true;
            this.JL_StatusColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.JL_StatusColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.JL_StatusColumn.Width = 54;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "USERID";
            this.dataGridViewTextBoxColumn36.HeaderText = "操作员ID";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            this.dataGridViewTextBoxColumn36.Width = 78;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.DataPropertyName = "USERNAME";
            this.dataGridViewTextBoxColumn37.HeaderText = "操作员名称";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.ReadOnly = true;
            this.dataGridViewTextBoxColumn37.Width = 90;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.DataPropertyName = "RECDATE";
            this.dataGridViewTextBoxColumn38.HeaderText = "修改时间";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.ReadOnly = true;
            this.dataGridViewTextBoxColumn38.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn38.Width = 78;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.DataPropertyName = "CHOSCODE";
            this.dataGridViewTextBoxColumn39.HeaderText = "医疗机构编码";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.ReadOnly = true;
            this.dataGridViewTextBoxColumn39.Width = 102;
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(89, 17);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(23, 12);
            this.label119.TabIndex = 37;
            this.label119.Text = "0笔";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(54, 17);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(29, 12);
            this.label120.TabIndex = 36;
            this.label120.Text = "共：";
            // 
            // AddEQBuildCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 540);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddEQBuildCard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "设备卡片单";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.AddEQBuildCard_Load);
            this.groupBox1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.CardRec_tab.ResumeLayout(false);
            this.CardRec_tab.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.CardFJ_tab.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.CardJLRec_tab.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.CardCC_tab.ResumeLayout(false);
            this.CCgroupBox.ResumeLayout(false);
            this.CCGet_groupBox.ResumeLayout(false);
            this.CCGet_groupBox.PerformLayout();
            this.CCNO_groupBo.ResumeLayout(false);
            this.CCNO_groupBo.PerformLayout();
            this.CardExplain_tab.ResumeLayout(false);
            this.CardExplain_tab.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.statusStrip2.ResumeLayout(false);
            this.statusStrip2.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage CardRec_tab;
        private System.Windows.Forms.TabPage CardFJ_tab;
        private System.Windows.Forms.TabPage CardJLRec_tab;
        private System.Windows.Forms.TabPage CardCC_tab;
        private System.Windows.Forms.TabPage CardExplain_tab;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolstrip_cardcode_status;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label lb34;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox cardId_txtbox;
        private System.Windows.Forms.TextBox stockid_txtbox;
        private System.Windows.Forms.TextBox cardcode_txtbox;
        private System.Windows.Forms.TextBox eqId_txtbox;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox checkrange_txtbox;
        private System.Windows.Forms.TextBox checklevel_txtbox;
        private System.Windows.Forms.TextBox jdlevel_txtbox;
        private System.Windows.Forms.TextBox fdvalue_txtbox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox totaledwork_txtbox;
        private System.Windows.Forms.TextBox totalwork_txtbox;
        private System.Windows.Forms.TextBox username_txtbox;
        private System.Windows.Forms.TextBox userid_txtbox;
        private System.Windows.Forms.TextBox recdate_txtbox;
        private System.Windows.Forms.TextBox choscode_txtbox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private YtWinContrl.com.contrl.YtComboBox Status_ytComboBox;
        private YtWinContrl.com.contrl.SelTextInpt Deptid_selText;
        private YtWinContrl.com.contrl.YtComboBox eqname_ytComboBox;
        private YtWinContrl.com.contrl.SelTextInpt statuscode_selText;
        private System.Windows.Forms.TextBox eqnum_txtbox;
        private System.Windows.Forms.TextBox checkZQ_txtbox;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox CCuseridtextBox;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox CCusername_textBox;
        private System.Windows.Forms.TextBox CCcsname_textBox;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox CCsupply_textBox;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox CCchosode_textBox;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox CCother_textBox;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox CCprice_textBox;
        private System.Windows.Forms.TextBox CCnewold_textBox;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox CCcardid_textBox;
        private System.Windows.Forms.GroupBox CCgroupBox;
        private System.Windows.Forms.GroupBox CCNO_groupBo;
        private System.Windows.Forms.GroupBox CCGet_groupBox;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox SMexplainNum_textBox;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox SMboxthing_textBox;
        private System.Windows.Forms.TextBox SMusername_textBox;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox SMteachnum_textBox;
        private System.Windows.Forms.TextBox SMother_textBox;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox SMcertificate_textBox;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox SMcardid_textBox;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox SMext_textBox;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox SMusrtid_textBox;
        private System.Windows.Forms.TextBox SMchoscode_textBox;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox CCcc_textBox;
        private System.Windows.Forms.TextBox CCrecdate_textBox;
        private System.Windows.Forms.TextBox dateTimePicker1;
        private YtWinContrl.com.contrl.SelTextInpt stockflowno_ytComboBox;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox synx_textBox;
        private System.Windows.Forms.TextBox YSYNX_textBox;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox BFR_textBox;
        private System.Windows.Forms.TextBox yanshourenyuan_txtBox;
        private System.Windows.Forms.TextBox yanshoujilu_textBox;
        private System.Windows.Forms.TextBox memo_textBox;
        private System.Windows.Forms.TextBox AZR_textBox;
        private System.Windows.Forms.TextBox zhiliangqingkuang_textBox;
        private System.Windows.Forms.TextBox yuanzhi_textBox;
        private System.Windows.Forms.TextBox LYR_textBox;
        private System.Windows.Forms.TextBox zhuyaoyongtu_textBox;
        private System.Windows.Forms.TextBox jiage_textBox;
        private System.Windows.Forms.TextBox CCH_textBox;
        private System.Windows.Forms.TextBox canzhilv_textBox;
        private System.Windows.Forms.TextBox hetonghao_textBox;
        private System.Windows.Forms.TextBox baoguanren_textBox;
        private System.Windows.Forms.TextBox leijizhejiu_textBox;
        private System.Windows.Forms.TextBox txm_textBox;
        private System.Windows.Forms.TextBox shoufeibiaozhun_textBox;
        private System.Windows.Forms.TextBox guobie_textBox;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.MaskedTextBox maskedTextBox8;
        private System.Windows.Forms.MaskedTextBox maskedTextBox9;
        private System.Windows.Forms.MaskedTextBox maskedTextBox10;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox4;
        private System.Windows.Forms.MaskedTextBox maskedTextBox5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel6;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel7;
        private System.Windows.Forms.GroupBox groupBox12;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox1;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt1;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt2;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt3;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox2;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.DateTimePicker dinggou_dateTimePicker1;
        private System.Windows.Forms.DateTimePicker CCSJdateTimePicker2;
        private System.Windows.Forms.DateTimePicker LYSJ_dateTimePicker;
        private System.Windows.Forms.DateTimePicker BFRQ_dateTimePicker;
        private System.Windows.Forms.DateTimePicker AZSJ_dateTimePicker;
        private System.Windows.Forms.DateTimePicker CCbuydate_textBox;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton JL_AddtoolStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton JL_DeltoolStrip;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton FJ_addtoolStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton FJ_DeltoolStrip;
        private YtWinContrl.com.datagrid.DataGView dataGView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn FJ_CardIdCloumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn FJ_RowNoColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewComboBoxColumn FJ_unitColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn FJ_NUMColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn FJ_PriceColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn FJ_MoneyColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn FJ_Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label JinEHeJi;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label TiaoSu;
        private System.Windows.Forms.Label label116;
        private YtWinContrl.com.datagrid.DataGView dataGView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn JL_CardIdColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn JL_RowNOColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private YtWinContrl.com.datagrid.CalendarColumn JL_CheckdateColumn;
        private YtWinContrl.com.datagrid.CalendarColumn JL_CheckDate_Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn JL_StatusColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
    }
}