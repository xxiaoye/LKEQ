﻿namespace EQWareManag.form
{
    partial class EQIn_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EQIn_Add));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.add_toolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fromplan_toolStripButton = new System.Windows.Forms.ToolStripButton();
            this.DeleButton = new System.Windows.Forms.ToolStripButton();
            this.save_toolStripButton = new System.Windows.Forms.ToolStripButton();
            this.cancel_toolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_Pass = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_Down = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.fpcode_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.SHDH_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.InWay_selTextInpt = new YtWinContrl.com.contrl.SelTextInpt();
            this.InWare_selTextInpt = new YtWinContrl.com.contrl.SelTextInpt();
            this.gys_selTextInpt = new YtWinContrl.com.contrl.SelTextInpt();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.memo_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.totalmoney_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.lstotalmoney_yTextBox = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_YzfMoney = new YtWinContrl.com.contrl.YTextBox();
            this.yTextBox_CGpeople = new YtWinContrl.com.contrl.YTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.yTextBox1 = new YtWinContrl.com.contrl.YTextBox();
            this.dataGView1 = new YtWinContrl.com.datagrid.DataGView();
            this.eq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.price0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.money = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lsprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yzf = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lsmoney = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cbdj = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supply = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplyid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productdate = new YtWinContrl.com.datagrid.CalendarColumn();
            this.validate = new YtWinContrl.com.datagrid.CalendarColumn();
            this.memo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eqid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ph = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.add_toolStripButton,
            this.fromplan_toolStripButton,
            this.DeleButton,
            this.save_toolStripButton,
            this.cancel_toolStripButton,
            this.toolStripButton_Pass,
            this.toolStripButton_Down,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(904, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // add_toolStripButton
            // 
            this.add_toolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("add_toolStripButton.Image")));
            this.add_toolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.add_toolStripButton.Name = "add_toolStripButton";
            this.add_toolStripButton.Size = new System.Drawing.Size(121, 22);
            this.add_toolStripButton.Text = "手工添加入库设备";
            this.add_toolStripButton.Click += new System.EventHandler(this.add_toolStripButton_Click);
            // 
            // fromplan_toolStripButton
            // 
            this.fromplan_toolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("fromplan_toolStripButton.Image")));
            this.fromplan_toolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.fromplan_toolStripButton.Name = "fromplan_toolStripButton";
            this.fromplan_toolStripButton.Size = new System.Drawing.Size(109, 22);
            this.fromplan_toolStripButton.Text = "从采购计划生成";
            this.fromplan_toolStripButton.Click += new System.EventHandler(this.fromplan_toolStripButton_Click);
            // 
            // DeleButton
            // 
            this.DeleButton.Image = ((System.Drawing.Image)(resources.GetObject("DeleButton.Image")));
            this.DeleButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.DeleButton.Name = "DeleButton";
            this.DeleButton.Size = new System.Drawing.Size(97, 22);
            this.DeleButton.Text = "删除入库设备";
            this.DeleButton.Click += new System.EventHandler(this.DeleButton_Click);
            // 
            // save_toolStripButton
            // 
            this.save_toolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("save_toolStripButton.Image")));
            this.save_toolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.save_toolStripButton.Name = "save_toolStripButton";
            this.save_toolStripButton.Size = new System.Drawing.Size(85, 22);
            this.save_toolStripButton.Text = "保存入库单";
            this.save_toolStripButton.Click += new System.EventHandler(this.save_toolStripButton_Click);
            // 
            // cancel_toolStripButton
            // 
            this.cancel_toolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cancel_toolStripButton.Image")));
            this.cancel_toolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cancel_toolStripButton.Name = "cancel_toolStripButton";
            this.cancel_toolStripButton.Size = new System.Drawing.Size(49, 22);
            this.cancel_toolStripButton.Text = "取消";
            this.cancel_toolStripButton.Click += new System.EventHandler(this.cancel_toolStripButton_Click);
            // 
            // toolStripButton_Pass
            // 
            this.toolStripButton_Pass.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_Pass.Image")));
            this.toolStripButton_Pass.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Pass.Name = "toolStripButton_Pass";
            this.toolStripButton_Pass.Size = new System.Drawing.Size(73, 22);
            this.toolStripButton_Pass.Text = "审核通过";
            this.toolStripButton_Pass.Click += new System.EventHandler(this.toolStripButton_Pass_Click);
            // 
            // toolStripButton_Down
            // 
            this.toolStripButton_Down.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_Down.Image")));
            this.toolStripButton_Down.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Down.Name = "toolStripButton_Down";
            this.toolStripButton_Down.Size = new System.Drawing.Size(85, 22);
            this.toolStripButton_Down.Text = "审核不通过";
            this.toolStripButton_Down.Click += new System.EventHandler(this.toolStripButton_Down_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(67, 22);
            this.toolStripButton1.Text = "打印(&P)";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // fpcode_yTextBox
            // 
            // 
            // 
            // 
            this.fpcode_yTextBox.Border.Class = "TextBoxBorder";
            this.fpcode_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.fpcode_yTextBox.Location = new System.Drawing.Point(447, 52);
            this.fpcode_yTextBox.Name = "fpcode_yTextBox";
            this.fpcode_yTextBox.Size = new System.Drawing.Size(135, 21);
            this.fpcode_yTextBox.TabIndex = 4;
            // 
            // SHDH_yTextBox
            // 
            // 
            // 
            // 
            this.SHDH_yTextBox.Border.Class = "TextBoxBorder";
            this.SHDH_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.SHDH_yTextBox.Location = new System.Drawing.Point(118, 53);
            this.SHDH_yTextBox.Name = "SHDH_yTextBox";
            this.SHDH_yTextBox.Size = new System.Drawing.Size(135, 21);
            this.SHDH_yTextBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(23, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "入库方式";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(352, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "入库库房";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "随货单号";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "备注";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(356, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "发票号码";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(641, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "发票日期";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(641, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "供货商名称";
            // 
            // InWay_selTextInpt
            // 
            this.InWay_selTextInpt.ColDefText = null;
            this.InWay_selTextInpt.ColStyle = null;
            this.InWay_selTextInpt.DataType = null;
            this.InWay_selTextInpt.DbConn = null;
            this.InWay_selTextInpt.Location = new System.Drawing.Point(118, 23);
            this.InWay_selTextInpt.Name = "InWay_selTextInpt";
            this.InWay_selTextInpt.NextFocusControl = null;
            this.InWay_selTextInpt.ReadOnly = false;
            this.InWay_selTextInpt.SelParam = null;
            this.InWay_selTextInpt.ShowColNum = 0;
            this.InWay_selTextInpt.ShowWidth = 0;
            this.InWay_selTextInpt.Size = new System.Drawing.Size(135, 22);
            this.InWay_selTextInpt.Sql = null;
            this.InWay_selTextInpt.SqlStr = null;
            this.InWay_selTextInpt.TabIndex = 0;
            this.InWay_selTextInpt.TvColName = null;
            this.InWay_selTextInpt.Value = null;
            this.InWay_selTextInpt.WatermarkText = "";
            // 
            // InWare_selTextInpt
            // 
            this.InWare_selTextInpt.ColDefText = null;
            this.InWare_selTextInpt.ColStyle = null;
            this.InWare_selTextInpt.DataType = null;
            this.InWare_selTextInpt.DbConn = null;
            this.InWare_selTextInpt.Location = new System.Drawing.Point(448, 22);
            this.InWare_selTextInpt.Name = "InWare_selTextInpt";
            this.InWare_selTextInpt.NextFocusControl = null;
            this.InWare_selTextInpt.ReadOnly = false;
            this.InWare_selTextInpt.SelParam = null;
            this.InWare_selTextInpt.ShowColNum = 0;
            this.InWare_selTextInpt.ShowWidth = 0;
            this.InWare_selTextInpt.Size = new System.Drawing.Size(135, 22);
            this.InWare_selTextInpt.Sql = null;
            this.InWare_selTextInpt.SqlStr = null;
            this.InWare_selTextInpt.TabIndex = 1;
            this.InWare_selTextInpt.TvColName = null;
            this.InWare_selTextInpt.Value = null;
            this.InWare_selTextInpt.WatermarkText = "";
            // 
            // gys_selTextInpt
            // 
            this.gys_selTextInpt.ColDefText = null;
            this.gys_selTextInpt.ColStyle = null;
            this.gys_selTextInpt.DataType = null;
            this.gys_selTextInpt.DbConn = null;
            this.gys_selTextInpt.Location = new System.Drawing.Point(730, 20);
            this.gys_selTextInpt.Name = "gys_selTextInpt";
            this.gys_selTextInpt.NextFocusControl = null;
            this.gys_selTextInpt.ReadOnly = false;
            this.gys_selTextInpt.SelParam = null;
            this.gys_selTextInpt.ShowColNum = 0;
            this.gys_selTextInpt.ShowWidth = 0;
            this.gys_selTextInpt.Size = new System.Drawing.Size(135, 22);
            this.gys_selTextInpt.Sql = null;
            this.gys_selTextInpt.SqlStr = null;
            this.gys_selTextInpt.TabIndex = 2;
            this.gys_selTextInpt.TvColName = null;
            this.gys_selTextInpt.Value = null;
            this.gys_selTextInpt.WatermarkText = "";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(730, 53);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(138, 21);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // memo_yTextBox
            // 
            // 
            // 
            // 
            this.memo_yTextBox.Border.Class = "TextBoxBorder";
            this.memo_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.memo_yTextBox.Location = new System.Drawing.Point(118, 148);
            this.memo_yTextBox.Name = "memo_yTextBox";
            this.memo_yTextBox.Size = new System.Drawing.Size(750, 21);
            this.memo_yTextBox.TabIndex = 11;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.memo_yTextBox);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.gys_selTextInpt);
            this.groupBox1.Controls.Add(this.InWare_selTextInpt);
            this.groupBox1.Controls.Add(this.InWay_selTextInpt);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.SHDH_yTextBox);
            this.groupBox1.Controls.Add(this.fpcode_yTextBox);
            this.groupBox1.Controls.Add(this.totalmoney_yTextBox);
            this.groupBox1.Controls.Add(this.lstotalmoney_yTextBox);
            this.groupBox1.Controls.Add(this.yTextBox_YzfMoney);
            this.groupBox1.Controls.Add(this.yTextBox_CGpeople);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(904, 182);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "基本信息";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(265, 88);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 12);
            this.label14.TabIndex = 75;
            this.label14.Text = "共：0条";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 125);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 7;
            this.label13.Text = "采购人";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(448, 116);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(138, 21);
            this.dateTimePicker2.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(360, 123);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 5;
            this.label12.Text = "制单日期";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(361, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "发票金额";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(641, 91);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "运杂费金额";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(33, 91);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "总金额";
            // 
            // totalmoney_yTextBox
            // 
            // 
            // 
            // 
            this.totalmoney_yTextBox.Border.Class = "TextBoxBorder";
            this.totalmoney_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.totalmoney_yTextBox.Location = new System.Drawing.Point(118, 84);
            this.totalmoney_yTextBox.Name = "totalmoney_yTextBox";
            this.totalmoney_yTextBox.ReadOnly = true;
            this.totalmoney_yTextBox.Size = new System.Drawing.Size(135, 21);
            this.totalmoney_yTextBox.TabIndex = 6;
            // 
            // lstotalmoney_yTextBox
            // 
            // 
            // 
            // 
            this.lstotalmoney_yTextBox.Border.Class = "TextBoxBorder";
            this.lstotalmoney_yTextBox.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.lstotalmoney_yTextBox.Location = new System.Drawing.Point(448, 83);
            this.lstotalmoney_yTextBox.Name = "lstotalmoney_yTextBox";
            this.lstotalmoney_yTextBox.ReadOnly = true;
            this.lstotalmoney_yTextBox.Size = new System.Drawing.Size(135, 21);
            this.lstotalmoney_yTextBox.TabIndex = 7;
            // 
            // yTextBox_YzfMoney
            // 
            // 
            // 
            // 
            this.yTextBox_YzfMoney.Border.Class = "TextBoxBorder";
            this.yTextBox_YzfMoney.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_YzfMoney.Location = new System.Drawing.Point(732, 86);
            this.yTextBox_YzfMoney.Name = "totalmoney_yTextBox";
            this.yTextBox_YzfMoney.ReadOnly = true;
            this.yTextBox_YzfMoney.Size = new System.Drawing.Size(135, 21);
            this.yTextBox_YzfMoney.TabIndex = 8;
            // 
            // yTextBox_CGpeople
            // 
            // 
            // 
            // 
            this.yTextBox_CGpeople.Border.Class = "TextBoxBorder";
            this.yTextBox_CGpeople.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox_CGpeople.Location = new System.Drawing.Point(118, 117);
            this.yTextBox_CGpeople.Name = "SHDH_yTextBox";
            this.yTextBox_CGpeople.Size = new System.Drawing.Size(135, 21);
            this.yTextBox_CGpeople.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 247);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "总金额";
            // 
            // yTextBox1
            // 
            // 
            // 
            // 
            this.yTextBox1.Border.Class = "TextBoxBorder";
            this.yTextBox1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.yTextBox1.Location = new System.Drawing.Point(0, 0);
            this.yTextBox1.Name = "yTextBox1";
            this.yTextBox1.Size = new System.Drawing.Size(100, 21);
            this.yTextBox1.TabIndex = 0;
            // 
            // dataGView1
            // 
            this.dataGView1.AllowUserToAddRows = false;
            this.dataGView1.AllowUserToDeleteRows = false;
            this.dataGView1.AllowUserToResizeRows = false;
            this.dataGView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGView1.ChangeDataColumName = null;
            this.dataGView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.eq,
            this.price,
            this.Column3,
            this.price0,
            this.money,
            this.num,
            this.lsprice,
            this.yzf,
            this.lsmoney,
            this.cbdj,
            this.rate,
            this.supply,
            this.supplyid,
            this.productdate,
            this.validate,
            this.memo,
            this.eqid,
            this.txm,
            this.Column2,
            this.ph,
            this.Column1,
            this.Column4});
            this.dataGView1.DbConn = null;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGView1.DwColIndex = 0;
            this.dataGView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView1.IsEditOnEnter = true;
            this.dataGView1.IsFillForm = true;
            this.dataGView1.IsPage = false;
            this.dataGView1.Key = null;
            this.dataGView1.Location = new System.Drawing.Point(0, 207);
            this.dataGView1.Name = "dataGView1";
            this.dataGView1.RowHeadersWidth = 20;
            this.dataGView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView1.RowTemplate.Height = 23;
            this.dataGView1.Size = new System.Drawing.Size(904, 294);
            this.dataGView1.TabIndex = 6;
            this.dataGView1.TjFmtStr = null;
            this.dataGView1.TjFormat = null;
            this.dataGView1.Url = null;
            this.dataGView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGView1_RowPostPaint);
            // 
            // eq
            // 
            this.eq.DataPropertyName = "EQNAME";
            this.eq.Frozen = true;
            this.eq.HeaderText = "设备";
            this.eq.Name = "eq";
            this.eq.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.eq.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.eq.Width = 33;
            // 
            // price
            // 
            this.price.DataPropertyName = "GG";
            this.price.HeaderText = "规格";
            this.price.Name = "price";
            this.price.ReadOnly = true;
            this.price.Width = 52;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "UNITCODE";
            this.Column3.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Column3.HeaderText = "单位编码";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column3.Width = 76;
            // 
            // price0
            // 
            this.price0.DataPropertyName = "XH";
            this.price0.HeaderText = "型号";
            this.price0.Name = "price0";
            this.price0.ReadOnly = true;
            this.price0.Width = 52;
            // 
            // money
            // 
            this.money.DataPropertyName = "PRODUCTPLACE";
            this.money.HeaderText = "产地";
            this.money.Name = "money";
            this.money.ReadOnly = true;
            this.money.Width = 52;
            // 
            // num
            // 
            this.num.DataPropertyName = "NUM";
            this.num.HeaderText = "数量";
            this.num.Name = "num";
            this.num.Width = 52;
            // 
            // lsprice
            // 
            this.lsprice.DataPropertyName = "PRICE";
            this.lsprice.HeaderText = "发票单价";
            this.lsprice.Name = "lsprice";
            this.lsprice.Width = 76;
            // 
            // yzf
            // 
            this.yzf.DataPropertyName = "OTHERMONEY";
            this.yzf.HeaderText = "运杂费";
            this.yzf.Name = "yzf";
            this.yzf.Width = 64;
            // 
            // lsmoney
            // 
            this.lsmoney.DataPropertyName = "MONEY";
            this.lsmoney.HeaderText = "发票金额";
            this.lsmoney.Name = "lsmoney";
            this.lsmoney.ReadOnly = true;
            this.lsmoney.Width = 76;
            // 
            // cbdj
            // 
            this.cbdj.DataPropertyName = "TOTALPRICE";
            this.cbdj.HeaderText = "成本单价";
            this.cbdj.Name = "cbdj";
            this.cbdj.ReadOnly = true;
            this.cbdj.Width = 76;
            // 
            // rate
            // 
            this.rate.DataPropertyName = "TOTALMONEY";
            this.rate.HeaderText = "成本金额";
            this.rate.Name = "rate";
            this.rate.ReadOnly = true;
            this.rate.Width = 76;
            // 
            // supply
            // 
            this.supply.DataPropertyName = "SUPPLYNAME";
            this.supply.HeaderText = "生产厂家";
            this.supply.Name = "supply";
            this.supply.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.supply.Width = 76;
            // 
            // supplyid
            // 
            this.supplyid.DataPropertyName = "SUPPLYID";
            this.supplyid.HeaderText = "生产厂家ID";
            this.supplyid.Name = "supplyid";
            this.supplyid.ReadOnly = true;
            this.supplyid.Width = 88;
            // 
            // productdate
            // 
            this.productdate.DataPropertyName = "PRODUCTDATE";
            this.productdate.Formt = null;
            this.productdate.HeaderText = "生产日期";
            this.productdate.Name = "productdate";
            this.productdate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.productdate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.productdate.Width = 76;
            // 
            // validate
            // 
            this.validate.DataPropertyName = "VALIDDATE";
            this.validate.Formt = null;
            this.validate.HeaderText = "有效期";
            this.validate.Name = "validate";
            this.validate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.validate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.validate.Width = 64;
            // 
            // memo
            // 
            this.memo.DataPropertyName = "MEMO";
            this.memo.HeaderText = "备注";
            this.memo.Name = "memo";
            this.memo.Width = 52;
            // 
            // eqid
            // 
            this.eqid.DataPropertyName = "EQID";
            this.eqid.HeaderText = "设备ID";
            this.eqid.Name = "eqid";
            this.eqid.ReadOnly = true;
            this.eqid.Visible = false;
            this.eqid.Width = 64;
            // 
            // txm
            // 
            this.txm.DataPropertyName = "TXM";
            this.txm.HeaderText = "条形码";
            this.txm.Name = "txm";
            this.txm.ReadOnly = true;
            this.txm.Width = 64;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "DETAILNO";
            this.Column2.HeaderText = "流水号";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 64;
            // 
            // ph
            // 
            this.ph.DataPropertyName = "CHOSCODE";
            this.ph.HeaderText = "医疗机构编码";
            this.ph.Name = "ph";
            this.ph.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "STOCKFLOWNO";
            this.Column1.HeaderText = "对应的库存流水号";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 124;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "PLANID";
            this.Column4.HeaderText = "采购计划ID";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 88;
            // 
            // EQIn_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 501);
            this.Controls.Add(this.dataGView1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "EQIn_Add";
            this.Text = "入库单信息";
            this.Load += new System.EventHandler(this.EQIn_Add_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton add_toolStripButton;
        private System.Windows.Forms.ToolStripButton DeleButton;
        private System.Windows.Forms.ToolStripButton save_toolStripButton;
        private YtWinContrl.com.contrl.YTextBox fpcode_yTextBox;
        private YtWinContrl.com.contrl.YTextBox SHDH_yTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private YtWinContrl.com.contrl.SelTextInpt InWay_selTextInpt;
        private YtWinContrl.com.contrl.SelTextInpt InWare_selTextInpt;
        private YtWinContrl.com.contrl.SelTextInpt gys_selTextInpt;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private YtWinContrl.com.contrl.YTextBox memo_yTextBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private YtWinContrl.com.contrl.YTextBox totalmoney_yTextBox;
        private System.Windows.Forms.Label label10;
        private YtWinContrl.com.contrl.YTextBox yTextBox1;
        private YtWinContrl.com.contrl.YTextBox lstotalmoney_yTextBox;
        private System.Windows.Forms.ToolStripButton cancel_toolStripButton;
        private YtWinContrl.com.datagrid.DataGView dataGView1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label12;
        private YtWinContrl.com.contrl.YTextBox yTextBox_YzfMoney;
        private System.Windows.Forms.Label label13;
        private YtWinContrl.com.contrl.YTextBox yTextBox_CGpeople;
        private System.Windows.Forms.ToolStripButton fromplan_toolStripButton;
        private System.Windows.Forms.ToolStripButton toolStripButton_Pass;
        private System.Windows.Forms.ToolStripButton toolStripButton_Down;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.DataGridViewTextBoxColumn eq;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn price0;
        private System.Windows.Forms.DataGridViewTextBoxColumn money;
        private System.Windows.Forms.DataGridViewTextBoxColumn num;
        private System.Windows.Forms.DataGridViewTextBoxColumn lsprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn yzf;
        private System.Windows.Forms.DataGridViewTextBoxColumn lsmoney;
        private System.Windows.Forms.DataGridViewTextBoxColumn cbdj;
        private System.Windows.Forms.DataGridViewTextBoxColumn rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn supply;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplyid;
        private YtWinContrl.com.datagrid.CalendarColumn productdate;
        private YtWinContrl.com.datagrid.CalendarColumn validate;
        private System.Windows.Forms.DataGridViewTextBoxColumn memo;
        private System.Windows.Forms.DataGridViewTextBoxColumn eqid;
        private System.Windows.Forms.DataGridViewTextBoxColumn txm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ph;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;

    }
}