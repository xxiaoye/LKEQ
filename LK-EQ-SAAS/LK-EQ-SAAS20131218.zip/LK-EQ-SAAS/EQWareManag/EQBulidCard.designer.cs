﻿namespace EQWareManag
{
    partial class EQBulidCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EQBulidCard));
            YtWinContrl.com.datagrid.TvList tvList4 = new YtWinContrl.com.datagrid.TvList();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("所有设备类别");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("所有使用状态");
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Add_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.Edit_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.QiYong_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.View_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.Del_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.refresh_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.button1 = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.selTextInpt1 = new YtWinContrl.com.contrl.SelTextInpt();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ytComboBox1 = new YtWinContrl.com.contrl.YtComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.EQKind_tab = new System.Windows.Forms.TabPage();
            this.EQKind_ytTreeView = new YtWinContrl.com.YtTreeView();
            this.UseStatus_tab = new System.Windows.Forms.TabPage();
            this.UseStatus_ytTreeView = new YtWinContrl.com.YtTreeView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGView1 = new YtWinContrl.com.datagrid.DataGView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status_Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Statuscode_Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Deptid_Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.JinEHeJi = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.TiaoSu = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.EQKind_tab.SuspendLayout();
            this.UseStatus_tab.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Add_toolStrip,
            this.Edit_toolStrip,
            this.QiYong_toolStrip,
            this.View_toolStrip,
            this.Del_toolStrip,
            this.refresh_toolStrip});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(875, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Add_toolStrip
            // 
            this.Add_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Add_toolStrip.Image")));
            this.Add_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Add_toolStrip.Name = "Add_toolStrip";
            this.Add_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Add_toolStrip.Text = "新增";
            this.Add_toolStrip.Click += new System.EventHandler(this.Add_toolStrip_Click);
            // 
            // Edit_toolStrip
            // 
            this.Edit_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Edit_toolStrip.Image")));
            this.Edit_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Edit_toolStrip.Name = "Edit_toolStrip";
            this.Edit_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Edit_toolStrip.Text = "编辑";
            this.Edit_toolStrip.Click += new System.EventHandler(this.Edit_toolStrip_Click);
            // 
            // QiYong_toolStrip
            // 
            this.QiYong_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("QiYong_toolStrip.Image")));
            this.QiYong_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.QiYong_toolStrip.Name = "QiYong_toolStrip";
            this.QiYong_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.QiYong_toolStrip.Text = "启用";
            this.QiYong_toolStrip.Click += new System.EventHandler(this.QiYong_toolStrip_Click);
            // 
            // View_toolStrip
            // 
            this.View_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("View_toolStrip.Image")));
            this.View_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.View_toolStrip.Name = "View_toolStrip";
            this.View_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.View_toolStrip.Text = "浏览";
            this.View_toolStrip.Click += new System.EventHandler(this.View_toolStrip_Click);
            // 
            // Del_toolStrip
            // 
            this.Del_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Del_toolStrip.Image")));
            this.Del_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Del_toolStrip.Name = "Del_toolStrip";
            this.Del_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Del_toolStrip.Text = "删除";
            this.Del_toolStrip.Click += new System.EventHandler(this.Del_toolStrip_Click);
            // 
            // refresh_toolStrip
            // 
            this.refresh_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("refresh_toolStrip.Image")));
            this.refresh_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.refresh_toolStrip.Name = "refresh_toolStrip";
            this.refresh_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.refresh_toolStrip.Text = "刷新";
            this.refresh_toolStrip.Click += new System.EventHandler(this.refresh_toolStrip_Click);
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(758, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "查询";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "CheckGreen.bmp");
            this.imageList1.Images.SetKeyName(1, "CheckRed.bmp");
            // 
            // selTextInpt1
            // 
            this.selTextInpt1.ColDefText = null;
            this.selTextInpt1.ColStyle = null;
            this.selTextInpt1.DataType = null;
            this.selTextInpt1.DbConn = null;
            this.selTextInpt1.Location = new System.Drawing.Point(203, 15);
            this.selTextInpt1.Name = "selTextInpt1";
            this.selTextInpt1.NextFocusControl = null;
            this.selTextInpt1.ReadOnly = false;
            this.selTextInpt1.SelParam = null;
            this.selTextInpt1.ShowColNum = 0;
            this.selTextInpt1.ShowWidth = 0;
            this.selTextInpt1.Size = new System.Drawing.Size(137, 22);
            this.selTextInpt1.Sql = null;
            this.selTextInpt1.SqlStr = null;
            this.selTextInpt1.TabIndex = 0;
            this.selTextInpt1.TvColName = null;
            this.selTextInpt1.Value = null;
            this.selTextInpt1.WatermarkText = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(121, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "科室";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.selTextInpt1);
            this.groupBox2.Controls.Add(this.ytComboBox1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(875, 48);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "过滤条件";
            // 
            // ytComboBox1
            // 
            this.ytComboBox1.CacheKey = null;
            this.ytComboBox1.DbConn = null;
            this.ytComboBox1.DefText = null;
            this.ytComboBox1.DefValue = null;
            this.ytComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ytComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ytComboBox1.EnableEmpty = true;
            this.ytComboBox1.FirstText = null;
            this.ytComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ytComboBox1.Fomart = null;
            this.ytComboBox1.ItemStr = "";
            this.ytComboBox1.Location = new System.Drawing.Point(523, 15);
            this.ytComboBox1.Name = "ytComboBox1";
            this.ytComboBox1.Param = null;
            this.ytComboBox1.Size = new System.Drawing.Size(150, 22);
            this.ytComboBox1.Sql = null;
            this.ytComboBox1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ytComboBox1.TabIndex = 1;
            this.ytComboBox1.Tag = tvList4;
            this.ytComboBox1.Value = null;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(419, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "状态过滤";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.EQKind_tab);
            this.tabControl1.Controls.Add(this.UseStatus_tab);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ItemSize = new System.Drawing.Size(95, 17);
            this.tabControl1.Location = new System.Drawing.Point(3, 17);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(194, 406);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 4;
            // 
            // EQKind_tab
            // 
            this.EQKind_tab.Controls.Add(this.EQKind_ytTreeView);
            this.EQKind_tab.Location = new System.Drawing.Point(4, 21);
            this.EQKind_tab.Name = "EQKind_tab";
            this.EQKind_tab.Padding = new System.Windows.Forms.Padding(3);
            this.EQKind_tab.Size = new System.Drawing.Size(186, 381);
            this.EQKind_tab.TabIndex = 0;
            this.EQKind_tab.Text = "设备类别";
            this.EQKind_tab.UseVisualStyleBackColor = true;
            // 
            // EQKind_ytTreeView
            // 
            this.EQKind_ytTreeView.DbConn = null;
            this.EQKind_ytTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EQKind_ytTreeView.HideSelection = false;
            this.EQKind_ytTreeView.ImageIndex = 0;
            this.EQKind_ytTreeView.ImageList = this.imageList1;
            this.EQKind_ytTreeView.LoadHaveData = false;
            this.EQKind_ytTreeView.Location = new System.Drawing.Point(3, 3);
            this.EQKind_ytTreeView.Name = "EQKind_ytTreeView";
            treeNode1.Name = "节点0";
            treeNode1.Text = "所有设备类别";
            this.EQKind_ytTreeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
            this.EQKind_ytTreeView.NoNodeTag = null;
            this.EQKind_ytTreeView.SelectedImageIndex = 1;
            this.EQKind_ytTreeView.Size = new System.Drawing.Size(180, 375);
            this.EQKind_ytTreeView.TabIndex = 2;
            this.EQKind_ytTreeView.TabStop = false;
            // 
            // UseStatus_tab
            // 
            this.UseStatus_tab.Controls.Add(this.UseStatus_ytTreeView);
            this.UseStatus_tab.Location = new System.Drawing.Point(4, 21);
            this.UseStatus_tab.Name = "UseStatus_tab";
            this.UseStatus_tab.Padding = new System.Windows.Forms.Padding(3);
            this.UseStatus_tab.Size = new System.Drawing.Size(186, 381);
            this.UseStatus_tab.TabIndex = 1;
            this.UseStatus_tab.Text = "使用状态";
            this.UseStatus_tab.UseVisualStyleBackColor = true;
            // 
            // UseStatus_ytTreeView
            // 
            this.UseStatus_ytTreeView.DbConn = null;
            this.UseStatus_ytTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.UseStatus_ytTreeView.HideSelection = false;
            this.UseStatus_ytTreeView.ImageIndex = 0;
            this.UseStatus_ytTreeView.ImageList = this.imageList1;
            this.UseStatus_ytTreeView.LoadHaveData = false;
            this.UseStatus_ytTreeView.Location = new System.Drawing.Point(3, 3);
            this.UseStatus_ytTreeView.Name = "UseStatus_ytTreeView";
            treeNode2.Name = "节点0";
            treeNode2.Text = "所有使用状态";
            this.UseStatus_ytTreeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode2});
            this.UseStatus_ytTreeView.NoNodeTag = null;
            this.UseStatus_ytTreeView.SelectedImageIndex = 1;
            this.UseStatus_ytTreeView.Size = new System.Drawing.Size(180, 375);
            this.UseStatus_ytTreeView.TabIndex = 4;
            this.UseStatus_ytTreeView.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox1.Location = new System.Drawing.Point(0, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 426);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "列表查询条件";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dataGView1);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(200, 73);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(675, 426);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "卡片主表信息";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.JinEHeJi);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.TiaoSu);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox4.Location = new System.Drawing.Point(3, 387);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(669, 36);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            // 
            // dataGView1
            // 
            this.dataGView1.AllowUserToAddRows = false;
            this.dataGView1.AllowUserToDeleteRows = false;
            this.dataGView1.AllowUserToResizeRows = false;
            this.dataGView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGView1.ChangeDataColumName = null;
            this.dataGView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column9,
            this.Status_Column,
            this.Statuscode_Column,
            this.Deptid_Column,
            this.Column7,
            this.Column8,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21,
            this.Column23,
            this.Column24,
            this.Column25,
            this.Column26,
            this.Column27,
            this.Column28,
            this.Column29,
            this.Column30,
            this.Column31,
            this.Column32,
            this.Column33,
            this.Column34,
            this.Column35,
            this.Column36,
            this.Column37,
            this.Column38,
            this.Column40,
            this.Column42,
            this.Column43,
            this.Column44,
            this.Column45,
            this.Column46,
            this.Column47,
            this.Column48});
            this.dataGView1.DbConn = null;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGView1.DwColIndex = 0;
            this.dataGView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView1.IsEditOnEnter = true;
            this.dataGView1.IsFillForm = true;
            this.dataGView1.IsPage = false;
            this.dataGView1.Key = null;
            this.dataGView1.Location = new System.Drawing.Point(3, 17);
            this.dataGView1.MultiSelect = false;
            this.dataGView1.Name = "dataGView1";
            this.dataGView1.ReadOnly = true;
            this.dataGView1.RowHeadersWidth = 20;
            this.dataGView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView1.RowTemplate.Height = 23;
            this.dataGView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView1.Size = new System.Drawing.Size(669, 370);
            this.dataGView1.TabIndex = 5;
            this.dataGView1.TjFmtStr = null;
            this.dataGView1.TjFormat = null;
            this.dataGView1.Url = null;
            this.dataGView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGView1_CellDoubleClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "CARDID";
            this.Column1.HeaderText = "卡片ID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 66;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "CARDCODE";
            this.Column2.HeaderText = "卡号";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 54;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "STOCKFLOWNO";
            this.Column3.HeaderText = "库存流水号";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 90;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "STOCKID";
            this.Column4.HeaderText = "库存ID";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 66;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "EQID";
            this.Column5.HeaderText = "设备ID";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 66;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "EQNAME";
            this.Column6.HeaderText = "设备名称";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 78;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "EQNUM";
            this.Column9.HeaderText = "设备数量";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 78;
            // 
            // Status_Column
            // 
            this.Status_Column.DataPropertyName = "STATUS";
            this.Status_Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Status_Column.HeaderText = "状态";
            this.Status_Column.Name = "Status_Column";
            this.Status_Column.ReadOnly = true;
            this.Status_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Status_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Status_Column.Width = 54;
            // 
            // Statuscode_Column
            // 
            this.Statuscode_Column.DataPropertyName = "STATUSCODE";
            this.Statuscode_Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Statuscode_Column.HeaderText = "使用状态";
            this.Statuscode_Column.Name = "Statuscode_Column";
            this.Statuscode_Column.ReadOnly = true;
            this.Statuscode_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Statuscode_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Statuscode_Column.Width = 78;
            // 
            // Deptid_Column
            // 
            this.Deptid_Column.DataPropertyName = "DEPTID";
            this.Deptid_Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Deptid_Column.HeaderText = "使用科室ID";
            this.Deptid_Column.Name = "Deptid_Column";
            this.Deptid_Column.ReadOnly = true;
            this.Deptid_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Deptid_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Deptid_Column.Width = 90;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "COUNTRY";
            this.Column7.HeaderText = "国别";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 54;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "CONTRACTCODE";
            this.Column8.HeaderText = "合同号";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 66;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "PRICE";
            this.Column10.HeaderText = "价格";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 54;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "YPRICE";
            this.Column11.HeaderText = "原值";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 54;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "FARE";
            this.Column12.HeaderText = "收费标准";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 78;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "DGDATE";
            this.Column13.HeaderText = "订购时间";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Width = 78;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "CCDATE";
            this.Column14.HeaderText = "出厂时间";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Width = 78;
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "LYPEOPLE";
            this.Column15.HeaderText = "领用人";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Width = 66;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "LYDATE";
            this.Column16.HeaderText = "领用时间";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.Width = 78;
            // 
            // Column17
            // 
            this.Column17.DataPropertyName = "SETUPDATE";
            this.Column17.HeaderText = "安装时间";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.Width = 78;
            // 
            // Column18
            // 
            this.Column18.DataPropertyName = "SETUPPEOPLE";
            this.Column18.HeaderText = "安装人";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            this.Column18.Width = 66;
            // 
            // Column19
            // 
            this.Column19.DataPropertyName = "CCCODE";
            this.Column19.HeaderText = "出厂号";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            this.Column19.Width = 66;
            // 
            // Column20
            // 
            this.Column20.DataPropertyName = "USEYEAR";
            this.Column20.HeaderText = "使用年限";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.Width = 78;
            // 
            // Column21
            // 
            this.Column21.DataPropertyName = "USEDYEAR";
            this.Column21.HeaderText = "已使用年限";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.Width = 90;
            // 
            // Column23
            // 
            this.Column23.DataPropertyName = "TOTALWORK";
            this.Column23.HeaderText = "总工作量";
            this.Column23.Name = "Column23";
            this.Column23.ReadOnly = true;
            this.Column23.Width = 78;
            // 
            // Column24
            // 
            this.Column24.DataPropertyName = "TOTALEDWORK";
            this.Column24.HeaderText = "累计工作量";
            this.Column24.Name = "Column24";
            this.Column24.ReadOnly = true;
            this.Column24.Width = 90;
            // 
            // Column25
            // 
            this.Column25.DataPropertyName = "TOTALZJ";
            this.Column25.HeaderText = "累计折旧";
            this.Column25.Name = "Column25";
            this.Column25.ReadOnly = true;
            this.Column25.Width = 78;
            // 
            // Column26
            // 
            this.Column26.DataPropertyName = "CZRATE";
            this.Column26.HeaderText = "残值率";
            this.Column26.Name = "Column26";
            this.Column26.ReadOnly = true;
            this.Column26.Width = 66;
            // 
            // Column27
            // 
            this.Column27.DataPropertyName = "MAINUSE";
            this.Column27.HeaderText = "主要用途";
            this.Column27.Name = "Column27";
            this.Column27.ReadOnly = true;
            this.Column27.Width = 78;
            // 
            // Column28
            // 
            this.Column28.DataPropertyName = "YSREC";
            this.Column28.HeaderText = "验收记录";
            this.Column28.Name = "Column28";
            this.Column28.ReadOnly = true;
            this.Column28.Width = 78;
            // 
            // Column29
            // 
            this.Column29.DataPropertyName = "YSPEOPLE";
            this.Column29.HeaderText = "验收人员";
            this.Column29.Name = "Column29";
            this.Column29.ReadOnly = true;
            this.Column29.Width = 78;
            // 
            // Column30
            // 
            this.Column30.DataPropertyName = "QUATHING";
            this.Column30.HeaderText = "质量情况";
            this.Column30.Name = "Column30";
            this.Column30.ReadOnly = true;
            this.Column30.Width = 78;
            // 
            // Column31
            // 
            this.Column31.DataPropertyName = "BGPEOPLE";
            this.Column31.HeaderText = "保管人";
            this.Column31.Name = "Column31";
            this.Column31.ReadOnly = true;
            this.Column31.Width = 66;
            // 
            // Column32
            // 
            this.Column32.DataPropertyName = "MEMO";
            this.Column32.HeaderText = "备注";
            this.Column32.Name = "Column32";
            this.Column32.ReadOnly = true;
            this.Column32.Width = 54;
            // 
            // Column33
            // 
            this.Column33.DataPropertyName = "TXM";
            this.Column33.HeaderText = "条形码";
            this.Column33.Name = "Column33";
            this.Column33.ReadOnly = true;
            this.Column33.Width = 66;
            // 
            // Column34
            // 
            this.Column34.DataPropertyName = "FDVALUE";
            this.Column34.HeaderText = "分度值";
            this.Column34.Name = "Column34";
            this.Column34.ReadOnly = true;
            this.Column34.Width = 66;
            // 
            // Column35
            // 
            this.Column35.DataPropertyName = "JDLEVEL";
            this.Column35.HeaderText = "精度等级";
            this.Column35.Name = "Column35";
            this.Column35.ReadOnly = true;
            this.Column35.Width = 78;
            // 
            // Column36
            // 
            this.Column36.DataPropertyName = "CHECKLEVEL";
            this.Column36.HeaderText = "检定等级";
            this.Column36.Name = "Column36";
            this.Column36.ReadOnly = true;
            this.Column36.Width = 78;
            // 
            // Column37
            // 
            this.Column37.DataPropertyName = "CHECKRANGE";
            this.Column37.HeaderText = "测量范围";
            this.Column37.Name = "Column37";
            this.Column37.ReadOnly = true;
            this.Column37.Width = 78;
            // 
            // Column38
            // 
            this.Column38.DataPropertyName = "CHECKZQ";
            this.Column38.HeaderText = "检定周期";
            this.Column38.Name = "Column38";
            this.Column38.ReadOnly = true;
            this.Column38.Width = 78;
            // 
            // Column40
            // 
            this.Column40.DataPropertyName = "CHOSCODE";
            this.Column40.HeaderText = "医疗机构编码";
            this.Column40.Name = "Column40";
            this.Column40.ReadOnly = true;
            this.Column40.Width = 102;
            // 
            // Column42
            // 
            this.Column42.DataPropertyName = "USERID";
            this.Column42.HeaderText = "操作员ID";
            this.Column42.Name = "Column42";
            this.Column42.ReadOnly = true;
            this.Column42.Width = 78;
            // 
            // Column43
            // 
            this.Column43.DataPropertyName = "USERNAME";
            this.Column43.HeaderText = "操作员姓名";
            this.Column43.Name = "Column43";
            this.Column43.ReadOnly = true;
            this.Column43.Width = 90;
            // 
            // Column44
            // 
            this.Column44.DataPropertyName = "RECDATE";
            this.Column44.HeaderText = "制卡时间";
            this.Column44.Name = "Column44";
            this.Column44.ReadOnly = true;
            this.Column44.Width = 78;
            // 
            // Column45
            // 
            this.Column45.DataPropertyName = "STARTDATE";
            this.Column45.HeaderText = "启用日期";
            this.Column45.Name = "Column45";
            this.Column45.ReadOnly = true;
            this.Column45.Width = 78;
            // 
            // Column46
            // 
            this.Column46.DataPropertyName = "STARTPEOPLE";
            this.Column46.HeaderText = "启用人";
            this.Column46.Name = "Column46";
            this.Column46.ReadOnly = true;
            this.Column46.Width = 66;
            // 
            // Column47
            // 
            this.Column47.DataPropertyName = "BFDATE";
            this.Column47.HeaderText = "报废日期";
            this.Column47.Name = "Column47";
            this.Column47.ReadOnly = true;
            this.Column47.Width = 78;
            // 
            // Column48
            // 
            this.Column48.DataPropertyName = "BFPEOPLE";
            this.Column48.HeaderText = "报废人";
            this.Column48.Name = "Column48";
            this.Column48.ReadOnly = true;
            this.Column48.Width = 66;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(528, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 12);
            this.label6.TabIndex = 45;
            this.label6.Text = "0元";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(438, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 12);
            this.label7.TabIndex = 44;
            this.label7.Text = "总原值合计：";
            // 
            // JinEHeJi
            // 
            this.JinEHeJi.AutoSize = true;
            this.JinEHeJi.Location = new System.Drawing.Point(265, 18);
            this.JinEHeJi.Name = "JinEHeJi";
            this.JinEHeJi.Size = new System.Drawing.Size(23, 12);
            this.JinEHeJi.TabIndex = 41;
            this.JinEHeJi.Text = "0元";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(192, 18);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 12);
            this.label15.TabIndex = 40;
            this.label15.Text = "总价格合计：";
            // 
            // TiaoSu
            // 
            this.TiaoSu.AutoSize = true;
            this.TiaoSu.Location = new System.Drawing.Point(43, 17);
            this.TiaoSu.Name = "TiaoSu";
            this.TiaoSu.Size = new System.Drawing.Size(23, 12);
            this.TiaoSu.TabIndex = 39;
            this.TiaoSu.Text = "0笔";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(18, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 38;
            this.label13.Text = "共：";
            // 
            // EQBulidCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 499);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.toolStrip1);
            this.Name = "EQBulidCard";
            this.Text = "设备建卡管理";
            this.Load += new System.EventHandler(this.EQBulidCard_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.EQKind_tab.ResumeLayout(false);
            this.UseStatus_tab.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton Add_toolStrip;
        private System.Windows.Forms.ToolStripButton Edit_toolStrip;
        private System.Windows.Forms.ToolStripButton Del_toolStrip;
        private System.Windows.Forms.ToolStripButton View_toolStrip;
        private System.Windows.Forms.ToolStripButton refresh_toolStrip;
        private System.Windows.Forms.ToolStripButton QiYong_toolStrip;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.GroupBox groupBox2;
        private YtWinContrl.com.contrl.YtComboBox ytComboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage EQKind_tab;
        private YtWinContrl.com.YtTreeView EQKind_ytTreeView;
        private System.Windows.Forms.TabPage UseStatus_tab;
        private YtWinContrl.com.YtTreeView UseStatus_ytTreeView;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private YtWinContrl.com.datagrid.DataGView dataGView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewComboBoxColumn Status_Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn Statuscode_Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn Deptid_Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column29;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column30;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column31;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column32;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column34;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column35;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column36;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column37;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column38;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column40;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column42;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column43;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column44;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column45;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column46;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column47;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column48;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label JinEHeJi;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label TiaoSu;
        private System.Windows.Forms.Label label13;
    }
}