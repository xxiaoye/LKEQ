﻿namespace EQWareManag
{
    partial class EQLingUse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EQLingUse));
            YtWinContrl.com.datagrid.TvList tvList1 = new YtWinContrl.com.datagrid.TvList();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Add_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.Edit_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.SubmitCheck_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.Submited_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.Chongxiao_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.Del_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.View_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.refresh_toolStrip = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeDuan1 = new YtWinContrl.com.contrl.DateTimeDuan();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.Status_ytComboBox = new YtWinContrl.com.contrl.YtComboBox();
            this.selTextInpt1 = new YtWinContrl.com.contrl.SelTextInpt();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGView2 = new YtWinContrl.com.datagrid.DataGView();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EqIdName_Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Unitcode_Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.JinEHeJi = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.TiaoSu = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.dataGView1 = new YtWinContrl.com.datagrid.DataGView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ware1Cloumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.TargetWarecodeColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opflag_Cloumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.status_Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.outstyle_Column = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ware2Cloumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Add_toolStrip,
            this.Edit_toolStrip,
            this.SubmitCheck_toolStrip,
            this.Submited_toolStrip,
            this.Chongxiao_toolStrip,
            this.Del_toolStrip,
            this.View_toolStrip,
            this.refresh_toolStrip});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1015, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Add_toolStrip
            // 
            this.Add_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Add_toolStrip.Image")));
            this.Add_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Add_toolStrip.Name = "Add_toolStrip";
            this.Add_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Add_toolStrip.Text = "新增";
            this.Add_toolStrip.Click += new System.EventHandler(this.Add_toolStrip_Click);
            // 
            // Edit_toolStrip
            // 
            this.Edit_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Edit_toolStrip.Image")));
            this.Edit_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Edit_toolStrip.Name = "Edit_toolStrip";
            this.Edit_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Edit_toolStrip.Text = "编辑";
            this.Edit_toolStrip.Click += new System.EventHandler(this.Edit_toolStrip_Click);
            // 
            // SubmitCheck_toolStrip
            // 
            this.SubmitCheck_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("SubmitCheck_toolStrip.Image")));
            this.SubmitCheck_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SubmitCheck_toolStrip.Name = "SubmitCheck_toolStrip";
            this.SubmitCheck_toolStrip.Size = new System.Drawing.Size(73, 22);
            this.SubmitCheck_toolStrip.Text = "提交审核";
            this.SubmitCheck_toolStrip.Click += new System.EventHandler(this.SubmitCheck_toolStrip_Click);
            // 
            // Submited_toolStrip
            // 
            this.Submited_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Submited_toolStrip.Image")));
            this.Submited_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Submited_toolStrip.Name = "Submited_toolStrip";
            this.Submited_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Submited_toolStrip.Text = "审核";
            this.Submited_toolStrip.Click += new System.EventHandler(this.Submited_toolStrip_Click);
            // 
            // Chongxiao_toolStrip
            // 
            this.Chongxiao_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Chongxiao_toolStrip.Image")));
            this.Chongxiao_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Chongxiao_toolStrip.Name = "Chongxiao_toolStrip";
            this.Chongxiao_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Chongxiao_toolStrip.Text = "冲销";
            this.Chongxiao_toolStrip.Click += new System.EventHandler(this.Chongxiao_toolStrip_Click);
            // 
            // Del_toolStrip
            // 
            this.Del_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("Del_toolStrip.Image")));
            this.Del_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Del_toolStrip.Name = "Del_toolStrip";
            this.Del_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.Del_toolStrip.Text = "删除";
            this.Del_toolStrip.Click += new System.EventHandler(this.Del_toolStrip_Click);
            // 
            // View_toolStrip
            // 
            this.View_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("View_toolStrip.Image")));
            this.View_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.View_toolStrip.Name = "View_toolStrip";
            this.View_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.View_toolStrip.Text = "浏览";
            this.View_toolStrip.Click += new System.EventHandler(this.View_toolStrip_Click);
            // 
            // refresh_toolStrip
            // 
            this.refresh_toolStrip.Image = ((System.Drawing.Image)(resources.GetObject("refresh_toolStrip.Image")));
            this.refresh_toolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.refresh_toolStrip.Name = "refresh_toolStrip";
            this.refresh_toolStrip.Size = new System.Drawing.Size(49, 22);
            this.refresh_toolStrip.Text = "刷新";
            this.refresh_toolStrip.Click += new System.EventHandler(this.refresh_toolStrip_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.dateTimeDuan1);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.Status_ytComboBox);
            this.groupBox1.Controls.Add(this.selTextInpt1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1015, 59);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "查询条件";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(701, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 42;
            this.label4.Text = "到";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(538, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 12);
            this.label5.TabIndex = 41;
            this.label5.Text = "从";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Checked = false;
            this.dateTimePicker2.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(732, 21);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(127, 21);
            this.dateTimePicker2.TabIndex = 40;
            // 
            // dateTimeDuan1
            // 
            this.dateTimeDuan1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dateTimeDuan1.End = this.dateTimePicker2;
            this.dateTimeDuan1.FormattingEnabled = true;
            this.dateTimeDuan1.Location = new System.Drawing.Point(413, 22);
            this.dateTimeDuan1.Name = "dateTimeDuan1";
            this.dateTimeDuan1.Size = new System.Drawing.Size(108, 20);
            this.dateTimeDuan1.Start = this.dateTimePicker1;
            this.dateTimeDuan1.TabIndex = 38;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Checked = false;
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(562, 21);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(127, 21);
            this.dateTimePicker1.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(366, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 37;
            this.label6.Text = "时间段";
            // 
            // Status_ytComboBox
            // 
            this.Status_ytComboBox.CacheKey = null;
            this.Status_ytComboBox.DbConn = null;
            this.Status_ytComboBox.DefText = null;
            this.Status_ytComboBox.DefValue = null;
            this.Status_ytComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Status_ytComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Status_ytComboBox.EnableEmpty = true;
            this.Status_ytComboBox.FirstText = null;
            this.Status_ytComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Status_ytComboBox.Fomart = null;
            this.Status_ytComboBox.ItemStr = "";
            this.Status_ytComboBox.Location = new System.Drawing.Point(229, 20);
            this.Status_ytComboBox.Name = "Status_ytComboBox";
            this.Status_ytComboBox.Param = null;
            this.Status_ytComboBox.Size = new System.Drawing.Size(100, 22);
            this.Status_ytComboBox.Sql = null;
            this.Status_ytComboBox.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Status_ytComboBox.TabIndex = 2;
            this.Status_ytComboBox.Tag = tvList1;
            this.Status_ytComboBox.Value = null;
            // 
            // selTextInpt1
            // 
            this.selTextInpt1.ColDefText = null;
            this.selTextInpt1.ColStyle = null;
            this.selTextInpt1.DataType = null;
            this.selTextInpt1.DbConn = null;
            this.selTextInpt1.Location = new System.Drawing.Point(75, 20);
            this.selTextInpt1.Name = "selTextInpt1";
            this.selTextInpt1.NextFocusControl = null;
            this.selTextInpt1.ReadOnly = false;
            this.selTextInpt1.SelParam = null;
            this.selTextInpt1.ShowColNum = 0;
            this.selTextInpt1.ShowWidth = 0;
            this.selTextInpt1.Size = new System.Drawing.Size(99, 22);
            this.selTextInpt1.Sql = null;
            this.selTextInpt1.SqlStr = null;
            this.selTextInpt1.TabIndex = 1;
            this.selTextInpt1.TvColName = null;
            this.selTextInpt1.Value = null;
            this.selTextInpt1.WatermarkText = "";
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(894, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "查询";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(187, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "状态";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "出库库房";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGView2);
            this.groupBox2.Location = new System.Drawing.Point(0, 239);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(986, 197);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "设备出库细表";
            this.groupBox2.Visible = false;
            // 
            // dataGView2
            // 
            this.dataGView2.AllowUserToAddRows = false;
            this.dataGView2.AllowUserToDeleteRows = false;
            this.dataGView2.AllowUserToResizeRows = false;
            this.dataGView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGView2.ChangeDataColumName = null;
            this.dataGView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column8,
            this.Column9,
            this.EqIdName_Column,
            this.Unitcode_Column,
            this.Column24,
            this.Column25,
            this.Column26,
            this.Column27,
            this.Column28,
            this.Column29,
            this.Column30,
            this.Column31,
            this.Column32,
            this.Column33,
            this.Column34,
            this.Column35,
            this.Column36,
            this.Column37,
            this.Column40,
            this.Column38,
            this.Column39});
            this.dataGView2.DbConn = null;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView2.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGView2.DwColIndex = 0;
            this.dataGView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView2.IsEditOnEnter = true;
            this.dataGView2.IsFillForm = true;
            this.dataGView2.IsPage = false;
            this.dataGView2.Key = null;
            this.dataGView2.Location = new System.Drawing.Point(12, 20);
            this.dataGView2.MultiSelect = false;
            this.dataGView2.Name = "dataGView2";
            this.dataGView2.ReadOnly = true;
            this.dataGView2.RowHeadersWidth = 15;
            this.dataGView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView2.RowTemplate.Height = 23;
            this.dataGView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView2.Size = new System.Drawing.Size(968, 177);
            this.dataGView2.TabIndex = 0;
            this.dataGView2.TjFmtStr = null;
            this.dataGView2.TjFormat = null;
            this.dataGView2.Url = null;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "DETAILNO";
            this.Column8.HeaderText = "流水号";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 66;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "OUTID";
            this.Column9.HeaderText = "出库ID";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 66;
            // 
            // EqIdName_Column
            // 
            this.EqIdName_Column.DataPropertyName = "EQID";
            this.EqIdName_Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.EqIdName_Column.HeaderText = "设备ID";
            this.EqIdName_Column.Name = "EqIdName_Column";
            this.EqIdName_Column.ReadOnly = true;
            this.EqIdName_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.EqIdName_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.EqIdName_Column.Width = 66;
            // 
            // Unitcode_Column
            // 
            this.Unitcode_Column.DataPropertyName = "UNITCODE";
            this.Unitcode_Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Unitcode_Column.HeaderText = "单位编码";
            this.Unitcode_Column.Name = "Unitcode_Column";
            this.Unitcode_Column.ReadOnly = true;
            this.Unitcode_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Unitcode_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Unitcode_Column.Width = 78;
            // 
            // Column24
            // 
            this.Column24.DataPropertyName = "STOCKFLOWNO";
            this.Column24.HeaderText = "库存流水号";
            this.Column24.Name = "Column24";
            this.Column24.ReadOnly = true;
            this.Column24.Width = 90;
            // 
            // Column25
            // 
            this.Column25.DataPropertyName = "NUM";
            this.Column25.HeaderText = "数量";
            this.Column25.Name = "Column25";
            this.Column25.ReadOnly = true;
            this.Column25.Width = 54;
            // 
            // Column26
            // 
            this.Column26.DataPropertyName = "PRICE";
            this.Column26.HeaderText = "单价";
            this.Column26.Name = "Column26";
            this.Column26.ReadOnly = true;
            this.Column26.Width = 54;
            // 
            // Column27
            // 
            this.Column27.DataPropertyName = "MONEY";
            this.Column27.HeaderText = "金额";
            this.Column27.Name = "Column27";
            this.Column27.ReadOnly = true;
            this.Column27.Width = 54;
            // 
            // Column28
            // 
            this.Column28.DataPropertyName = "OTHERMONEY";
            this.Column28.HeaderText = "运杂费";
            this.Column28.Name = "Column28";
            this.Column28.ReadOnly = true;
            this.Column28.Width = 66;
            // 
            // Column29
            // 
            this.Column29.DataPropertyName = "TOTALPRICE";
            this.Column29.HeaderText = "成本单价";
            this.Column29.Name = "Column29";
            this.Column29.ReadOnly = true;
            this.Column29.Width = 78;
            // 
            // Column30
            // 
            this.Column30.DataPropertyName = "TOTALMONEY";
            this.Column30.HeaderText = "成本金额";
            this.Column30.Name = "Column30";
            this.Column30.ReadOnly = true;
            this.Column30.Width = 78;
            // 
            // Column31
            // 
            this.Column31.DataPropertyName = "GG";
            this.Column31.HeaderText = "规格";
            this.Column31.Name = "Column31";
            this.Column31.ReadOnly = true;
            this.Column31.Width = 54;
            // 
            // Column32
            // 
            this.Column32.DataPropertyName = "XH";
            this.Column32.HeaderText = "型号";
            this.Column32.Name = "Column32";
            this.Column32.ReadOnly = true;
            this.Column32.Width = 54;
            // 
            // Column33
            // 
            this.Column33.DataPropertyName = "CD";
            this.Column33.HeaderText = "产地";
            this.Column33.Name = "Column33";
            this.Column33.ReadOnly = true;
            this.Column33.Width = 54;
            // 
            // Column34
            // 
            this.Column34.DataPropertyName = "TXM";
            this.Column34.HeaderText = "条形码";
            this.Column34.Name = "Column34";
            this.Column34.ReadOnly = true;
            this.Column34.Width = 66;
            // 
            // Column35
            // 
            this.Column35.DataPropertyName = "SUPPLYID";
            this.Column35.HeaderText = "生产厂家ID";
            this.Column35.Name = "Column35";
            this.Column35.ReadOnly = true;
            this.Column35.Width = 90;
            // 
            // Column36
            // 
            this.Column36.DataPropertyName = "SUPPLYNAME";
            this.Column36.HeaderText = "生产厂家名称";
            this.Column36.Name = "Column36";
            this.Column36.ReadOnly = true;
            this.Column36.Width = 102;
            // 
            // Column37
            // 
            this.Column37.DataPropertyName = "PRODUCTDATE";
            this.Column37.HeaderText = "生产日期";
            this.Column37.Name = "Column37";
            this.Column37.ReadOnly = true;
            this.Column37.Width = 78;
            // 
            // Column40
            // 
            this.Column40.DataPropertyName = "VALIDDATE";
            this.Column40.HeaderText = "有效期";
            this.Column40.Name = "Column40";
            this.Column40.ReadOnly = true;
            this.Column40.Width = 66;
            // 
            // Column38
            // 
            this.Column38.DataPropertyName = "CHOSCODE";
            this.Column38.HeaderText = "医疗机构编码";
            this.Column38.Name = "Column38";
            this.Column38.ReadOnly = true;
            this.Column38.Width = 102;
            // 
            // Column39
            // 
            this.Column39.DataPropertyName = "MEMO";
            this.Column39.HeaderText = "备注";
            this.Column39.Name = "Column39";
            this.Column39.ReadOnly = true;
            this.Column39.Width = 54;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.JinEHeJi);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.TiaoSu);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox3.Location = new System.Drawing.Point(0, 558);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1015, 28);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            // 
            // JinEHeJi
            // 
            this.JinEHeJi.AutoSize = true;
            this.JinEHeJi.Location = new System.Drawing.Point(279, 17);
            this.JinEHeJi.Name = "JinEHeJi";
            this.JinEHeJi.Size = new System.Drawing.Size(23, 12);
            this.JinEHeJi.TabIndex = 37;
            this.JinEHeJi.Text = "0元";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(196, 17);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 12);
            this.label15.TabIndex = 36;
            this.label15.Text = "总金额合计：";
            // 
            // TiaoSu
            // 
            this.TiaoSu.AutoSize = true;
            this.TiaoSu.Location = new System.Drawing.Point(108, 17);
            this.TiaoSu.Name = "TiaoSu";
            this.TiaoSu.Size = new System.Drawing.Size(23, 12);
            this.TiaoSu.TabIndex = 35;
            this.TiaoSu.Text = "0笔";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(73, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 34;
            this.label13.Text = "共：";
            // 
            // dataGView1
            // 
            this.dataGView1.AllowUserToAddRows = false;
            this.dataGView1.AllowUserToDeleteRows = false;
            this.dataGView1.AllowUserToResizeRows = false;
            this.dataGView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGView1.ChangeDataColumName = null;
            this.dataGView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column4,
            this.Column3,
            this.ware1Cloumn,
            this.TargetWarecodeColumn,
            this.Column5,
            this.Column6,
            this.opflag_Cloumn,
            this.status_Column,
            this.Column7,
            this.Column10,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21,
            this.Column11,
            this.outstyle_Column,
            this.ware2Cloumn});
            this.dataGView1.DbConn = null;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGView1.DwColIndex = 0;
            this.dataGView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView1.IsEditOnEnter = true;
            this.dataGView1.IsFillForm = true;
            this.dataGView1.IsPage = false;
            this.dataGView1.Key = null;
            this.dataGView1.Location = new System.Drawing.Point(0, 84);
            this.dataGView1.MultiSelect = false;
            this.dataGView1.Name = "dataGView1";
            this.dataGView1.ReadOnly = true;
            this.dataGView1.RowHeadersWidth = 20;
            this.dataGView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView1.RowTemplate.Height = 23;
            this.dataGView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView1.Size = new System.Drawing.Size(1015, 474);
            this.dataGView1.TabIndex = 6;
            this.dataGView1.TjFmtStr = null;
            this.dataGView1.TjFormat = null;
            this.dataGView1.Url = null;
            this.dataGView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGView1_CellDoubleClick);
            this.dataGView1.SelectionChanged += new System.EventHandler(this.dataGView1_SelectionChanged);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "OUTID";
            this.Column1.FillWeight = 268.1992F;
            this.Column1.HeaderText = "出库ID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 66;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "IONAME";
            this.Column4.HeaderText = "出库方式";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 78;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "RECIPECODE";
            this.Column3.FillWeight = 206.1608F;
            this.Column3.HeaderText = "单据号";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 66;
            // 
            // ware1Cloumn
            // 
            this.ware1Cloumn.DataPropertyName = "WARECODE";
            this.ware1Cloumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.ware1Cloumn.FillWeight = 180.9488F;
            this.ware1Cloumn.HeaderText = "出库库房";
            this.ware1Cloumn.Name = "ware1Cloumn";
            this.ware1Cloumn.ReadOnly = true;
            this.ware1Cloumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ware1Cloumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ware1Cloumn.Width = 78;
            // 
            // TargetWarecodeColumn
            // 
            this.TargetWarecodeColumn.DataPropertyName = "TARGETWARECODE";
            this.TargetWarecodeColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.TargetWarecodeColumn.HeaderText = "出库目的库房";
            this.TargetWarecodeColumn.Name = "TargetWarecodeColumn";
            this.TargetWarecodeColumn.ReadOnly = true;
            this.TargetWarecodeColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.TargetWarecodeColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.TargetWarecodeColumn.Width = 102;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "名称";
            this.Column5.HeaderText = "出库目的科室";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 102;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "TOTALMONEY";
            this.Column6.FillWeight = 139.7734F;
            this.Column6.HeaderText = "总金额";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 66;
            // 
            // opflag_Cloumn
            // 
            this.opflag_Cloumn.DataPropertyName = "OPFLAG";
            this.opflag_Cloumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.opflag_Cloumn.HeaderText = "操作标志";
            this.opflag_Cloumn.Name = "opflag_Cloumn";
            this.opflag_Cloumn.ReadOnly = true;
            this.opflag_Cloumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.opflag_Cloumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.opflag_Cloumn.Width = 78;
            // 
            // status_Column
            // 
            this.status_Column.DataPropertyName = "STATUS";
            this.status_Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.status_Column.HeaderText = "状态";
            this.status_Column.Name = "status_Column";
            this.status_Column.ReadOnly = true;
            this.status_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.status_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.status_Column.Width = 54;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "OUTDATE";
            this.Column7.FillWeight = 123.0401F;
            this.Column7.HeaderText = "制单日期";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 78;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "MEMO";
            this.Column10.FillWeight = 84.60555F;
            this.Column10.HeaderText = "备注";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 54;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "CHOSCODE";
            this.Column12.FillWeight = 66.46748F;
            this.Column12.HeaderText = "医疗机构编码";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 102;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "USERID";
            this.Column13.FillWeight = 59.09629F;
            this.Column13.HeaderText = "操作员ID";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Width = 78;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "USERNAME";
            this.Column14.FillWeight = 52.66653F;
            this.Column14.HeaderText = "操作员姓名";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Width = 90;
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "RECDATE";
            this.Column15.FillWeight = 47.05792F;
            this.Column15.HeaderText = "修改时间";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Width = 78;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "SHDATE";
            this.Column16.FillWeight = 42.1656F;
            this.Column16.HeaderText = "审核日期";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.Width = 78;
            // 
            // Column17
            // 
            this.Column17.DataPropertyName = "SHUSERID";
            this.Column17.FillWeight = 37.89811F;
            this.Column17.HeaderText = "审核操作员ID";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.Width = 102;
            // 
            // Column18
            // 
            this.Column18.DataPropertyName = "SHUSERNAME";
            this.Column18.FillWeight = 34.17563F;
            this.Column18.HeaderText = "审核操作员姓名";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            this.Column18.Width = 114;
            // 
            // Column19
            // 
            this.Column19.DataPropertyName = "CXDATE";
            this.Column19.FillWeight = 30.92858F;
            this.Column19.HeaderText = "冲销日期";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            this.Column19.Width = 78;
            // 
            // Column20
            // 
            this.Column20.DataPropertyName = "CXUSERID";
            this.Column20.FillWeight = 28.09621F;
            this.Column20.HeaderText = "冲销操作员ID";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.Width = 102;
            // 
            // Column21
            // 
            this.Column21.DataPropertyName = "CXUSERNAME";
            this.Column21.FillWeight = 25.62557F;
            this.Column21.HeaderText = "冲销操作员姓名";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.Width = 114;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "INID";
            this.Column11.FillWeight = 74.91792F;
            this.Column11.HeaderText = "对应入库ID";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 90;
            // 
            // outstyle_Column
            // 
            this.outstyle_Column.DataPropertyName = "IOID";
            this.outstyle_Column.FillWeight = 235F;
            this.outstyle_Column.HeaderText = "出库方式ID";
            this.outstyle_Column.Name = "outstyle_Column";
            this.outstyle_Column.ReadOnly = true;
            this.outstyle_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.outstyle_Column.Visible = false;
            this.outstyle_Column.Width = 90;
            // 
            // ware2Cloumn
            // 
            this.ware2Cloumn.DataPropertyName = "TARGETDEPTID";
            this.ware2Cloumn.FillWeight = 158.9568F;
            this.ware2Cloumn.HeaderText = "出库目的科室ID";
            this.ware2Cloumn.Name = "ware2Cloumn";
            this.ware2Cloumn.ReadOnly = true;
            this.ware2Cloumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ware2Cloumn.Visible = false;
            this.ware2Cloumn.Width = 114;
            // 
            // EQLingUse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 586);
            this.Controls.Add(this.dataGView1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "EQLingUse";
            this.Text = "设备领用管理";
            this.Load += new System.EventHandler(this.EQLingUse_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton Add_toolStrip;
        private System.Windows.Forms.ToolStripButton Edit_toolStrip;
        private System.Windows.Forms.ToolStripButton SubmitCheck_toolStrip;
        private System.Windows.Forms.ToolStripButton Submited_toolStrip;
        private System.Windows.Forms.ToolStripButton Chongxiao_toolStrip;
        private System.Windows.Forms.ToolStripButton Del_toolStrip;
        private System.Windows.Forms.ToolStripButton View_toolStrip;
        private System.Windows.Forms.ToolStripButton refresh_toolStrip;
        private System.Windows.Forms.GroupBox groupBox1;
        private YtWinContrl.com.contrl.YtComboBox Status_ytComboBox;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private YtWinContrl.com.datagrid.DataGView dataGView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewComboBoxColumn EqIdName_Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn Unitcode_Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column29;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column30;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column31;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column32;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column34;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column35;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column36;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column37;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column40;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column38;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column39;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private YtWinContrl.com.contrl.DateTimeDuan dateTimeDuan1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox3;
        private YtWinContrl.com.datagrid.DataGView dataGView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewComboBoxColumn ware1Cloumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn TargetWarecodeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewComboBoxColumn opflag_Cloumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn status_Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn outstyle_Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn ware2Cloumn;
        private System.Windows.Forms.Label JinEHeJi;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label TiaoSu;
        private System.Windows.Forms.Label label13;

    }
}