﻿namespace StatisticQuery
{
    partial class EQCardQuery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EQCardQuery));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.selTextInpt_KS = new YtWinContrl.com.contrl.SelTextInpt();
            this.label6 = new System.Windows.Forms.Label();
            this.Search_button = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeDuan1 = new YtWinContrl.com.contrl.DateTimeDuan();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.CardFJ_tab = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.CardJLRec_tab = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.CardCC_tab = new System.Windows.Forms.TabPage();
            this.label54 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.CCuseridtextBox = new System.Windows.Forms.TextBox();
            this.CCchosode_textBox = new System.Windows.Forms.TextBox();
            this.CCcardid_textBox = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.CCusername_textBox = new System.Windows.Forms.TextBox();
            this.CCrecdate_textBox = new System.Windows.Forms.TextBox();
            this.CCcc_textBox = new System.Windows.Forms.TextBox();
            this.CCprice_textBox = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.CCbuydate_textBox = new System.Windows.Forms.DateTimePicker();
            this.label49 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.CCnewold_textBox = new System.Windows.Forms.TextBox();
            this.CCsupply_textBox = new System.Windows.Forms.TextBox();
            this.CCcsname_textBox = new System.Windows.Forms.TextBox();
            this.CCother_textBox = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.CardExplain_tab = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.SMexplainNum_textBox = new System.Windows.Forms.TextBox();
            this.SMusrtid_textBox = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SMchoscode_textBox = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.SMboxthing_textBox = new System.Windows.Forms.TextBox();
            this.SMusername_textBox = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.SMteachnum_textBox = new System.Windows.Forms.TextBox();
            this.SMother_textBox = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.SMcertificate_textBox = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.SMcardid_textBox = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.SMext_textBox = new System.Windows.Forms.TextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.TiaoSu = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.dataGView1 = new YtWinContrl.com.datagrid.DataGView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column47 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column53 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dataGView2 = new YtWinContrl.com.datagrid.DataGView();
            this.FJ_CardIdCloumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FJ_RowNoColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FJ_unitColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.FJ_NUMColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FJ_PriceColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FJ_MoneyColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FJ_Status = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGView3 = new YtWinContrl.com.datagrid.DataGView();
            this.JL_CardIdColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JL_RowNOColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JL_CheckdateColumn = new YtWinContrl.com.datagrid.CalendarColumn();
            this.JL_CheckDate_Column = new YtWinContrl.com.datagrid.CalendarColumn();
            this.JL_StatusColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.CardFJ_tab.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.CardJLRec_tab.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.CardCC_tab.SuspendLayout();
            this.CardExplain_tab.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView3)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.selTextInpt_KS);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.Search_button);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.dateTimeDuan1);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(894, 93);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "查询";
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button1.Location = new System.Drawing.Point(449, 58);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 26);
            this.button1.TabIndex = 3;
            this.button1.Text = "  下载图纸文件(&L)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // selTextInpt_KS
            // 
            this.selTextInpt_KS.ColDefText = null;
            this.selTextInpt_KS.ColStyle = null;
            this.selTextInpt_KS.DataType = null;
            this.selTextInpt_KS.DbConn = null;
            this.selTextInpt_KS.Location = new System.Drawing.Point(274, 62);
            this.selTextInpt_KS.Name = "selTextInpt_KS";
            this.selTextInpt_KS.NextFocusControl = null;
            this.selTextInpt_KS.ReadOnly = false;
            this.selTextInpt_KS.SelParam = null;
            this.selTextInpt_KS.ShowColNum = 0;
            this.selTextInpt_KS.ShowWidth = 0;
            this.selTextInpt_KS.Size = new System.Drawing.Size(125, 22);
            this.selTextInpt_KS.Sql = null;
            this.selTextInpt_KS.SqlStr = null;
            this.selTextInpt_KS.TabIndex = 1;
            this.selTextInpt_KS.TvColName = null;
            this.selTextInpt_KS.Value = null;
            this.selTextInpt_KS.WatermarkText = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(228, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 37;
            this.label6.Text = "科室";
            // 
            // Search_button
            // 
            this.Search_button.Image = ((System.Drawing.Image)(resources.GetObject("Search_button.Image")));
            this.Search_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Search_button.Location = new System.Drawing.Point(639, 17);
            this.Search_button.Name = "Search_button";
            this.Search_button.Size = new System.Drawing.Size(82, 26);
            this.Search_button.TabIndex = 2;
            this.Search_button.Text = "   查询(&Q)";
            this.Search_button.UseVisualStyleBackColor = true;
            this.Search_button.Click += new System.EventHandler(this.Search_button_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(416, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 31;
            this.label3.Text = "到";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(251, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 30;
            this.label4.Text = "从";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 29;
            this.label5.Text = "常用时间段";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Checked = false;
            this.dateTimePicker2.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(448, 20);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(127, 21);
            this.dateTimePicker2.TabIndex = 28;
            // 
            // dateTimeDuan1
            // 
            this.dateTimeDuan1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dateTimeDuan1.End = this.dateTimePicker2;
            this.dateTimeDuan1.FormattingEnabled = true;
            this.dateTimeDuan1.Location = new System.Drawing.Point(84, 20);
            this.dateTimeDuan1.Name = "dateTimeDuan1";
            this.dateTimeDuan1.Size = new System.Drawing.Size(133, 20);
            this.dateTimeDuan1.Start = this.dateTimePicker1;
            this.dateTimeDuan1.TabIndex = 0;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Checked = false;
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(274, 19);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(127, 21);
            this.dateTimePicker1.TabIndex = 26;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.CardFJ_tab);
            this.tabControl1.Controls.Add(this.CardJLRec_tab);
            this.tabControl1.Controls.Add(this.CardCC_tab);
            this.tabControl1.Controls.Add(this.CardExplain_tab);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControl1.ItemSize = new System.Drawing.Size(137, 17);
            this.tabControl1.Location = new System.Drawing.Point(0, 411);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(894, 335);
            this.tabControl1.TabIndex = 18;
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // CardFJ_tab
            // 
            this.CardFJ_tab.AutoScroll = true;
            this.CardFJ_tab.Controls.Add(this.groupBox5);
            this.CardFJ_tab.Location = new System.Drawing.Point(4, 21);
            this.CardFJ_tab.Margin = new System.Windows.Forms.Padding(10);
            this.CardFJ_tab.Name = "CardFJ_tab";
            this.CardFJ_tab.Padding = new System.Windows.Forms.Padding(5);
            this.CardFJ_tab.Size = new System.Drawing.Size(886, 310);
            this.CardFJ_tab.TabIndex = 1;
            this.CardFJ_tab.Text = "设备附件";
            this.CardFJ_tab.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dataGView2);
            this.groupBox5.Controls.Add(this.groupBox2);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(5, 5);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(876, 300);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "设备附件清单";
            // 
            // CardJLRec_tab
            // 
            this.CardJLRec_tab.AutoScroll = true;
            this.CardJLRec_tab.Controls.Add(this.groupBox6);
            this.CardJLRec_tab.Location = new System.Drawing.Point(4, 21);
            this.CardJLRec_tab.Margin = new System.Windows.Forms.Padding(10);
            this.CardJLRec_tab.Name = "CardJLRec_tab";
            this.CardJLRec_tab.Padding = new System.Windows.Forms.Padding(5);
            this.CardJLRec_tab.Size = new System.Drawing.Size(886, 310);
            this.CardJLRec_tab.TabIndex = 2;
            this.CardJLRec_tab.Text = "计量设备";
            this.CardJLRec_tab.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dataGView3);
            this.groupBox6.Controls.Add(this.groupBox3);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(5, 5);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(876, 300);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "计量设备清单";
            // 
            // CardCC_tab
            // 
            this.CardCC_tab.AutoScroll = true;
            this.CardCC_tab.Controls.Add(this.label54);
            this.CardCC_tab.Controls.Add(this.label56);
            this.CardCC_tab.Controls.Add(this.label55);
            this.CardCC_tab.Controls.Add(this.label57);
            this.CardCC_tab.Controls.Add(this.CCuseridtextBox);
            this.CardCC_tab.Controls.Add(this.CCchosode_textBox);
            this.CardCC_tab.Controls.Add(this.CCcardid_textBox);
            this.CardCC_tab.Controls.Add(this.label59);
            this.CardCC_tab.Controls.Add(this.CCusername_textBox);
            this.CardCC_tab.Controls.Add(this.CCrecdate_textBox);
            this.CardCC_tab.Controls.Add(this.CCcc_textBox);
            this.CardCC_tab.Controls.Add(this.CCprice_textBox);
            this.CardCC_tab.Controls.Add(this.label60);
            this.CardCC_tab.Controls.Add(this.label61);
            this.CardCC_tab.Controls.Add(this.CCbuydate_textBox);
            this.CardCC_tab.Controls.Add(this.label49);
            this.CardCC_tab.Controls.Add(this.label52);
            this.CardCC_tab.Controls.Add(this.label50);
            this.CardCC_tab.Controls.Add(this.label51);
            this.CardCC_tab.Controls.Add(this.CCnewold_textBox);
            this.CardCC_tab.Controls.Add(this.CCsupply_textBox);
            this.CardCC_tab.Controls.Add(this.CCcsname_textBox);
            this.CardCC_tab.Controls.Add(this.CCother_textBox);
            this.CardCC_tab.Controls.Add(this.label53);
            this.CardCC_tab.Location = new System.Drawing.Point(4, 21);
            this.CardCC_tab.Margin = new System.Windows.Forms.Padding(10);
            this.CardCC_tab.Name = "CardCC_tab";
            this.CardCC_tab.Padding = new System.Windows.Forms.Padding(5);
            this.CardCC_tab.Size = new System.Drawing.Size(886, 230);
            this.CardCC_tab.TabIndex = 3;
            this.CardCC_tab.Text = "设备财产管理";
            this.CardCC_tab.UseVisualStyleBackColor = true;
            // 
            // label54
            // 
            this.label54.Location = new System.Drawing.Point(117, 79);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(82, 21);
            this.label54.TabIndex = 35;
            this.label54.Text = "价格";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.Location = new System.Drawing.Point(117, 304);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(82, 21);
            this.label56.TabIndex = 34;
            this.label56.Text = "医疗机构编码";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.Location = new System.Drawing.Point(117, 124);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(82, 21);
            this.label55.TabIndex = 36;
            this.label55.Text = "出厂日期";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.Location = new System.Drawing.Point(117, 259);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(82, 21);
            this.label57.TabIndex = 33;
            this.label57.Text = "操作员ID";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CCuseridtextBox
            // 
            this.CCuseridtextBox.Location = new System.Drawing.Point(220, 259);
            this.CCuseridtextBox.Multiline = true;
            this.CCuseridtextBox.Name = "CCuseridtextBox";
            this.CCuseridtextBox.ReadOnly = true;
            this.CCuseridtextBox.Size = new System.Drawing.Size(150, 21);
            this.CCuseridtextBox.TabIndex = 41;
            this.CCuseridtextBox.TabStop = false;
            // 
            // CCchosode_textBox
            // 
            this.CCchosode_textBox.Location = new System.Drawing.Point(220, 304);
            this.CCchosode_textBox.Multiline = true;
            this.CCchosode_textBox.Name = "CCchosode_textBox";
            this.CCchosode_textBox.ReadOnly = true;
            this.CCchosode_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCchosode_textBox.TabIndex = 40;
            this.CCchosode_textBox.TabStop = false;
            // 
            // CCcardid_textBox
            // 
            this.CCcardid_textBox.Location = new System.Drawing.Point(220, 33);
            this.CCcardid_textBox.Multiline = true;
            this.CCcardid_textBox.Name = "CCcardid_textBox";
            this.CCcardid_textBox.ReadOnly = true;
            this.CCcardid_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCcardid_textBox.TabIndex = 39;
            this.CCcardid_textBox.TabStop = false;
            // 
            // label59
            // 
            this.label59.Location = new System.Drawing.Point(117, 169);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(82, 21);
            this.label59.TabIndex = 31;
            this.label59.Text = "修改时间";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CCusername_textBox
            // 
            this.CCusername_textBox.Location = new System.Drawing.Point(220, 218);
            this.CCusername_textBox.Multiline = true;
            this.CCusername_textBox.Name = "CCusername_textBox";
            this.CCusername_textBox.ReadOnly = true;
            this.CCusername_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCusername_textBox.TabIndex = 43;
            this.CCusername_textBox.TabStop = false;
            // 
            // CCrecdate_textBox
            // 
            this.CCrecdate_textBox.Location = new System.Drawing.Point(220, 169);
            this.CCrecdate_textBox.Multiline = true;
            this.CCrecdate_textBox.Name = "CCrecdate_textBox";
            this.CCrecdate_textBox.ReadOnly = true;
            this.CCrecdate_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCrecdate_textBox.TabIndex = 42;
            this.CCrecdate_textBox.TabStop = false;
            // 
            // CCcc_textBox
            // 
            this.CCcc_textBox.Location = new System.Drawing.Point(220, 124);
            this.CCcc_textBox.Multiline = true;
            this.CCcc_textBox.Name = "CCcc_textBox";
            this.CCcc_textBox.ReadOnly = true;
            this.CCcc_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCcc_textBox.TabIndex = 37;
            this.CCcc_textBox.TabStop = false;
            // 
            // CCprice_textBox
            // 
            this.CCprice_textBox.Location = new System.Drawing.Point(220, 79);
            this.CCprice_textBox.Multiline = true;
            this.CCprice_textBox.Name = "CCprice_textBox";
            this.CCprice_textBox.ReadOnly = true;
            this.CCprice_textBox.Size = new System.Drawing.Size(150, 21);
            this.CCprice_textBox.TabIndex = 38;
            this.CCprice_textBox.TabStop = false;
            // 
            // label60
            // 
            this.label60.Location = new System.Drawing.Point(117, 218);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(82, 21);
            this.label60.TabIndex = 32;
            this.label60.Text = "操作员名称";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.Location = new System.Drawing.Point(117, 34);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(82, 21);
            this.label61.TabIndex = 30;
            this.label61.Text = "卡片ID";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CCbuydate_textBox
            // 
            this.CCbuydate_textBox.CustomFormat = "yyyy-MM-dd hh:mm";
            this.CCbuydate_textBox.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.CCbuydate_textBox.Location = new System.Drawing.Point(856, 74);
            this.CCbuydate_textBox.Name = "CCbuydate_textBox";
            this.CCbuydate_textBox.Size = new System.Drawing.Size(210, 21);
            this.CCbuydate_textBox.TabIndex = 29;
            // 
            // label49
            // 
            this.label49.Location = new System.Drawing.Point(756, 30);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(82, 25);
            this.label49.TabIndex = 25;
            this.label49.Text = "供货单位";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.Location = new System.Drawing.Point(756, 214);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(82, 25);
            this.label52.TabIndex = 28;
            this.label52.Text = "其他";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.Location = new System.Drawing.Point(756, 120);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(82, 25);
            this.label50.TabIndex = 27;
            this.label50.Text = "产商名称";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.Location = new System.Drawing.Point(756, 75);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(82, 25);
            this.label51.TabIndex = 26;
            this.label51.Text = "购置日期";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CCnewold_textBox
            // 
            this.CCnewold_textBox.Location = new System.Drawing.Point(856, 165);
            this.CCnewold_textBox.Multiline = true;
            this.CCnewold_textBox.Name = "CCnewold_textBox";
            this.CCnewold_textBox.Size = new System.Drawing.Size(210, 25);
            this.CCnewold_textBox.TabIndex = 22;
            // 
            // CCsupply_textBox
            // 
            this.CCsupply_textBox.Location = new System.Drawing.Point(856, 30);
            this.CCsupply_textBox.Multiline = true;
            this.CCsupply_textBox.Name = "CCsupply_textBox";
            this.CCsupply_textBox.Size = new System.Drawing.Size(210, 25);
            this.CCsupply_textBox.TabIndex = 20;
            // 
            // CCcsname_textBox
            // 
            this.CCcsname_textBox.Location = new System.Drawing.Point(856, 120);
            this.CCcsname_textBox.Multiline = true;
            this.CCcsname_textBox.Name = "CCcsname_textBox";
            this.CCcsname_textBox.Size = new System.Drawing.Size(210, 25);
            this.CCcsname_textBox.TabIndex = 21;
            // 
            // CCother_textBox
            // 
            this.CCother_textBox.Location = new System.Drawing.Point(856, 218);
            this.CCother_textBox.Multiline = true;
            this.CCother_textBox.Name = "CCother_textBox";
            this.CCother_textBox.Size = new System.Drawing.Size(210, 107);
            this.CCother_textBox.TabIndex = 23;
            // 
            // label53
            // 
            this.label53.Location = new System.Drawing.Point(756, 165);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(82, 25);
            this.label53.TabIndex = 24;
            this.label53.Text = "新旧程度";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CardExplain_tab
            // 
            this.CardExplain_tab.AutoScroll = true;
            this.CardExplain_tab.Controls.Add(this.button3);
            this.CardExplain_tab.Controls.Add(this.groupBox7);
            this.CardExplain_tab.Controls.Add(this.label66);
            this.CardExplain_tab.Controls.Add(this.label68);
            this.CardExplain_tab.Controls.Add(this.label67);
            this.CardExplain_tab.Controls.Add(this.label62);
            this.CardExplain_tab.Controls.Add(this.SMexplainNum_textBox);
            this.CardExplain_tab.Controls.Add(this.SMusrtid_textBox);
            this.CardExplain_tab.Controls.Add(this.textBox1);
            this.CardExplain_tab.Controls.Add(this.SMchoscode_textBox);
            this.CardExplain_tab.Controls.Add(this.label65);
            this.CardExplain_tab.Controls.Add(this.label63);
            this.CardExplain_tab.Controls.Add(this.SMboxthing_textBox);
            this.CardExplain_tab.Controls.Add(this.SMusername_textBox);
            this.CardExplain_tab.Controls.Add(this.label64);
            this.CardExplain_tab.Controls.Add(this.label69);
            this.CardExplain_tab.Controls.Add(this.SMteachnum_textBox);
            this.CardExplain_tab.Controls.Add(this.SMother_textBox);
            this.CardExplain_tab.Controls.Add(this.label70);
            this.CardExplain_tab.Controls.Add(this.SMcertificate_textBox);
            this.CardExplain_tab.Controls.Add(this.label71);
            this.CardExplain_tab.Controls.Add(this.SMcardid_textBox);
            this.CardExplain_tab.Controls.Add(this.label72);
            this.CardExplain_tab.Controls.Add(this.SMext_textBox);
            this.CardExplain_tab.Location = new System.Drawing.Point(4, 21);
            this.CardExplain_tab.Margin = new System.Windows.Forms.Padding(10);
            this.CardExplain_tab.Name = "CardExplain_tab";
            this.CardExplain_tab.Padding = new System.Windows.Forms.Padding(5);
            this.CardExplain_tab.Size = new System.Drawing.Size(886, 230);
            this.CardExplain_tab.TabIndex = 4;
            this.CardExplain_tab.Text = "设备说明书";
            this.CardExplain_tab.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(604, 39);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(106, 23);
            this.button3.TabIndex = 20;
            this.button3.Text = "(更改)上传图纸";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.pictureBox1);
            this.groupBox7.Location = new System.Drawing.Point(739, 24);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(273, 272);
            this.groupBox7.TabIndex = 19;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "图纸";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(3, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(267, 252);
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // label66
            // 
            this.label66.Location = new System.Drawing.Point(49, 393);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(95, 21);
            this.label66.TabIndex = 16;
            this.label66.Text = "验收合格证";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.Location = new System.Drawing.Point(39, 199);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(106, 21);
            this.label68.TabIndex = 16;
            this.label68.Text = "医疗机构编码";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.Location = new System.Drawing.Point(39, 79);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(106, 21);
            this.label67.TabIndex = 16;
            this.label67.Text = "修改时间";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.Location = new System.Drawing.Point(49, 162);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(95, 21);
            this.label62.TabIndex = 16;
            this.label62.Text = "操作员名称";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMexplainNum_textBox
            // 
            this.SMexplainNum_textBox.Location = new System.Drawing.Point(184, 239);
            this.SMexplainNum_textBox.Name = "SMexplainNum_textBox";
            this.SMexplainNum_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMexplainNum_textBox.TabIndex = 4;
            // 
            // SMusrtid_textBox
            // 
            this.SMusrtid_textBox.Location = new System.Drawing.Point(184, 119);
            this.SMusrtid_textBox.Name = "SMusrtid_textBox";
            this.SMusrtid_textBox.ReadOnly = true;
            this.SMusrtid_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMusrtid_textBox.TabIndex = 17;
            this.SMusrtid_textBox.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(184, 81);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(164, 21);
            this.textBox1.TabIndex = 17;
            this.textBox1.TabStop = false;
            // 
            // SMchoscode_textBox
            // 
            this.SMchoscode_textBox.Location = new System.Drawing.Point(184, 197);
            this.SMchoscode_textBox.Name = "SMchoscode_textBox";
            this.SMchoscode_textBox.ReadOnly = true;
            this.SMchoscode_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMchoscode_textBox.TabIndex = 17;
            this.SMchoscode_textBox.TabStop = false;
            // 
            // label65
            // 
            this.label65.Location = new System.Drawing.Point(49, 355);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(95, 21);
            this.label65.TabIndex = 16;
            this.label65.Text = "装箱单";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.Location = new System.Drawing.Point(49, 120);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(95, 21);
            this.label63.TabIndex = 16;
            this.label63.Text = "操作员ID";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMboxthing_textBox
            // 
            this.SMboxthing_textBox.Location = new System.Drawing.Point(184, 356);
            this.SMboxthing_textBox.Name = "SMboxthing_textBox";
            this.SMboxthing_textBox.Size = new System.Drawing.Size(825, 21);
            this.SMboxthing_textBox.TabIndex = 1;
            // 
            // SMusername_textBox
            // 
            this.SMusername_textBox.Location = new System.Drawing.Point(184, 159);
            this.SMusername_textBox.Name = "SMusername_textBox";
            this.SMusername_textBox.ReadOnly = true;
            this.SMusername_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMusername_textBox.TabIndex = 17;
            this.SMusername_textBox.TabStop = false;
            // 
            // label64
            // 
            this.label64.Location = new System.Drawing.Point(49, 275);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(95, 21);
            this.label64.TabIndex = 16;
            this.label64.Text = "技术说明书份数";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.Location = new System.Drawing.Point(604, 310);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(106, 21);
            this.label69.TabIndex = 16;
            this.label69.Text = "图纸文件格式";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMteachnum_textBox
            // 
            this.SMteachnum_textBox.Location = new System.Drawing.Point(184, 275);
            this.SMteachnum_textBox.Name = "SMteachnum_textBox";
            this.SMteachnum_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMteachnum_textBox.TabIndex = 3;
            // 
            // SMother_textBox
            // 
            this.SMother_textBox.Location = new System.Drawing.Point(184, 315);
            this.SMother_textBox.Multiline = true;
            this.SMother_textBox.Name = "SMother_textBox";
            this.SMother_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMother_textBox.TabIndex = 5;
            // 
            // label70
            // 
            this.label70.Location = new System.Drawing.Point(50, 239);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(95, 21);
            this.label70.TabIndex = 16;
            this.label70.Text = "使用说明书份数";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMcertificate_textBox
            // 
            this.SMcertificate_textBox.Location = new System.Drawing.Point(184, 396);
            this.SMcertificate_textBox.Multiline = true;
            this.SMcertificate_textBox.Name = "SMcertificate_textBox";
            this.SMcertificate_textBox.Size = new System.Drawing.Size(825, 21);
            this.SMcertificate_textBox.TabIndex = 2;
            // 
            // label71
            // 
            this.label71.Location = new System.Drawing.Point(49, 38);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(95, 21);
            this.label71.TabIndex = 16;
            this.label71.Text = "卡片ID";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMcardid_textBox
            // 
            this.SMcardid_textBox.Location = new System.Drawing.Point(184, 39);
            this.SMcardid_textBox.Name = "SMcardid_textBox";
            this.SMcardid_textBox.ReadOnly = true;
            this.SMcardid_textBox.Size = new System.Drawing.Size(164, 21);
            this.SMcardid_textBox.TabIndex = 17;
            this.SMcardid_textBox.TabStop = false;
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.Color.White;
            this.label72.Location = new System.Drawing.Point(39, 314);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(106, 21);
            this.label72.TabIndex = 16;
            this.label72.Text = "其他";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SMext_textBox
            // 
            this.SMext_textBox.Location = new System.Drawing.Point(742, 310);
            this.SMext_textBox.Name = "SMext_textBox";
            this.SMext_textBox.ReadOnly = true;
            this.SMext_textBox.Size = new System.Drawing.Size(267, 21);
            this.SMext_textBox.TabIndex = 17;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.TiaoSu);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox4.Location = new System.Drawing.Point(0, 381);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(894, 30);
            this.groupBox4.TabIndex = 43;
            this.groupBox4.TabStop = false;
            // 
            // TiaoSu
            // 
            this.TiaoSu.AutoSize = true;
            this.TiaoSu.Location = new System.Drawing.Point(46, 14);
            this.TiaoSu.Name = "TiaoSu";
            this.TiaoSu.Size = new System.Drawing.Size(23, 12);
            this.TiaoSu.TabIndex = 31;
            this.TiaoSu.Text = "0笔";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(21, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 30;
            this.label13.Text = "共：";
            // 
            // dataGView1
            // 
            this.dataGView1.AllowUserToAddRows = false;
            this.dataGView1.AllowUserToDeleteRows = false;
            this.dataGView1.AllowUserToResizeRows = false;
            this.dataGView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGView1.ChangeDataColumName = null;
            this.dataGView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGView1.ColumnHeadersHeight = 25;
            this.dataGView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column4,
            this.Column47,
            this.Column8,
            this.Column5,
            this.Column37,
            this.Column6,
            this.Column7,
            this.Column20,
            this.Column38,
            this.Column21,
            this.Column22,
            this.Column23,
            this.Column24,
            this.Column25,
            this.Column26,
            this.Column27,
            this.Column28,
            this.Column29,
            this.Column30,
            this.Column31,
            this.Column32,
            this.Column33,
            this.Column34,
            this.Column35,
            this.Column36,
            this.Column39,
            this.Column40,
            this.Column41,
            this.Column42,
            this.Column43,
            this.Column44,
            this.Column45,
            this.Column46,
            this.Column48,
            this.Column49,
            this.Column50,
            this.Column51,
            this.Column52,
            this.Column53,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column16});
            this.dataGView1.DbConn = null;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGView1.DwColIndex = 0;
            this.dataGView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView1.IsEditOnEnter = true;
            this.dataGView1.IsFillForm = true;
            this.dataGView1.IsPage = false;
            this.dataGView1.Key = null;
            this.dataGView1.Location = new System.Drawing.Point(0, 93);
            this.dataGView1.MultiSelect = false;
            this.dataGView1.Name = "dataGView1";
            this.dataGView1.ReadOnly = true;
            this.dataGView1.RowHeadersWidth = 30;
            this.dataGView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView1.RowTemplate.Height = 23;
            this.dataGView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView1.Size = new System.Drawing.Size(894, 288);
            this.dataGView1.TabIndex = 44;
            this.dataGView1.TjFmtStr = null;
            this.dataGView1.TjFormat = null;
            this.dataGView1.Url = null;
            this.dataGView1.SelectionChanged += new System.EventHandler(this.dataGView1_SelectionChanged);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "CARDID";
            this.Column1.HeaderText = "卡片ID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 64;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "CARDCODE";
            this.Column2.HeaderText = "卡号";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 52;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "STOCKFLOWNO";
            this.Column4.HeaderText = "库存流水号";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column4.Width = 88;
            // 
            // Column47
            // 
            this.Column47.DataPropertyName = "STATUS";
            this.Column47.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Column47.HeaderText = "状态";
            this.Column47.Name = "Column47";
            this.Column47.ReadOnly = true;
            this.Column47.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column47.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column47.Width = 52;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "DEPTID";
            this.Column8.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Column8.HeaderText = "使用科室";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column8.Width = 76;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "STOCKID";
            this.Column5.HeaderText = "库存ID";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 64;
            // 
            // Column37
            // 
            this.Column37.DataPropertyName = "EQID";
            this.Column37.HeaderText = "设备ID";
            this.Column37.Name = "Column37";
            this.Column37.ReadOnly = true;
            this.Column37.Width = 64;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "EQNAME";
            this.Column6.HeaderText = "设备名称";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 76;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "STATUSCODE";
            this.Column7.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Column7.HeaderText = "使用状态";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column7.Width = 76;
            // 
            // Column20
            // 
            this.Column20.DataPropertyName = "COUNTRY";
            this.Column20.HeaderText = "国别";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.Width = 52;
            // 
            // Column38
            // 
            this.Column38.DataPropertyName = "CONTRACTCODE";
            this.Column38.HeaderText = "合同号";
            this.Column38.Name = "Column38";
            this.Column38.ReadOnly = true;
            this.Column38.Width = 64;
            // 
            // Column21
            // 
            this.Column21.DataPropertyName = "EQNUM";
            this.Column21.HeaderText = "设备数量";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.Width = 76;
            // 
            // Column22
            // 
            this.Column22.DataPropertyName = "PRICE";
            this.Column22.HeaderText = "价格";
            this.Column22.Name = "Column22";
            this.Column22.ReadOnly = true;
            this.Column22.Width = 52;
            // 
            // Column23
            // 
            this.Column23.DataPropertyName = "YPRICE";
            this.Column23.HeaderText = "原值";
            this.Column23.Name = "Column23";
            this.Column23.ReadOnly = true;
            this.Column23.Width = 52;
            // 
            // Column24
            // 
            this.Column24.DataPropertyName = "FARE";
            this.Column24.HeaderText = "收费标准";
            this.Column24.Name = "Column24";
            this.Column24.ReadOnly = true;
            this.Column24.Width = 76;
            // 
            // Column25
            // 
            this.Column25.DataPropertyName = "DGDATE";
            this.Column25.HeaderText = "订购时间";
            this.Column25.Name = "Column25";
            this.Column25.ReadOnly = true;
            this.Column25.Width = 76;
            // 
            // Column26
            // 
            this.Column26.DataPropertyName = "CCDATE";
            this.Column26.HeaderText = "出厂时间";
            this.Column26.Name = "Column26";
            this.Column26.ReadOnly = true;
            this.Column26.Width = 76;
            // 
            // Column27
            // 
            this.Column27.DataPropertyName = "LYPEOPLE";
            this.Column27.HeaderText = "领用人";
            this.Column27.Name = "Column27";
            this.Column27.ReadOnly = true;
            this.Column27.Width = 64;
            // 
            // Column28
            // 
            this.Column28.DataPropertyName = "LYDATE";
            this.Column28.HeaderText = "领用时间";
            this.Column28.Name = "Column28";
            this.Column28.ReadOnly = true;
            this.Column28.Width = 76;
            // 
            // Column29
            // 
            this.Column29.DataPropertyName = "SETUPDATE";
            this.Column29.HeaderText = "安装时间";
            this.Column29.Name = "Column29";
            this.Column29.ReadOnly = true;
            this.Column29.Width = 76;
            // 
            // Column30
            // 
            this.Column30.DataPropertyName = "SETUPPEOPLE";
            this.Column30.HeaderText = "安装人";
            this.Column30.Name = "Column30";
            this.Column30.ReadOnly = true;
            this.Column30.Width = 64;
            // 
            // Column31
            // 
            this.Column31.DataPropertyName = "CCCODE";
            this.Column31.HeaderText = "出厂号";
            this.Column31.Name = "Column31";
            this.Column31.ReadOnly = true;
            this.Column31.Width = 64;
            // 
            // Column32
            // 
            this.Column32.DataPropertyName = "USEYEAR";
            this.Column32.HeaderText = "使用年限";
            this.Column32.Name = "Column32";
            this.Column32.ReadOnly = true;
            this.Column32.Width = 76;
            // 
            // Column33
            // 
            this.Column33.DataPropertyName = "USEDYEAR";
            this.Column33.HeaderText = "已使用年限";
            this.Column33.Name = "Column33";
            this.Column33.ReadOnly = true;
            this.Column33.Width = 88;
            // 
            // Column34
            // 
            this.Column34.DataPropertyName = "TOTALWORK";
            this.Column34.HeaderText = "总工作量";
            this.Column34.Name = "Column34";
            this.Column34.ReadOnly = true;
            this.Column34.Width = 76;
            // 
            // Column35
            // 
            this.Column35.DataPropertyName = "TOTALEDWORK";
            this.Column35.HeaderText = "累计工作量";
            this.Column35.Name = "Column35";
            this.Column35.ReadOnly = true;
            this.Column35.Width = 88;
            // 
            // Column36
            // 
            this.Column36.DataPropertyName = "TOTALZJ";
            this.Column36.HeaderText = "累计折旧";
            this.Column36.Name = "Column36";
            this.Column36.ReadOnly = true;
            this.Column36.Width = 76;
            // 
            // Column39
            // 
            this.Column39.DataPropertyName = "CZRATE";
            this.Column39.HeaderText = "残值率";
            this.Column39.Name = "Column39";
            this.Column39.ReadOnly = true;
            this.Column39.Width = 64;
            // 
            // Column40
            // 
            this.Column40.DataPropertyName = "MAINUSE";
            this.Column40.HeaderText = "主要用途";
            this.Column40.Name = "Column40";
            this.Column40.ReadOnly = true;
            this.Column40.Width = 76;
            // 
            // Column41
            // 
            this.Column41.DataPropertyName = "YSREC";
            this.Column41.HeaderText = "验收记录";
            this.Column41.Name = "Column41";
            this.Column41.ReadOnly = true;
            this.Column41.Width = 76;
            // 
            // Column42
            // 
            this.Column42.DataPropertyName = "YSPEOPLE";
            this.Column42.HeaderText = "验收人员";
            this.Column42.Name = "Column42";
            this.Column42.ReadOnly = true;
            this.Column42.Width = 76;
            // 
            // Column43
            // 
            this.Column43.DataPropertyName = "QUATHING";
            this.Column43.HeaderText = "质量情况";
            this.Column43.Name = "Column43";
            this.Column43.ReadOnly = true;
            this.Column43.Width = 76;
            // 
            // Column44
            // 
            this.Column44.DataPropertyName = "FDVALUE";
            this.Column44.HeaderText = "分度值";
            this.Column44.Name = "Column44";
            this.Column44.ReadOnly = true;
            this.Column44.Width = 64;
            // 
            // Column45
            // 
            this.Column45.DataPropertyName = "JDLEVEL";
            this.Column45.HeaderText = "精度等级";
            this.Column45.Name = "Column45";
            this.Column45.ReadOnly = true;
            this.Column45.Width = 76;
            // 
            // Column46
            // 
            this.Column46.DataPropertyName = "CHECKLEVEL";
            this.Column46.HeaderText = "检定等级";
            this.Column46.Name = "Column46";
            this.Column46.ReadOnly = true;
            this.Column46.Width = 76;
            // 
            // Column48
            // 
            this.Column48.DataPropertyName = "CHECKRANGE";
            this.Column48.HeaderText = "测量范围";
            this.Column48.Name = "Column48";
            this.Column48.ReadOnly = true;
            this.Column48.Width = 76;
            // 
            // Column49
            // 
            this.Column49.DataPropertyName = "CHECKZQ";
            this.Column49.HeaderText = "检定周期";
            this.Column49.Name = "Column49";
            this.Column49.ReadOnly = true;
            this.Column49.Width = 76;
            // 
            // Column50
            // 
            this.Column50.DataPropertyName = "BGPEOPLE";
            this.Column50.HeaderText = "保管人";
            this.Column50.Name = "Column50";
            this.Column50.ReadOnly = true;
            this.Column50.Width = 64;
            // 
            // Column51
            // 
            this.Column51.DataPropertyName = "BFDATE";
            this.Column51.HeaderText = "报废日期";
            this.Column51.Name = "Column51";
            this.Column51.ReadOnly = true;
            this.Column51.Width = 76;
            // 
            // Column52
            // 
            this.Column52.DataPropertyName = "BFPEOPLE";
            this.Column52.HeaderText = "报废人";
            this.Column52.Name = "Column52";
            this.Column52.ReadOnly = true;
            this.Column52.Width = 64;
            // 
            // Column53
            // 
            this.Column53.DataPropertyName = "MEMO";
            this.Column53.HeaderText = "备注";
            this.Column53.Name = "Column53";
            this.Column53.ReadOnly = true;
            this.Column53.Width = 52;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "TXM";
            this.Column9.HeaderText = "条形码";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 64;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "USERID";
            this.Column10.HeaderText = "操作员ID";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 76;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "USERNAME";
            this.Column11.HeaderText = "操作员名称";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 88;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "RECDATE";
            this.Column12.HeaderText = "制卡时间";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 76;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "STARTDATE";
            this.Column13.HeaderText = "启用日期";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Width = 76;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "STARTPEOPLE";
            this.Column14.HeaderText = "启用人";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Width = 64;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "CHOSCODE";
            this.Column16.HeaderText = "医疗机构编码";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Location = new System.Drawing.Point(3, 267);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(870, 30);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(217, 14);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 12);
            this.label14.TabIndex = 33;
            this.label14.Text = "0元";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(144, 14);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 32;
            this.label17.Text = "金额合计：";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(46, 14);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(23, 12);
            this.label18.TabIndex = 31;
            this.label18.Text = "0条";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(21, 14);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 30;
            this.label19.Text = "共：";
            // 
            // dataGView2
            // 
            this.dataGView2.AllowUserToAddRows = false;
            this.dataGView2.AllowUserToDeleteRows = false;
            this.dataGView2.AllowUserToResizeRows = false;
            this.dataGView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGView2.ChangeDataColumName = null;
            this.dataGView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FJ_CardIdCloumn,
            this.FJ_RowNoColumn,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.FJ_unitColumn,
            this.FJ_NUMColumn,
            this.FJ_PriceColumn,
            this.FJ_MoneyColumn,
            this.FJ_Status,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.dataGView2.DbConn = null;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView2.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGView2.DwColIndex = 0;
            this.dataGView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView2.IsEditOnEnter = true;
            this.dataGView2.IsFillForm = true;
            this.dataGView2.IsPage = false;
            this.dataGView2.Key = null;
            this.dataGView2.Location = new System.Drawing.Point(3, 17);
            this.dataGView2.MultiSelect = false;
            this.dataGView2.Name = "dataGView2";
            this.dataGView2.RowHeadersWidth = 20;
            this.dataGView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView2.RowTemplate.Height = 23;
            this.dataGView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView2.Size = new System.Drawing.Size(870, 250);
            this.dataGView2.TabIndex = 42;
            this.dataGView2.TjFmtStr = null;
            this.dataGView2.TjFormat = null;
            this.dataGView2.Url = null;
            // 
            // FJ_CardIdCloumn
            // 
            this.FJ_CardIdCloumn.DataPropertyName = "CARDID";
            this.FJ_CardIdCloumn.HeaderText = "卡片ID";
            this.FJ_CardIdCloumn.Name = "FJ_CardIdCloumn";
            this.FJ_CardIdCloumn.ReadOnly = true;
            this.FJ_CardIdCloumn.Width = 64;
            // 
            // FJ_RowNoColumn
            // 
            this.FJ_RowNoColumn.DataPropertyName = "ROWNO";
            this.FJ_RowNoColumn.HeaderText = "行号";
            this.FJ_RowNoColumn.Name = "FJ_RowNoColumn";
            this.FJ_RowNoColumn.ReadOnly = true;
            this.FJ_RowNoColumn.Width = 52;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "FJNAME";
            this.dataGridViewTextBoxColumn1.HeaderText = "附件名称";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 76;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "COUNTRY";
            this.dataGridViewTextBoxColumn2.HeaderText = "国别";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 52;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "GGXH";
            this.dataGridViewTextBoxColumn3.HeaderText = "规格型号";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 76;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CCCODE";
            this.dataGridViewTextBoxColumn4.HeaderText = "出厂号";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 64;
            // 
            // FJ_unitColumn
            // 
            this.FJ_unitColumn.DataPropertyName = "UNIT";
            this.FJ_unitColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.FJ_unitColumn.HeaderText = "单位";
            this.FJ_unitColumn.Name = "FJ_unitColumn";
            this.FJ_unitColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.FJ_unitColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.FJ_unitColumn.Width = 52;
            // 
            // FJ_NUMColumn
            // 
            this.FJ_NUMColumn.DataPropertyName = "NUM";
            this.FJ_NUMColumn.HeaderText = "数量";
            this.FJ_NUMColumn.Name = "FJ_NUMColumn";
            this.FJ_NUMColumn.Width = 52;
            // 
            // FJ_PriceColumn
            // 
            this.FJ_PriceColumn.DataPropertyName = "PRICE";
            this.FJ_PriceColumn.HeaderText = "单价";
            this.FJ_PriceColumn.Name = "FJ_PriceColumn";
            this.FJ_PriceColumn.Width = 52;
            // 
            // FJ_MoneyColumn
            // 
            this.FJ_MoneyColumn.DataPropertyName = "TOTALMONEY";
            this.FJ_MoneyColumn.HeaderText = "金额";
            this.FJ_MoneyColumn.Name = "FJ_MoneyColumn";
            this.FJ_MoneyColumn.ReadOnly = true;
            this.FJ_MoneyColumn.Width = 52;
            // 
            // FJ_Status
            // 
            this.FJ_Status.DataPropertyName = "STATUS";
            this.FJ_Status.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.FJ_Status.HeaderText = "状态";
            this.FJ_Status.Name = "FJ_Status";
            this.FJ_Status.ReadOnly = true;
            this.FJ_Status.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.FJ_Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.FJ_Status.Width = 52;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "USERID";
            this.dataGridViewTextBoxColumn5.HeaderText = "操作员ID";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 76;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "USERNAME";
            this.dataGridViewTextBoxColumn6.HeaderText = "操作员名称";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 88;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "RECDATE";
            this.dataGridViewTextBoxColumn7.HeaderText = "修改时间";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn7.Width = 76;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "CHOSCODE";
            this.dataGridViewTextBoxColumn8.HeaderText = "医疗机构编码";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox3.Location = new System.Drawing.Point(3, 267);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(870, 30);
            this.groupBox3.TabIndex = 42;
            this.groupBox3.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 12);
            this.label7.TabIndex = 31;
            this.label7.Text = "0条";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 30;
            this.label8.Text = "共：";
            // 
            // dataGView3
            // 
            this.dataGView3.AllowUserToAddRows = false;
            this.dataGView3.AllowUserToDeleteRows = false;
            this.dataGView3.AllowUserToResizeRows = false;
            this.dataGView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGView3.ChangeDataColumName = null;
            this.dataGView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.JL_CardIdColumn,
            this.JL_RowNOColumn,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.JL_CheckdateColumn,
            this.JL_CheckDate_Column,
            this.JL_StatusColumn,
            this.dataGridViewTextBoxColumn36,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39});
            this.dataGView3.DbConn = null;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView3.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGView3.DwColIndex = 0;
            this.dataGView3.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView3.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView3.IsEditOnEnter = true;
            this.dataGView3.IsFillForm = true;
            this.dataGView3.IsPage = false;
            this.dataGView3.Key = null;
            this.dataGView3.Location = new System.Drawing.Point(3, 17);
            this.dataGView3.MultiSelect = false;
            this.dataGView3.Name = "dataGView3";
            this.dataGView3.RowHeadersWidth = 20;
            this.dataGView3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView3.RowTemplate.Height = 23;
            this.dataGView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView3.Size = new System.Drawing.Size(870, 250);
            this.dataGView3.TabIndex = 43;
            this.dataGView3.TjFmtStr = null;
            this.dataGView3.TjFormat = null;
            this.dataGView3.Url = null;
            // 
            // JL_CardIdColumn
            // 
            this.JL_CardIdColumn.DataPropertyName = "CARDID";
            this.JL_CardIdColumn.HeaderText = "卡片ID";
            this.JL_CardIdColumn.Name = "JL_CardIdColumn";
            this.JL_CardIdColumn.ReadOnly = true;
            this.JL_CardIdColumn.Width = 64;
            // 
            // JL_RowNOColumn
            // 
            this.JL_RowNOColumn.DataPropertyName = "ROWNO";
            this.JL_RowNOColumn.HeaderText = "行号";
            this.JL_RowNOColumn.Name = "JL_RowNOColumn";
            this.JL_RowNOColumn.ReadOnly = true;
            this.JL_RowNOColumn.Width = 52;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "REPAIRTHING";
            this.dataGridViewTextBoxColumn29.HeaderText = "维修内容摘要";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "JL";
            this.dataGridViewTextBoxColumn30.HeaderText = "结论";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.Width = 52;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "REPAIRPEOPLE";
            this.dataGridViewTextBoxColumn31.HeaderText = "维修人";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.Width = 64;
            // 
            // JL_CheckdateColumn
            // 
            this.JL_CheckdateColumn.DataPropertyName = "REPAIRDATE";
            this.JL_CheckdateColumn.Formt = null;
            this.JL_CheckdateColumn.HeaderText = "维修日期";
            this.JL_CheckdateColumn.Name = "JL_CheckdateColumn";
            this.JL_CheckdateColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.JL_CheckdateColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.JL_CheckdateColumn.Width = 76;
            // 
            // JL_CheckDate_Column
            // 
            this.JL_CheckDate_Column.DataPropertyName = "CHECKDATE";
            this.JL_CheckDate_Column.Formt = null;
            this.JL_CheckDate_Column.HeaderText = "检定日期";
            this.JL_CheckDate_Column.Name = "JL_CheckDate_Column";
            this.JL_CheckDate_Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.JL_CheckDate_Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.JL_CheckDate_Column.Width = 76;
            // 
            // JL_StatusColumn
            // 
            this.JL_StatusColumn.DataPropertyName = "STATUS";
            this.JL_StatusColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.JL_StatusColumn.HeaderText = "状态";
            this.JL_StatusColumn.Name = "JL_StatusColumn";
            this.JL_StatusColumn.ReadOnly = true;
            this.JL_StatusColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.JL_StatusColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.JL_StatusColumn.Width = 52;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "USERID";
            this.dataGridViewTextBoxColumn36.HeaderText = "操作员ID";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            this.dataGridViewTextBoxColumn36.Width = 76;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.DataPropertyName = "USERNAME";
            this.dataGridViewTextBoxColumn37.HeaderText = "操作员名称";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.ReadOnly = true;
            this.dataGridViewTextBoxColumn37.Width = 88;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.DataPropertyName = "RECDATE";
            this.dataGridViewTextBoxColumn38.HeaderText = "修改时间";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.ReadOnly = true;
            this.dataGridViewTextBoxColumn38.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn38.Width = 76;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.DataPropertyName = "CHOSCODE";
            this.dataGridViewTextBoxColumn39.HeaderText = "医疗机构编码";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.ReadOnly = true;
            // 
            // EQCardQuery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(894, 746);
            this.Controls.Add(this.dataGView1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox1);
            this.Name = "EQCardQuery";
            this.Text = "设备卡片查询";
            this.Load += new System.EventHandler(this.EQCardQuery_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.CardFJ_tab.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.CardJLRec_tab.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.CardCC_tab.ResumeLayout(false);
            this.CardCC_tab.PerformLayout();
            this.CardExplain_tab.ResumeLayout(false);
            this.CardExplain_tab.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Search_button;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private YtWinContrl.com.contrl.DateTimeDuan dateTimeDuan1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt_KS;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage CardFJ_tab;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TabPage CardJLRec_tab;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TabPage CardCC_tab;
        private System.Windows.Forms.TabPage CardExplain_tab;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox SMexplainNum_textBox;
        private System.Windows.Forms.TextBox SMusrtid_textBox;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox SMchoscode_textBox;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox SMboxthing_textBox;
        private System.Windows.Forms.TextBox SMusername_textBox;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox SMteachnum_textBox;
        private System.Windows.Forms.TextBox SMother_textBox;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox SMcertificate_textBox;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox SMcardid_textBox;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox SMext_textBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox CCuseridtextBox;
        private System.Windows.Forms.TextBox CCchosode_textBox;
        private System.Windows.Forms.TextBox CCcardid_textBox;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox CCusername_textBox;
        private System.Windows.Forms.TextBox CCrecdate_textBox;
        private System.Windows.Forms.TextBox CCcc_textBox;
        private System.Windows.Forms.TextBox CCprice_textBox;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.DateTimePicker CCbuydate_textBox;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox CCnewold_textBox;
        private System.Windows.Forms.TextBox CCsupply_textBox;
        private System.Windows.Forms.TextBox CCcsname_textBox;
        private System.Windows.Forms.TextBox CCother_textBox;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label TiaoSu;
        private System.Windows.Forms.Label label13;
        private YtWinContrl.com.datagrid.DataGView dataGView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column47;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column37;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column38;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column29;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column30;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column31;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column32;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column34;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column35;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column36;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column39;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column40;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column41;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column42;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column43;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column44;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column45;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column46;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column48;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column49;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column50;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column51;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column52;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column53;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private YtWinContrl.com.datagrid.DataGView dataGView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn FJ_CardIdCloumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn FJ_RowNoColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewComboBoxColumn FJ_unitColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn FJ_NUMColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn FJ_PriceColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn FJ_MoneyColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn FJ_Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private YtWinContrl.com.datagrid.DataGView dataGView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn JL_CardIdColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn JL_RowNOColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private YtWinContrl.com.datagrid.CalendarColumn JL_CheckdateColumn;
        private YtWinContrl.com.datagrid.CalendarColumn JL_CheckDate_Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn JL_StatusColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}