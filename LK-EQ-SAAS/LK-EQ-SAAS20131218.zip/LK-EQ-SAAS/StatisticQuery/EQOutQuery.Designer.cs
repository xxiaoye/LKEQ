﻿namespace StatisticQuery
{
    partial class EQOutQuery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EQOutQuery));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.selTextInpt_KS = new YtWinContrl.com.contrl.SelTextInpt();
            this.label6 = new System.Windows.Forms.Label();
            this.selTextInpt2 = new YtWinContrl.com.contrl.SelTextInpt();
            this.selTextInpt1 = new YtWinContrl.com.contrl.SelTextInpt();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Search_button = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeDuan1 = new YtWinContrl.com.contrl.DateTimeDuan();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dataGView1 = new YtWinContrl.com.datagrid.DataGView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column47 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.JinEHeJi = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.TiaoSu = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dataGView2 = new YtWinContrl.com.datagrid.DataGView();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.selTextInpt_KS);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.selTextInpt2);
            this.groupBox1.Controls.Add(this.selTextInpt1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Search_button);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.dateTimeDuan1);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(756, 93);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "查询";
            // 
            // selTextInpt_KS
            // 
            this.selTextInpt_KS.ColDefText = null;
            this.selTextInpt_KS.ColStyle = null;
            this.selTextInpt_KS.DataType = null;
            this.selTextInpt_KS.DbConn = null;
            this.selTextInpt_KS.Location = new System.Drawing.Point(296, 61);
            this.selTextInpt_KS.Name = "selTextInpt_KS";
            this.selTextInpt_KS.NextFocusControl = null;
            this.selTextInpt_KS.ReadOnly = false;
            this.selTextInpt_KS.SelParam = null;
            this.selTextInpt_KS.ShowColNum = 0;
            this.selTextInpt_KS.ShowWidth = 0;
            this.selTextInpt_KS.Size = new System.Drawing.Size(125, 22);
            this.selTextInpt_KS.Sql = null;
            this.selTextInpt_KS.SqlStr = null;
            this.selTextInpt_KS.TabIndex = 1;
            this.selTextInpt_KS.TvColName = null;
            this.selTextInpt_KS.Value = null;
            this.selTextInpt_KS.WatermarkText = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(251, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 37;
            this.label6.Text = "科室";
            // 
            // selTextInpt2
            // 
            this.selTextInpt2.ColDefText = null;
            this.selTextInpt2.ColStyle = null;
            this.selTextInpt2.DataType = null;
            this.selTextInpt2.DbConn = null;
            this.selTextInpt2.Location = new System.Drawing.Point(84, 61);
            this.selTextInpt2.Name = "selTextInpt2";
            this.selTextInpt2.NextFocusControl = null;
            this.selTextInpt2.ReadOnly = false;
            this.selTextInpt2.SelParam = null;
            this.selTextInpt2.ShowColNum = 0;
            this.selTextInpt2.ShowWidth = 0;
            this.selTextInpt2.Size = new System.Drawing.Size(133, 22);
            this.selTextInpt2.Sql = null;
            this.selTextInpt2.SqlStr = null;
            this.selTextInpt2.TabIndex = 0;
            this.selTextInpt2.TvColName = null;
            this.selTextInpt2.Value = null;
            this.selTextInpt2.WatermarkText = "";
            // 
            // selTextInpt1
            // 
            this.selTextInpt1.ColDefText = null;
            this.selTextInpt1.ColStyle = null;
            this.selTextInpt1.DataType = null;
            this.selTextInpt1.DbConn = null;
            this.selTextInpt1.Location = new System.Drawing.Point(503, 60);
            this.selTextInpt1.Name = "selTextInpt1";
            this.selTextInpt1.NextFocusControl = null;
            this.selTextInpt1.ReadOnly = false;
            this.selTextInpt1.SelParam = null;
            this.selTextInpt1.ShowColNum = 0;
            this.selTextInpt1.ShowWidth = 0;
            this.selTextInpt1.Size = new System.Drawing.Size(127, 22);
            this.selTextInpt1.Sql = null;
            this.selTextInpt1.SqlStr = null;
            this.selTextInpt1.TabIndex = 2;
            this.selTextInpt1.TvColName = null;
            this.selTextInpt1.Value = null;
            this.selTextInpt1.WatermarkText = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 33;
            this.label2.Text = "库房";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(438, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 33;
            this.label1.Text = "出库方式";
            // 
            // Search_button
            // 
            this.Search_button.Image = ((System.Drawing.Image)(resources.GetObject("Search_button.Image")));
            this.Search_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Search_button.Location = new System.Drawing.Point(652, 58);
            this.Search_button.Name = "Search_button";
            this.Search_button.Size = new System.Drawing.Size(82, 26);
            this.Search_button.TabIndex = 3;
            this.Search_button.Text = "   查询(&Q)";
            this.Search_button.UseVisualStyleBackColor = true;
            this.Search_button.Click += new System.EventHandler(this.Search_button_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(458, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 31;
            this.label3.Text = "到";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(251, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 30;
            this.label4.Text = "从";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 29;
            this.label5.Text = "常用时间段";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Checked = false;
            this.dateTimePicker2.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(503, 19);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(127, 21);
            this.dateTimePicker2.TabIndex = 28;
            // 
            // dateTimeDuan1
            // 
            this.dateTimeDuan1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dateTimeDuan1.End = this.dateTimePicker2;
            this.dateTimeDuan1.FormattingEnabled = true;
            this.dateTimeDuan1.Location = new System.Drawing.Point(84, 20);
            this.dateTimeDuan1.Name = "dateTimeDuan1";
            this.dateTimeDuan1.Size = new System.Drawing.Size(133, 20);
            this.dateTimeDuan1.Start = this.dateTimePicker1;
            this.dateTimeDuan1.TabIndex = 27;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Checked = false;
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(294, 19);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(127, 21);
            this.dateTimePicker1.TabIndex = 26;
            // 
            // dataGView1
            // 
            this.dataGView1.AllowUserToAddRows = false;
            this.dataGView1.AllowUserToDeleteRows = false;
            this.dataGView1.AllowUserToResizeRows = false;
            this.dataGView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGView1.ChangeDataColumName = null;
            this.dataGView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGView1.ColumnHeadersHeight = 25;
            this.dataGView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column47,
            this.Column8,
            this.Column5,
            this.Column37,
            this.Column6,
            this.Column7,
            this.Column20,
            this.Column38,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column16,
            this.Column9});
            this.dataGView1.DbConn = null;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView1.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGView1.DwColIndex = 0;
            this.dataGView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView1.IsEditOnEnter = true;
            this.dataGView1.IsFillForm = true;
            this.dataGView1.IsPage = false;
            this.dataGView1.Key = null;
            this.dataGView1.Location = new System.Drawing.Point(0, 93);
            this.dataGView1.Name = "dataGView1";
            this.dataGView1.ReadOnly = true;
            this.dataGView1.RowHeadersWidth = 30;
            this.dataGView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView1.RowTemplate.Height = 23;
            this.dataGView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView1.Size = new System.Drawing.Size(756, 246);
            this.dataGView1.TabIndex = 17;
            this.dataGView1.TjFmtStr = null;
            this.dataGView1.TjFormat = null;
            this.dataGView1.Url = null;
            this.dataGView1.SelectionChanged += new System.EventHandler(this.dataGView1_SelectionChanged);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "OUTID";
            this.Column1.HeaderText = "出库ID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 64;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "IONAME";
            this.Column2.HeaderText = "出库方式";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 76;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "OPFLAG";
            this.Column3.HeaderText = "操作标志";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 76;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "WARENAME";
            this.Column4.HeaderText = "出库库房";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column4.Width = 76;
            // 
            // Column47
            // 
            this.Column47.DataPropertyName = "TARGETWARECODE";
            this.Column47.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Column47.HeaderText = "出库目的库房";
            this.Column47.Name = "Column47";
            this.Column47.ReadOnly = true;
            this.Column47.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column47.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "TARGETDEPTID";
            this.Column8.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Column8.HeaderText = "出库目的科室";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "TOTALMONEY";
            this.Column5.HeaderText = "总金额";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 64;
            // 
            // Column37
            // 
            this.Column37.DataPropertyName = "INID";
            this.Column37.HeaderText = "对应入库ID";
            this.Column37.Name = "Column37";
            this.Column37.ReadOnly = true;
            this.Column37.Width = 88;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "LSTOTALMONEY";
            this.Column6.HeaderText = "零售总金额";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 88;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "STATUS";
            this.Column7.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Column7.HeaderText = "状态";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column7.Width = 52;
            // 
            // Column20
            // 
            this.Column20.DataPropertyName = "RECIPECODE";
            this.Column20.HeaderText = "单据号";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.Width = 64;
            // 
            // Column38
            // 
            this.Column38.DataPropertyName = "OUTDATE";
            this.Column38.HeaderText = "制单日期";
            this.Column38.Name = "Column38";
            this.Column38.ReadOnly = true;
            this.Column38.Width = 76;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "USERID";
            this.Column10.HeaderText = "操作员ID";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 76;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "USERNAME";
            this.Column11.HeaderText = "操作员名称";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 88;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "RECDATE";
            this.Column12.HeaderText = "修改时间";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 76;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "SHDATE";
            this.Column13.HeaderText = "审核日期";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Width = 76;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "SHUSERID";
            this.Column14.HeaderText = "审核操作员ID";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "SHUSERNAME";
            this.Column15.HeaderText = "审核操作员姓名";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Width = 112;
            // 
            // Column17
            // 
            this.Column17.DataPropertyName = "CXDATE";
            this.Column17.HeaderText = "冲销日期";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.Width = 76;
            // 
            // Column18
            // 
            this.Column18.DataPropertyName = "CXUSERID";
            this.Column18.HeaderText = "冲销操作员ID";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            // 
            // Column19
            // 
            this.Column19.DataPropertyName = "CXUSERNAME";
            this.Column19.HeaderText = "冲销操作员姓名";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            this.Column19.Width = 112;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "CHOSCODE";
            this.Column16.HeaderText = "医疗机构编码";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "MEMO";
            this.Column9.HeaderText = "备注";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 52;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.JinEHeJi);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.TiaoSu);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 339);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(756, 30);
            this.groupBox3.TabIndex = 33;
            this.groupBox3.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(427, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 12);
            this.label7.TabIndex = 37;
            this.label7.Text = "0元";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(327, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 12);
            this.label8.TabIndex = 36;
            this.label8.Text = "零售总金额合计：";
            // 
            // JinEHeJi
            // 
            this.JinEHeJi.AutoSize = true;
            this.JinEHeJi.Location = new System.Drawing.Point(221, 14);
            this.JinEHeJi.Name = "JinEHeJi";
            this.JinEHeJi.Size = new System.Drawing.Size(23, 12);
            this.JinEHeJi.TabIndex = 33;
            this.JinEHeJi.Text = "0元";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(148, 14);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 12);
            this.label15.TabIndex = 32;
            this.label15.Text = "总金额合计：";
            // 
            // TiaoSu
            // 
            this.TiaoSu.AutoSize = true;
            this.TiaoSu.Location = new System.Drawing.Point(46, 14);
            this.TiaoSu.Name = "TiaoSu";
            this.TiaoSu.Size = new System.Drawing.Size(23, 12);
            this.TiaoSu.TabIndex = 31;
            this.TiaoSu.Text = "0笔";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(21, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 30;
            this.label13.Text = "共：";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Location = new System.Drawing.Point(0, 509);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(756, 30);
            this.groupBox2.TabIndex = 35;
            this.groupBox2.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(597, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 12);
            this.label9.TabIndex = 37;
            this.label9.Text = "0元";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(513, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 36;
            this.label10.Text = "运杂费合计：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(217, 14);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 12);
            this.label14.TabIndex = 33;
            this.label14.Text = "0元";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(144, 14);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 32;
            this.label17.Text = "金额合计：";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(46, 14);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(23, 12);
            this.label18.TabIndex = 31;
            this.label18.Text = "0条";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(21, 14);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 30;
            this.label19.Text = "共：";
            // 
            // dataGView2
            // 
            this.dataGView2.AllowUserToAddRows = false;
            this.dataGView2.AllowUserToDeleteRows = false;
            this.dataGView2.AllowUserToResizeRows = false;
            this.dataGView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGView2.ChangeDataColumName = null;
            this.dataGView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGView2.ColumnHeadersHeight = 25;
            this.dataGView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column24,
            this.Column25,
            this.Column26,
            this.Column23,
            this.Column27,
            this.Column28,
            this.Column29,
            this.Column30,
            this.Column31,
            this.Column32,
            this.Column33,
            this.Column34,
            this.Column40,
            this.Column41,
            this.Column45,
            this.Column46,
            this.Column22,
            this.Column36,
            this.Column42,
            this.Column35,
            this.Column44,
            this.Column43});
            this.dataGView2.DbConn = null;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGView2.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGView2.DwColIndex = 0;
            this.dataGView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGView2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGView2.IsEditOnEnter = true;
            this.dataGView2.IsFillForm = true;
            this.dataGView2.IsPage = false;
            this.dataGView2.Key = null;
            this.dataGView2.Location = new System.Drawing.Point(0, 369);
            this.dataGView2.Name = "dataGView2";
            this.dataGView2.ReadOnly = true;
            this.dataGView2.RowHeadersWidth = 30;
            this.dataGView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGView2.RowTemplate.Height = 23;
            this.dataGView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGView2.Size = new System.Drawing.Size(756, 140);
            this.dataGView2.TabIndex = 36;
            this.dataGView2.TjFmtStr = null;
            this.dataGView2.TjFormat = null;
            this.dataGView2.Url = null;
            // 
            // Column24
            // 
            this.Column24.DataPropertyName = "OUTID";
            this.Column24.HeaderText = "出库ID";
            this.Column24.Name = "Column24";
            this.Column24.ReadOnly = true;
            this.Column24.Width = 64;
            // 
            // Column25
            // 
            this.Column25.DataPropertyName = "EQNAME";
            this.Column25.HeaderText = "设备";
            this.Column25.Name = "Column25";
            this.Column25.ReadOnly = true;
            this.Column25.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column25.Width = 52;
            // 
            // Column26
            // 
            this.Column26.DataPropertyName = "DICDESC";
            this.Column26.HeaderText = "单位";
            this.Column26.Name = "Column26";
            this.Column26.ReadOnly = true;
            this.Column26.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column26.Width = 52;
            // 
            // Column23
            // 
            this.Column23.DataPropertyName = "DETAILNO";
            this.Column23.HeaderText = "流水号";
            this.Column23.Name = "Column23";
            this.Column23.ReadOnly = true;
            this.Column23.Width = 64;
            // 
            // Column27
            // 
            this.Column27.DataPropertyName = "NUM";
            this.Column27.HeaderText = "数量";
            this.Column27.Name = "Column27";
            this.Column27.ReadOnly = true;
            this.Column27.Width = 52;
            // 
            // Column28
            // 
            this.Column28.DataPropertyName = "PRICE";
            this.Column28.HeaderText = "单价";
            this.Column28.Name = "Column28";
            this.Column28.ReadOnly = true;
            this.Column28.Width = 52;
            // 
            // Column29
            // 
            this.Column29.DataPropertyName = "MONEY";
            this.Column29.HeaderText = "金额";
            this.Column29.Name = "Column29";
            this.Column29.ReadOnly = true;
            this.Column29.Width = 52;
            // 
            // Column30
            // 
            this.Column30.DataPropertyName = "GG";
            this.Column30.HeaderText = "规格";
            this.Column30.Name = "Column30";
            this.Column30.ReadOnly = true;
            this.Column30.Width = 52;
            // 
            // Column31
            // 
            this.Column31.DataPropertyName = "XH";
            this.Column31.HeaderText = "型号";
            this.Column31.Name = "Column31";
            this.Column31.ReadOnly = true;
            this.Column31.Width = 52;
            // 
            // Column32
            // 
            this.Column32.DataPropertyName = "CD";
            this.Column32.HeaderText = "产地";
            this.Column32.Name = "Column32";
            this.Column32.ReadOnly = true;
            this.Column32.Width = 52;
            // 
            // Column33
            // 
            this.Column33.DataPropertyName = "OTHERMONEY";
            this.Column33.HeaderText = "运杂费";
            this.Column33.Name = "Column33";
            this.Column33.ReadOnly = true;
            this.Column33.Width = 64;
            // 
            // Column34
            // 
            this.Column34.DataPropertyName = "STOCKFLOWNO";
            this.Column34.HeaderText = "库存流水号";
            this.Column34.Name = "Column34";
            this.Column34.ReadOnly = true;
            this.Column34.Width = 88;
            // 
            // Column40
            // 
            this.Column40.DataPropertyName = "TOTALPRICE";
            this.Column40.HeaderText = "成本单价";
            this.Column40.Name = "Column40";
            this.Column40.ReadOnly = true;
            this.Column40.Width = 76;
            // 
            // Column41
            // 
            this.Column41.DataPropertyName = "TOTALMONEY";
            this.Column41.HeaderText = "成本金额";
            this.Column41.Name = "Column41";
            this.Column41.ReadOnly = true;
            this.Column41.Width = 76;
            // 
            // Column45
            // 
            this.Column45.DataPropertyName = "SUPPLYID";
            this.Column45.HeaderText = "生产厂家ID";
            this.Column45.Name = "Column45";
            this.Column45.ReadOnly = true;
            this.Column45.Width = 88;
            // 
            // Column46
            // 
            this.Column46.DataPropertyName = "SUPPLYNAME";
            this.Column46.HeaderText = "生产厂家名称";
            this.Column46.Name = "Column46";
            this.Column46.ReadOnly = true;
            // 
            // Column22
            // 
            this.Column22.DataPropertyName = "PRODUCTDATE";
            this.Column22.HeaderText = "生产日期";
            this.Column22.Name = "Column22";
            this.Column22.ReadOnly = true;
            this.Column22.Width = 76;
            // 
            // Column36
            // 
            this.Column36.DataPropertyName = "VALIDDATE";
            this.Column36.HeaderText = "有效期";
            this.Column36.Name = "Column36";
            this.Column36.ReadOnly = true;
            this.Column36.Width = 64;
            // 
            // Column42
            // 
            this.Column42.DataPropertyName = "WSXKZH";
            this.Column42.HeaderText = "卫生许可证号";
            this.Column42.Name = "Column42";
            this.Column42.ReadOnly = true;
            // 
            // Column35
            // 
            this.Column35.DataPropertyName = "CHOSCODE";
            this.Column35.HeaderText = "医疗机构编码";
            this.Column35.Name = "Column35";
            this.Column35.ReadOnly = true;
            // 
            // Column44
            // 
            this.Column44.DataPropertyName = "TXM";
            this.Column44.HeaderText = "条形码";
            this.Column44.Name = "Column44";
            this.Column44.ReadOnly = true;
            this.Column44.Width = 64;
            // 
            // Column43
            // 
            this.Column43.DataPropertyName = "MEMO";
            this.Column43.HeaderText = "备注";
            this.Column43.Name = "Column43";
            this.Column43.ReadOnly = true;
            this.Column43.Width = 52;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(417, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 12);
            this.label11.TabIndex = 39;
            this.label11.Text = "0元";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(327, 14);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 12);
            this.label12.TabIndex = 38;
            this.label12.Text = "成本金额合计：";
            // 
            // EQOutQuery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 539);
            this.Controls.Add(this.dataGView2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.dataGView1);
            this.Controls.Add(this.groupBox1);
            this.Name = "EQOutQuery";
            this.Text = "设备出库查询";
            this.Load += new System.EventHandler(this.EQOutQuery_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt2;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Search_button;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private YtWinContrl.com.contrl.DateTimeDuan dateTimeDuan1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private YtWinContrl.com.datagrid.DataGView dataGView1;
        private YtWinContrl.com.contrl.SelTextInpt selTextInpt_KS;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column47;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column37;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column38;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label JinEHeJi;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label TiaoSu;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private YtWinContrl.com.datagrid.DataGView dataGView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column29;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column30;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column31;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column32;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column34;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column40;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column41;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column45;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column46;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column36;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column42;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column35;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column44;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column43;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}